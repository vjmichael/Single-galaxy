# Eve-Mu — P1-F1 through P1-F120 fork-source survey

**Snapshot observed:** 2026-10-27  
**Status:** All 120 forks enumerated and screened for `master` divergence and branch names. Build, in-depth source semantics, and runtime improvement tests reserved for P2.

## Verified census

- **120 named, P0-lineage-verified forks:** all publicly visible, unarchived, `master` default, with GitHub source lineage anchored to `EvEmu-Project/evemu_Crucible` (F8 is a descendant of F1).
- **`master` GitHub compare:** 34 identical; 46 behind; 30 diverged; 9 ahead; 1 not comparable (no common ancestor).
- **Other branches discovered:** 205 named nondefault branches across 70 forks. Branch names are NOT evidence of implemented or working features; some are copies of historical shared branches.
- **No codebase behavior has been tested.** Divergence shows commit history only, not quality, completeness, feature support, or compatibility.
- **Three unidentified entries** inferred from a dynamic GitHub fork counter remain separate from numbered F1–F120. Do not confuse 120 named forks with a complete census of every historical/private/inaccessible fork.

## Highest-priority source inspection leads (not confirmed improvements)

| Fork | Master comparison | What changed on disk / what deserves inspection |
|---|---|---|
| P1-F118 `rumpelstompskin/evemu_Crucible_Claude` | 41 ahead; 42 files | Market SQL indexes/seed scripts, market service, `WormholeMgr`, `DungeonMgr`, `AnomalyMgr`, NPC/drone AI, Docker helper scripts. Promising for solo economy and wormholes; untested. |
| P1-F120 `Black007Angel/evemu_Crucible-physics` | 5 ahead; 30 files | `MarketBotMgr`, inventory, celestial/physics movement, drone/AI and Docker setup. Promising for automated markets and local mining experience; untested. |
| P1-F2 `AzediZ/evemu_Crucible` | 51 ahead; 174 files | Incursion data, automated bot client, movement/combat, many server subsystems and build scripts. Broad modification with high integration risk; untested. |
| P1-F12 `pixelcatburglar/evemu_Crucible` | 7 ahead; 82 files | API server, accounts, agents, character services and migration. Useful potential tooling; direct mining benefit not established. |
| P1-F69 `jionychiow/evemu_Crucible` | 10 ahead / 1 behind; 80 files | EVE protocol, packet handling, character/agent and ship services. Compatibility risk warrants targeted inspection. |
| P1-F97 `brandonbelisle/evemu_Crucible` | 16 ahead; 6 files | Ship, `Damage`, `DestinyManager` and system movement; small, focused surface. |
| P1-F71 `Conan1996-2/evemu_Crucible` | 8 ahead; 3 files | Database cleanup script and database connection handling; possible installation relevance. |
| P1-F26 `chuengeric/evemu_Crucible` | 3 ahead; 13 files | Memory allocators and server utilities; indirect stability relevance. |
| P1-F87 `Worlgun/evemu_Crucible` | Not comparable | GitHub returned no common ancestor for `master`; repository size was markedly small in search. Inspect independently before considering integration. |

## Nondefault branches worth follow-up

- P1-F1: `feature/tutorial-disable`, `fix/warp-formula-and-packets`.
- P1-F7: `feature/physics`, `fix/repair-service-and-warp-desync`.
- P1-F23: `probe-crash`, `dev`, `destiny-rework`.
- P1-F29: `CommandCenter-pin-error`, `piPins-sql`.
- P1-F38: `market-solarSystemIndex`.
- P1-F42: `fixes/2026-10-15-combat-and-fitting`.
- P1-F59: `phase-0-foundation`, `phase-1-commerce`.
- P1-F63: `staging_autopilot`, `staging_traderjoe_1_0`, `dbupgrade`.
- P1-F83: `iHub_management_open`, `giveallskills_fix`, `target_destroyed_modules_deactivate_segfault`.
- P1-F91: `manufacturing-fix`.
- P1-F95: `missions_rework`.
- P1-F106: `belt-rat-spawns-(high-value,-isolated-diff)`, `destiny-move-desync-275`.
- P1-F108: `player-bot`.
- P1-F115: `feature/outpost-manufacturing`, `feature/pos-manufacturing`.
- Many forks carry `destiny-rework`, `dungeon_editor`, or `staging`; do not assume these are unique branch implementations.

## Practical P2 evaluation criteria

Prioritize mining loop (ore belt, laser cycles, cargo, refining, sale), offline economy/market liquidity, predictable ore replenishment, system transfers, persistence, solo NPC behavior, Windows setup, and optional wormhole connectivity. Read each claimed feature source, assess underlying dependencies, build or test where possible, and classify as verified / promising-unverified / not relevant / regression. Do not merge on file count alone. Pin exact SHAs before implementing changes.

## Full per-fork register

| P1 | Fork (owner/repo) | Master relative to upstream | Ahead | Behind | Other branches |
|---|---|---|---:|---:|---|
| P1-F1 | [ozatomic/evemu_crucible_current](https://github.com/ozatomic/evemu_crucible_current) | identical | 0 | 0 | feature/tutorial-disable, fix/warp-formula-and-packets |
| P1-F2 | [AzediZ/evemu_Crucible](https://github.com/AzediZ/evemu_Crucible) | ahead | 51 | 0 | revised |
| P1-F3 | [ion9/evemu_Crucible](https://github.com/ion9/evemu_Crucible) | behind | 0 | 395 | dashboard/phpmyadmin, staging |
| P1-F4 | [triple111/evemu_Crucible](https://github.com/triple111/evemu_Crucible) | behind | 0 | 30 | staging, testing |
| P1-F5 | [GameModForks/evemu_Crucible](https://github.com/GameModForks/evemu_Crucible) | diverged | 2 | 243 | — |
| P1-F6 | [ToddRosenkrantz/evemu_Crucible](https://github.com/ToddRosenkrantz/evemu_Crucible) | diverged | 3 | 382 | fix-108, patch-1, staging |
| P1-F7 | [ziggozoggo/evemu_crucible](https://github.com/ziggozoggo/evemu_crucible) | identical | 0 | 0 | feature/physics, fix/repair-service-and-warp-desync, stage |
| P1-F8 | [pet1100/evemu_crucible](https://github.com/pet1100/evemu_crucible) | identical | 0 | 0 | bugfix/undocking, dev |
| P1-F9 | [chengood5000/evemu_Crucible](https://github.com/chengood5000/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F10 | [chuengjoanna/evemu_Crucible](https://github.com/chuengjoanna/evemu_Crucible) | behind | 0 | 1 | apple_compatible |
| P1-F11 | [luokery/evemu_Crucible](https://github.com/luokery/evemu_Crucible) | diverged | 1 | 243 | — |
| P1-F12 | [pixelcatburglar/evemu_Crucible](https://github.com/pixelcatburglar/evemu_Crucible) | ahead | 7 | 0 | — |
| P1-F13 | [DavidStinson/evemu_Crucible](https://github.com/DavidStinson/evemu_Crucible) | diverged | 2 | 243 | — |
| P1-F14 | [bnaambo/evemu_Crucible](https://github.com/bnaambo/evemu_Crucible) | behind | 0 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F15 | [novafacing/evemu_Crucible](https://github.com/novafacing/evemu_Crucible) | diverged | 2 | 243 | destiny-rework, dungeon_editor, patch/boost_1.74.0_compat, staging |
| P1-F16 | [sangohan/evemu_Crucible](https://github.com/sangohan/evemu_Crucible) | diverged | 2 | 243 | — |
| P1-F17 | [idolord/evemu_Crucible](https://github.com/idolord/evemu_Crucible) | diverged | 1 | 67 | destiny-rework, dungeon_editor, staging |
| P1-F18 | [ImTorbin/evemu_Crucible3.0](https://github.com/ImTorbin/evemu_Crucible3.0) | identical | 0 | 0 | — |
| P1-F19 | [cingulari/evemu_Crucible](https://github.com/cingulari/evemu_Crucible) | behind | 0 | 30 | destiny-rework, dungeon_editor, staging |
| P1-F20 | [seren1tyy/evemu_Crucible](https://github.com/seren1tyy/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F21 | [locvez/evemu_Crucible](https://github.com/locvez/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F22 | [strikersix23/evemu_Crucible](https://github.com/strikersix23/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F23 | [d10sfan/evemu_Crucible](https://github.com/d10sfan/evemu_Crucible) | behind | 0 | 30 | destiny-rework, dev, dungeon_editor, probe-crash, staging, test |
| P1-F24 | [charles-m-knox/evemu_Crucible](https://github.com/charles-m-knox/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F25 | [Avi-E-Koenig/evemu_Crucible](https://github.com/Avi-E-Koenig/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F26 | [chuengeric/evemu_Crucible](https://github.com/chuengeric/evemu_Crucible) | ahead | 3 | 0 | — |
| P1-F27 | [dd667/evemu_Crucible](https://github.com/dd667/evemu_Crucible) | behind | 0 | 30 | fix-108, staging |
| P1-F28 | [x0S37h0x/evemu_Crucible](https://github.com/x0S37h0x/evemu_Crucible) | diverged | 6 | 243 | — |
| P1-F29 | [DeerHunt3r/evemu_Crucible](https://github.com/DeerHunt3r/evemu_Crucible) | diverged | 2 | 383 | #105, CommandCenter-pin-error, fix-108, patch-1, piPins-sql, staging |
| P1-F30 | [SilverXarrow/evemu_Crucible](https://github.com/SilverXarrow/evemu_Crucible) | behind | 0 | 30 | destiny-rework, dungeon_editor, staging |
| P1-F31 | [devedse/evemu_Crucible](https://github.com/devedse/evemu_Crucible) | identical | 0 | 0 | destiny-rework, staging |
| P1-F32 | [01Hub/evemu_Crucible](https://github.com/01Hub/evemu_Crucible) | diverged | 1 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F33 | [phillipwgardner/evemu_Crucible](https://github.com/phillipwgardner/evemu_Crucible) | diverged | 5 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F34 | [alycecil/evemu_Crucible](https://github.com/alycecil/evemu_Crucible) | diverged | 5 | 243 | destiny-rework, dungeon_editor, main, staged, staging |
| P1-F35 | [donato/evemu_Crucible](https://github.com/donato/evemu_Crucible) | diverged | 6 | 1 | 3, cmake |
| P1-F36 | [swaric/evemu_Crucible](https://github.com/swaric/evemu_Crucible) | identical | 0 | 0 | destiny-rework, feature/packet-capture, staging |
| P1-F37 | [afarazit/evemu_Crucible](https://github.com/afarazit/evemu_Crucible) | diverged | 5 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F38 | [kenneaal/evemu_Crucible](https://github.com/kenneaal/evemu_Crucible) | behind | 0 | 30 | destiny-rework, dungeon_editor, market-solarSystemIndex, staging |
| P1-F39 | [dawa11/evemu_Crucible](https://github.com/dawa11/evemu_Crucible) | identical | 0 | 0 | destiny-rework, staging |
| P1-F40 | [soesbeek/evemu_crucible](https://github.com/soesbeek/evemu_crucible) | diverged | 1 | 1 | — |
| P1-F41 | [PHX-TeamPhoenix/evemu_Crucible](https://github.com/PHX-TeamPhoenix/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F42 | [Mrinnovvation/evemu_Crucible](https://github.com/Mrinnovvation/evemu_Crucible) | identical | 0 | 0 | destiny-rework, fix/gettimeparts-now, fixes/2026-10-15-combat-and-fitting, staging |
| P1-F43 | [gatesry/evemu_Crucible](https://github.com/gatesry/evemu_Crucible) | diverged | 3 | 380 | staging |
| P1-F44 | [rrfarmer/evemu_Crucible](https://github.com/rrfarmer/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F45 | [AceGamesUser/evemu_Crucible](https://github.com/AceGamesUser/evemu_Crucible) | diverged | 1 | 30 | — |
| P1-F46 | [SynieztroLedPar/evemu_Crucible](https://github.com/SynieztroLedPar/evemu_Crucible) | diverged | 6 | 243 | — |
| P1-F47 | [I-89762345-I/evemu_Crucible](https://github.com/I-89762345-I/evemu_Crucible) | behind | 0 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F48 | [sephcasiah/evemu_Crucible](https://github.com/sephcasiah/evemu_Crucible) | behind | 0 | 1 | — |
| P1-F49 | [d4rkf0x/evemu_Crucible](https://github.com/d4rkf0x/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F50 | [dgerabagi/evemu_Crucible](https://github.com/dgerabagi/evemu_Crucible) | identical | 0 | 0 | feature/autopilot-fix, feature/combat-missions |
| P1-F51 | [xrizonx/evemu_Crucible](https://github.com/xrizonx/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F52 | [gebainixyz/evemu_Crucible](https://github.com/gebainixyz/evemu_Crucible) | behind | 0 | 30 | destiny-rework, dungeon_editor, staging |
| P1-F53 | [Almamu/evemu_crucible](https://github.com/Almamu/evemu_crucible) | diverged | 7 | 243 | refactor/python-types-rewrite, staging |
| P1-F54 | [Pursche/evemu_Crucible](https://github.com/Pursche/evemu_Crucible) | diverged | 3 | 243 | staging |
| P1-F55 | [Mezzarius/evemu_Crucible](https://github.com/Mezzarius/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F56 | [hxhieu/evemu_Crucible](https://github.com/hxhieu/evemu_Crucible) | identical | 0 | 0 | chore/hxh-dockerfile, chore/local-debug, chore/pyrep-lite-build, destiny-rework, dungeon_editor, staging |
| P1-F57 | [SpirytusMoe/evemu_Crucible](https://github.com/SpirytusMoe/evemu_Crucible) | behind | 0 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F58 | [AviiNL/evemu_Crucible](https://github.com/AviiNL/evemu_Crucible) | diverged | 2 | 1 | — |
| P1-F59 | [sargentscrufy/evemu_Crucible](https://github.com/sargentscrufy/evemu_Crucible) | identical | 0 | 0 | destiny-rework, phase-0-foundation, phase-1-commerce, staging |
| P1-F60 | [GrumpyDrago/evemu_Crucible](https://github.com/GrumpyDrago/evemu_Crucible) | diverged | 3 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F61 | [favoms/evemu_Crucible](https://github.com/favoms/evemu_Crucible) | behind | 0 | 243 | destiny-rework, staging |
| P1-F62 | [salartarium/evemu_Crucible](https://github.com/salartarium/evemu_Crucible) | behind | 0 | 30 | destiny-rework, dungeon_editor, patch-1, staging |
| P1-F63 | [celinor1982/evemu_Crucible](https://github.com/celinor1982/evemu_Crucible) | behind | 0 | 1 | dbupgrade, destiny-rework, dungeon_editor, staging, staging_autopilot, staging_test, staging_traderjoe_1_0 |
| P1-F64 | [aliyajadzia/evemu_Crucible](https://github.com/aliyajadzia/evemu_Crucible) | behind | 0 | 30 | destiny-rework, staging |
| P1-F65 | [kroryan/evemu_Crucible](https://github.com/kroryan/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F66 | [innocentius/evemu_Crucible](https://github.com/innocentius/evemu_Crucible) | behind | 0 | 30 | destiny-rework, dungeon_editor, staging |
| P1-F67 | [no23/evemu_Crucible](https://github.com/no23/evemu_Crucible) | ahead | 1 | 0 | — |
| P1-F68 | [beelitzs/evemu_Crucible](https://github.com/beelitzs/evemu_Crucible) | behind | 0 | 1 | destiny-rework, dungeon_editor, staging |
| P1-F69 | [jionychiow/evemu_Crucible](https://github.com/jionychiow/evemu_Crucible) | diverged | 10 | 1 | — |
| P1-F70 | [tylerengland89/evemu_Crucible](https://github.com/tylerengland89/evemu_Crucible) | identical | 0 | 0 | destiny-rework, staging |
| P1-F71 | [Conan1996-2/evemu_Crucible](https://github.com/Conan1996-2/evemu_Crucible) | ahead | 8 | 0 | — |
| P1-F72 | [wytsa/evemu_Crucible](https://github.com/wytsa/evemu_Crucible) | behind | 0 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F73 | [Gargash/evemu_Crucible](https://github.com/Gargash/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F74 | [TheOneJohiah/evemu_Crucible](https://github.com/TheOneJohiah/evemu_Crucible) | diverged | 2 | 243 | destiny-rework, staging |
| P1-F75 | [almirosmanovic/evemu_Crucible](https://github.com/almirosmanovic/evemu_Crucible) | behind | 0 | 30 | destiny-rework, dungeon_editor, staging |
| P1-F76 | [JiwekLabs/evemu_Crucible](https://github.com/JiwekLabs/evemu_Crucible) | identical | 0 | 0 | feature/stationmenus, inventory |
| P1-F77 | [xxdolcexx/evemu_Crucible](https://github.com/xxdolcexx/evemu_Crucible) | diverged | 1 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F78 | [dkstiler/evemu_Crucible](https://github.com/dkstiler/evemu_Crucible) | identical | 0 | 0 | destiny-rework, destiny-staging, fix-108, staging |
| P1-F79 | [ganymedex/evemu_Crucible](https://github.com/ganymedex/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F80 | [sonicj/evemu_Crucible](https://github.com/sonicj/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F81 | [masternerdguy/evemu_Crucible](https://github.com/masternerdguy/evemu_Crucible) | identical | 0 | 0 | defect/20260607-incorrect-spawn-class, staging |
| P1-F82 | [KaldarAralay/evemu_Crucible](https://github.com/KaldarAralay/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F83 | [SantjagoCorkez/evemu_Crucible](https://github.com/SantjagoCorkez/evemu_Crucible) | behind | 0 | 30 | boost_174_build_fix, destiny-rework, giveallskills_fix, iHub_management_open, odb_models, staging, target_destroyed_modules_deactivate_segfault |
| P1-F84 | [Valkyrien04/evemu_Crucible](https://github.com/Valkyrien04/evemu_Crucible) | diverged | 1 | 243 | feature-env-var-support |
| P1-F85 | [AlbertPope/evemu_Crucible](https://github.com/AlbertPope/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F86 | [nicti/evemu_Crucible](https://github.com/nicti/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F87 | [Worlgun/evemu_Crucible](https://github.com/Worlgun/evemu_Crucible) | error | — | — | — |
| P1-F88 | [ZyenDomani/evemu_Crucible](https://github.com/ZyenDomani/evemu_Crucible) | behind | 0 | 30 | staging |
| P1-F89 | [kroryon/evemu_Crucible](https://github.com/kroryon/evemu_Crucible) | behind | 0 | 1 | — |
| P1-F90 | [zhyrohaad/evemu_Crucible](https://github.com/zhyrohaad/evemu_Crucible) | behind | 0 | 244 | allan-destiny, destiny-rework, staging |
| P1-F91 | [katz1/evemu_Crucible](https://github.com/katz1/evemu_Crucible) | behind | 0 | 380 | manufacturing-fix, staging |
| P1-F92 | [fumikejin/evemu_Crucible](https://github.com/fumikejin/evemu_Crucible) | behind | 0 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F93 | [rhammond17/evemu_Crucible](https://github.com/rhammond17/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F94 | [alive1986/evemu_Crucible](https://github.com/alive1986/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F95 | [jdhirst/evemu_Crucible](https://github.com/jdhirst/evemu_Crucible) | identical | 0 | 0 | missions_rework, posplot, staging |
| P1-F96 | [CyborgYL/evemu_Crucible](https://github.com/CyborgYL/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F97 | [brandonbelisle/evemu_Crucible](https://github.com/brandonbelisle/evemu_Crucible) | ahead | 16 | 0 | — |
| P1-F98 | [xchgeax/evemu_Crucible](https://github.com/xchgeax/evemu_Crucible) | behind | 0 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F99 | [Trav41514/evemu_Crucible](https://github.com/Trav41514/evemu_Crucible) | behind | 0 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F100 | [Stranho/evemu_Crucible](https://github.com/Stranho/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F101 | [mcp77/evemu_Crucible](https://github.com/mcp77/evemu_Crucible) | behind | 0 | 243 | destiny-rework, dungeon_editor, staging |
| P1-F102 | [boldblue/evemu_Crucible](https://github.com/boldblue/evemu_Crucible) | diverged | 1 | 243 | — |
| P1-F103 | [solette1/evemu_Crucible](https://github.com/solette1/evemu_Crucible) | ahead | 2 | 0 | copilot/implement-faction-territory-warfare, destiny-rework, dungeon_editor, staging |
| P1-F104 | [TohkaPrincess/evemu_Crucible](https://github.com/TohkaPrincess/evemu_Crucible) | behind | 0 | 1 | — |
| P1-F105 | [Stars-22/evemu_Crucible](https://github.com/Stars-22/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F106 | [robertbriggsgames/evemu_Crucible](https://github.com/robertbriggsgames/evemu_Crucible) | identical | 0 | 0 | Staging, belt-rat-spawns-(high-value,-isolated-diff), destiny-move-desync-275, modules-loader |
| P1-F107 | [VizanArkonin/evemu_Crucible](https://github.com/VizanArkonin/evemu_Crucible) | behind | 0 | 244 | contracts_implementation, destiny-rework, revert-1-staging, staging |
| P1-F108 | [FrostSoul/evemu_Crucible](https://github.com/FrostSoul/evemu_Crucible) | identical | 0 | 0 | player-bot |
| P1-F109 | [hrluo93/evemu_Crucible](https://github.com/hrluo93/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F110 | [closet13/evemu_Crucible](https://github.com/closet13/evemu_Crucible) | behind | 0 | 30 | — |
| P1-F111 | [FeenieRU/evemu_Crucible](https://github.com/FeenieRU/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F112 | [comet0/evemu_crucible](https://github.com/comet0/evemu_crucible) | diverged | 3 | 1 | — |
| P1-F113 | [melkordoran/evemu_Crucible](https://github.com/melkordoran/evemu_Crucible) | identical | 0 | 0 | destiny-rework, staging |
| P1-F114 | [ThisIsSietandre/evemu_Crucible](https://github.com/ThisIsSietandre/evemu_Crucible) | identical | 0 | 0 | — |
| P1-F115 | [marsara9/evemu_Crucible](https://github.com/marsara9/evemu_Crucible) | behind | 0 | 30 | destiny-rework, dungeon_editor, feature/minor-fixes, feature/outpost-manufacturing, feature/pos-manufacturing, staging |
| P1-F116 | [SySAttic/evemu_Crucible](https://github.com/SySAttic/evemu_Crucible) | diverged | 1 | 30 | dbupgrade, destiny-rework, dungeon_editor, staging |
| P1-F117 | [chuengeric2020/evemu_Crucible_ch](https://github.com/chuengeric2020/evemu_Crucible_ch) | behind | 0 | 1 | beta_v0.1 |
| P1-F118 | [rumpelstompskin/evemu_Crucible_Claude](https://github.com/rumpelstompskin/evemu_Crucible_Claude) | ahead | 41 | 0 | claude/wonderful-cori-veosq7 |
| P1-F119 | [mythkina/evemu_Crucible-1](https://github.com/mythkina/evemu_Crucible-1) | diverged | 3 | 243 | fix-108, staging |
| P1-F120 | [Black007Angel/evemu_Crucible-physics](https://github.com/Black007Angel/evemu_Crucible-physics) | ahead | 5 | 0 | — |

## Reproducibility and limitations

- GitHub search supplied visibility, `master` as default branch and archived flag. Per-repo GitHub compare supplied ahead/behind stats and tracked-file summaries. Branch inventory used branch-search query on each fork.
- No compile, database, client binary, game assets, runtime mining demonstration, or integration test performed during P1.
- Repository commits and branch pointers may move; exact snapshot SHAs still need pinning before P2 source assessment.
- Source-lineage and license review do not grant rights to proprietary game clients or assets. Personal offline use does not eliminate rights/terms considerations.

