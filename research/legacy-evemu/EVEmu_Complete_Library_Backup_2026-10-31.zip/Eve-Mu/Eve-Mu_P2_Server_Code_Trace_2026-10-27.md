# Eve-Mu — Server-Side Source Reconnaissance Checkpoint

**Date:** 2026-10-27  
**Phase:** P2 targeted source reconnaissance, NOT a completed audit, verified implementation, functional benchmark, or merge recommendation.  
**Source:** Public EVEmu GitHub repository and named forks. The original 10 GB historical client remains on the user's own machine, untouched. No client binary or content was transferred.  
**User-confirmed research purpose:** Personal educational study of space-MMORPG client/server architecture, with a limited private mining experience as the present experiment. The fork inventory is a **candidate map** for later careful review; the option of building an original, independently implemented game is a future alternative and does not mean automatically reusing proprietary game code/assets or abandoning the EVEmu analysis.

## Decision and method

1. The survey of 120 public fork names and the branch screening for the 80 default-branch-identical/behind forks identify candidate implementations **only**. A fork's branch label, commit count, touched-file list, README promise, or test-script name alone is not proof of functional value.
2. **What this checkpoint verifies:** files exist at the named repositories/branches; GitHub provided file object SHA identifiers; particular methods and code flows visibly exist and, for F42, server entry-point and market handlers reference the simulated economy.
3. **What it does not verify:** code compiles, dependencies/migrations load, client works, mining is correct, balance is coherent, save/reload succeeds, a test passes or a change is better than upstream.
4. **Future independent-game option:** Distill architectural concepts (authoritative state, entity/command handling, simulation ticks, economic ledgers, persistence, world zoning). Independently design original code, rules, UI, story, ships, names and assets if a separate game becomes desirable. Do not presume private educational use grants permission to redistribute or reuse proprietary game materials.

## Server code-path trace and inspection findings

### Upstream M0 (`EvEmu-Project/evemu_Crucible`, master)

- **Mining:** `src/eve-server/ship/modules/MiningLaser.cpp` (Git blob SHA `8443058efe2066c885fd11bb526d5262ad57b630`) implements `CanActivate`, cycle timing, ore amount and cargo calculations, asteroid quantity updates, crystal damage, and the exhaustion path. Crucial cross-file observation: when the rock is depleted, `TargetManager::Depleted(this)` calls `MiningLaser::Depleted(mMap)` to allocate the remaining ore among active miners *before* deleting the asteroid; the depletion path should not be judged by looking at `ProcessCycle()` alone. `TargetManager.cpp` directly documents this coordination.
- **Asteroids:** `src/eve-server/system/cosmicMgrs/BeltMgr.cpp` (blob `600b1651607dab625e4b6d6a67f06a51a1076fda`) includes spawn/check, `Load()` and `Save()` paths calling `ManagerDB::LoadSystemRoids` / `SaveSystemRoids`, plus respawn timers. The file's header comment says old saving/loading was disabled; **the currently visible functions contradict using that historical comment as proof of no persistence**. Current persistence behavior remains untested. Inspect database schema and lifecycle before claiming it works.
- **Refining:** `src/eve-server/station/ReprocessingService.cpp` (blob `a4ce9e1464efd2d7b16122186450ca262500ed31`) registers `GetQuote`, `GetQuotes`, `Reprocess`, and validates station access. Real ore-to-mineral inventory and tax computation needs test.
- **Markets:** `src/eve-server/market/MarketProxyService.cpp` (blob `1fec4391923616ed7f19af854af4ec0bdf4828fb`) registers order retrieval, `PlaceCharOrder`, modification/cancellation, and transaction operations. `MarketBotMgr.cpp` (blob `9be7ff937b4e134f8957062415319d3607817083`) provides bot order creation logic. Still requires accounting/inventory audit.

### F42 — `Mrinnovvation/evemu_Crucible`, `fixes/2026-10-15-combat-and-fitting`

- Different mining source (`MiningLaser.cpp` blob `0591c86d557d371d770390c038c3b4ffd71d8f85`) calls `AsteroidSE::RemoveQuantity(oreAmount)` and checks for an asteroid entity. There are also altered cargo accounting, notification and industrial-index/depletion paths. **Potentially relevant changes, not yet validated as corrections**. In contrast, upstream mutates `AttrQuantity` and adjusts radius directly.
- Different reprocessing file (blob `1f0f81af6392dd05e1211945226f3ecd471a30ed`) and market proxy (blob `29ae6871f144b149d7f52de9933aff6fd08baeb1`). Broad branch provenance derives from `rennr/evemu_Revised`; compare common ancestors and duplication before attributing all changes to F42.
- **Concrete simulation module:** `src/eve-server/market/sim/` contains `MarketSimMgr.cpp` (blob `9c4e84e2f2ac0a35baa1ea98baeea70f24b7fa89`), `SimActors.cpp` (`59f16cbc52eccb87facf5e97889e8428decf102d`), `SimEconomy.cpp` (`384e480f6017f54515cc194d312168b2522a3aed`), `SimWorld`, `SimLedger`, `SimProduction`, `SimLogistics`, `SimHaulers`, `SimChains`, etc. These contain code for virtual miners, consumers, finite stock/wallets, price calculations, shipments and production models.
- **Evidence it is wired, rather than merely an unused directory:** `src/eve-server/eve-server.cpp` calls `sMktSim.Initialize()` / `.Close()`; `EntityList.cpp` calls `.Process()` in the main game tick; `MarketMgr.cpp` calls methods including `AllowIntake`, `CanFill`, `OnSimBidFilled`, `OnSimAskFilled`, and `OnPlayerOrder`. `MarketSimMgr::Initialize` checks database readiness, loads calibration/state and seeds a new simulation if needed. `utils/config/eve-server.xml` provides `<marketSim>` controls including Enabled, EconomyScale, a time budget, tick timing, actors, logistics, hub station IDs, intake limits and ledger-audit behavior.
- **Critical unverified dependencies:** specialized `mktCal*` calibration tables, simulator database migration/state tables, order-backed ledger reconciliation, correct behavior on missing calibration, tick CPU/memory use, economy conservation, and interactions with Trader Joe/legacy NPC orders. The code warns legacy orders may be unbacked; this is a nontrivial integration risk. Any `README` assertions of a working universe must be qualified until independently reproduced.
- This fork was earlier categorized as default-branch identical/behind; the substantial development is on a nondefault branch. Never dismiss the fork using only `master`.

### F59 — `sargentscrufy/evemu_Crucible`, `phase-1-commerce`

- `MiningLaser.cpp` differs from upstream (blob `751ede42b524ffd84a17e740c6f39407eaf70d4a`), but the sampled mining/depletion implementation is largely the same. **Do not attribute significant ore extraction improvements merely to the differing file SHA.** Full diff needed.
- `ReprocessingService.cpp` blob **matches upstream** (`a4ce9e1464efd2d7b16122186450ca262500ed31`). F59's value here is primarily its reprocessing validation scripts rather than new reprocessing code.
- `MarketProxyService.cpp` differs (blob `039c516e4ba7d0beeb5cf382b42c168f661f52b0`); `MarketBotMgr.cpp` differs (`3d5de98b4ba30ea0c779bdd2448f46047397f62b`). `tools/simchars/` and `tools/simfleet/` include headless protocol bot infrastructure.
- **Executable test artifacts, not proven passes:** `tools/simfleet/reprocess_test.py` (blob `0c2d2c731f9662610f1e5084639ba8aac5eb29c8`) stages ore and invokes `reprocessingSvc`; `industry_chain_test.py` (`bd52189c559362da2b447b2499883d785c9da086`) stages ore and a blueprint, invokes reprocessing and a manufacturing job, and verifies material consumption; `market_fill_test.py` (`d51a8135a2d6405b911eb0c633f24e88f089ed5e`) contains actual assertions for wallet/hangar amounts, order partial fills, market price selection, order crossing and failure-on-no-match. Many scenarios **stage or manipulate database state directly** and therefore do not certify normal gameplay setup or a full mine-undock-dock-sell session.
- `tools/smoke-bot/smoke_test.py` verifies a login handshake, **not an entire game session**. `tools/simfleet/fleet_runner.py` runs external per-pilot hauler processes and restarts crashed loops; it is a research lead, not proof of scalable automated miner fleets.
- F59's progress report claims other QA and private gameplay sessions. These remain *author-reported*, not independently reproduced by us.

### F118 — `rumpelstompskin/evemu_Crucible_Claude`, master

- Mining laser, reprocessing service and MarketBotMgr blobs **match upstream**. `MarketProxyService.cpp` differs (blob `9c2af40b2a10a3aad10b03e6a979e54b373dbbfd`). Focus testing on actual changed market behavior, SQL migrations and wormhole changes; do not treat F118 as a proven mining/refining fix.
- `WormholeMgr.cpp` differs from upstream (F118 blob `57fef52f59b4da32040f24e1b038bff296ac76e5`; upstream source blob `ed160674d361855d008c0729eb1c006795c3f890`). Potential review flag: `GetRandomDestination()` indexes `destSystems[MakeRandomInt(0,destSystems.size()-1)]` without a visible empty-vector guard; **do not call it a confirmed bug without tracing invariants/callers**. This matters for the proposed restricted optional wormhole.

### F120 — `Black007Angel/evemu_Crucible-physics`, master

- Mining laser, reprocessing service and MarketProxyService blob SHAs **match upstream**. `MarketBotMgr.cpp` differs (blob `2de9b7023ebf226a06c41897d60739c5541995a3`). The bot writes buy orders with owner/station/quantity/price/escrow fields to MarketDB; verify actual stock and wallet backing rather than conflating posted orders with an economically complete buyer.
- `AddSystem` / `RemoveSystem` are explicitly placeholders. This fork is not proven feature-complete. Changes in inventory/physics/NPC AI require separate review.

## Current comparative understanding (do not confuse this with recommendations to merge)

| Area | Upstream baseline | F42 candidate | F59 candidate | F118 / F120 candidates | Test/evidence gap |
|---|---|---|---|---|---|
| Mining laser | Implements extraction, cargo and depletion paths | Asteroid entity quantity/update changes | Differs, but sampled core is similar | Same files as upstream | Ore conservation, simultaneous miners, zero/full cargo, depletion, drones |
| Asteroid belts | Spawn, load, save and respawn routines present | Need separate belt-file diff | Need separate belt-file diff | Need separate belt-file diff | Persist and reload belt after server restart |
| Refining | Reprocessing RPC implemented | Changed code | Same code plus test harness | Same code | Skills, yields, taxes, materials accounting |
| Order matching | Market service and market bot exist | Ledger-backed simulator hooks; custom calibration | Headless market transaction assertions | Targeted market changes | Unbacked orders, wallet/stock conservation, range matching, failures |
| Offline life | Basic server NPC/MarketBot | Statistical supply-chain actors integrated into 1Hz loop | External protocol-driven bots | Market bot / NPC candidates | CPU/RAM scaling, simulated activity without client, crash recovery |
| Wormholes | Existing manager | No evidence of new change from this comparison | Not yet assessed | F118 manager differs | Reachability rules, empty destinations, collapse, save/load |

## Planned acceptance gates — future work, not completed

**Gate S1: sources/build:** pin head SHAs for target branches, trace ancestry of F42 versus `rennr/evemu_Revised`, inspect licenses, schema and dependencies, reproduce clean Windows x86-64-compatible builds or provide a clear environment blocker. No Docker/WSL2 assumption for the intended standalone target (temporary research environment can differ if documented).

**Gate S2: isolated simulation tests:** unit/integration tests for ore accounting on 1 ore left, aborted module cycle, several miners plus mining drones, full cargo, rock deletion, belt save/reload; then station refining yields/inventory, then market purchase/sale settlement, orders and rollback/error cases. Ensure ownership, balance and order conservation.

**Gate S3: game loop:** local client (future user-authorized session) or protocol test client: login → undock → warp to belt → target and mine → fill cargo → dock → reprocess → sell ore/minerals → restart server → verify persisted balance/inventory/belts. Mark each step individually and identify mocked/staged prerequisites.

**Gate S4: miniature world:** one high-sec economic hub, a medium-sec frontier, null-sec frontier and optional wormhole reachable exclusively from medium-sec. Prove map/gate restrictions, client static-data behavior, transport and NPC encounter behavior. Only then select integration milestones.

## Next sensible research action

Detailed per-file diff/provenance and test fixture design for **F42 and F59**, with limited checks on F118 (wormholes/market), F120 (market bots) and F106 (belt rats). Do not blindly merge whole forks or present advertised features as tested. Client binary analysis deferred at user's request; no client upload.
