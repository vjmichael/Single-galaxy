# Eve-Mu — ED-01 Desktop Edition: One-Click Windows x86-64 Architecture and Delivery Plan

**Decision status:** ACCEPTED BY USER, 2026-10-27.  **Implementation status:** PLANNED; not a compiled, installed, or tested product.  **Platform:** Windows x86-64 only for the first release. **Mode:** offline-first private single-PC universe. **Scope:** launcher/orchestrator plus packaged EVEmu server and database; not a new game engine. **Source-of-truth:** pinned EVEmu/Crucible static data and migrations; verified source and reproducible build artifacts.

## 1. The decision

Eve-Mu Desktop Edition must permit a nontechnical user to install once, select a separately obtained compatible historical client when needed, and click **Play**. The app shall prepare and manage its server, embedded portable MariaDB installation, game schema, market bootstrap, database credentials, and server/client lifecycle with no terminal, Go, Git, Docker, WSL, separately installed database or manual SQL required **on the user's machine**. Developer/CI systems may use a full build toolchain.

**Explicitly NOT approved or demonstrated:** bundling proprietary EVE client files; abandoning MariaDB for SQLite; exposing private single-PC servers to the public network; running databases as global Windows services; deleting or migrating the user's already installed MariaDB; selecting a permanent upstream fork; treating previous isolated market tests as native server integration passes.

**Historical EVE client:** Detected or selected once by the user. Do not alter original client files in place without user-controlled backups or an isolated launch profile. If the compatible client is missing, show a clear, nonterminal first-run prompt, not an inaccessible 'Ready to Play' claim.

## 2. Architecture

```
EveMuLauncher.exe                   (GUI, single-instance, Windows x86-64)
  |-- Installation/manifest validator (signed release manifest, hashes, versions)
  |-- First-run coordinator (idempotent, step journal/checkpoints)
  |-- Process supervisor (start, probe, stop, restart, log, port conflict)
  |-- Database controller (portable MariaDB; user-owned local data; backups)
  |-- Schema/migration controller (prebuilt EVEDBTool or equivalent packaged runner)
  |-- Market readiness checker (backed asks and bids before Play)
  |-- EVEmu server supervisor (local process, readiness probe)
  |-- Compatible-client path detector and launch-profile manager
  |-- UI (Play, Stop, Repair, Backup, Restore, Advanced Logs)
  `-- Upgrade manager (version pins, backups, reversible install stage)

%ProgramFiles%/Eve-Mu/ or user-writable install root
  Launcher/  Server/  MariaDB/  Resources/base-db/  Resources/migrations/

%LOCALAPPDATA%/Eve-Mu/
  Universes/default/Database/     (never deleted by normal uninstall/update)
  Universes/default/Config/       (machine-generated config, no passwords in plain logs)
  Universes/default/Backups/      (verified snapshots / logical dumps)
  Logs/  State/  ClientProfiles/
```

**Database choice:** bundle tested Windows MariaDB ZIP binaries and launch `mariadbd.exe` privately on demand, without registering a system-wide Windows service or requiring administrator rights for routine gameplay. MariaDB documents ZIP-based installation (`mariadb-install-db.exe` plus `mariadbd.exe`). Use a private data directory, least-privileged account, loopback-only transport (or named pipe if compatible), unique instance identity, and collision-resistant port selection. Validate no external interface is listening and no other MariaDB instance is affected. Server binary version must be independently certified against F42 migrations; do **not** assume MariaDB 13.0.2 compatibility without tests.

**Secrets:** random per-universe DB credentials; secure in Windows-protected storage (e.g. DPAPI/Credential Manager) and never emit to logs; do not pass secrets casually on process command lines. Ensure first-run bootstrap can initialize MariaDB without exposing passwords and that recovery survives power interruption.

**Source:** F42/Revised native market simulator provides `World::Seed`, `World::Requote`, `RunUntilIdle`, gateway, escrow/inventory ledger and backed `mktSimOrder`. Reuse existing components. The starter-market acceptance gate must check both sides of the order book and the NPC backing in MariaDB. The old `seed_market.sql` creates legacy rows with no sim ledger backing and is NOT an acceptable substitute.

**Economy:** experimental default 20x reduction in market monetary reference prices (configurable 10x/20x/50x etc), with coordinated changes to purchasing power, costs, minerals, ore buy quotes, refine yields, fees, and rewards; avoid pricing arbitrage/negative prices. Persistent universe save records its pricing policy/version. Scaling changes require explicit migration or new-universe flow, never implicit repricing of an existing save.

**Universe:** small high-sec starting trade/mining hub, medium-sec frontier, null-sec area, wormhole accessed from medium-sec; staged as a configuration of existing data rather than destructive removal of the full historical source. First-run validation confirms stations/system IDs and routes.

## 3. Milestones and mandatory acceptance gates

| Milestone | Deliverable | Required gate |
| --- | --- | --- |
| **ED-M00 — Baseline and packaging contract** | Pin historical server fork/commit, SQL data and migrations, MariaDB version, runtime dependencies, installer layout, file hashes and license inventory. Document client build compatibility. | Manifest reproducibly identifies inputs; complete required assets obtainable; no silent internet dependency. |
| **ED-M01 — Native server build proof** | Build and launch actual EVEmu core on Windows x86-64 with a test MariaDB instance. Build or prebuild the schema/migration runner in CI. | Hello/health or real startup observed; reproducible fresh-host build; crash/error logs captured. |
| **ED-M02 — Desktop launcher shell** | Minimal standalone Windows GUI, Play/Stop state machine, progress, logs, friendly errors and explicit Repair. | Launch/stop dummy server from GUI, no console window; restart recovery; non-admin test. |
| **ED-M03 — Portable private MariaDB** | Ship a tested portable DB payload; initialize/start/stop only the private instance; create per-universe roles, secure credentials and local data. | Fresh non-admin Windows machine works without system MariaDB; existing MariaDB service not touched; port conflict handled; no public listener. |
| **ED-M04 — Zero-click schema and SDE import** | Package unmodified EVEmu base `.sql.gz`, baseline migrations and F42 market-calibration migrations. Prebuilt migrator plus checkpoint journal and progress UI. | Fresh DB contains verified `invTypes`, `staStations`, `mktOrders`, `mktCal*`, `mktSim*`; critical transactional tables are InnoDB. Injected interruption can recover without loss or double-import. |
| **ED-M05 — Guaranteed first-login economy** | Apply verified item catalog, portable bootstrap adapter and 20x price profile through native market simulator's stock/escrow path. | Before Play, starter equipment and ship sell orders + funded Veldspar/mineral buy orders exist at configured hub; no unfunded NPC orders; restart and duplicate launch safe. Real native buy/sell/rollback test passed. |
| **ED-M06 — Managed EVEmu universe** | Spawn and monitor server with chosen mini-universe configuration, health timeout, error recovery and graceful process cleanup. | Startup/undock/mining/market round trip can be completed when compatible client exists; crash doesn't corrupt save; multi-process concurrency prevented. |
| **ED-M07 — Historical client attachment** | Find or select existing compatible client, verify supported build, create isolated configuration, launch/restore without overwriting user's source client. | First setup only requests client folder if not detected; no client redistribution; one-click subsequent launches; missing/wrong client handled clearly. |
| **ED-M08 — Save, repair, update, backup/restore** | One-click backup/restore and installation repair; atomic updater with signed binaries, metadata and DB version gate. | Restore tested from real backup; no DB file copy while server running; migration preceded by backup; power-loss/update rollback exercised; uninstall preserves universe unless user explicitly deletes data. |
| **ED-M09 — Release and accessibility QA** | Installer or per-user portable package, logs/export, diagnostics, license notices, offline deployment, clean-VM matrix. | New nontechnical user: install, choose client once, Play; no Git/Go/SQL/MariaDB prerequisites; Windows Defender / UAC behaviors tested; no network access required for startup. |

These stages are development dependencies, not a claim that the application is ready. Each stage produces a reproducible Windows test package and a binary pass/fail report. Do not advance milestone gates solely on models, SQLite, fake IDs, or paper reviews.

## 4. Launch state model

```
NOT_INSTALLED -> CHECKING_FILES -> INITIALIZING_DB -> APPLYING_SCHEMA
 -> LOADING_MARKET -> CHECKING_SERVER -> CLIENT_SETUP_REQUIRED (if needed)
 -> READY -> PLAYING -> STOPPING -> READY
Any state -> ERROR_RECOVERABLE (Retry / Repair / Export Logs)
Any persistent-data incompatibility -> BACKUP_REQUIRED or MIGRATION_REQUIRED
```

UI always distinguishes “server ready” from “client available” and “market ready.” Never show green Play when database is empty, SDE IDs unverified, starter market has only unbacked orders, or server process isn't responding. Repair operations require explicit user confirmation if they risk altering saved universes. Progress can be read from durable events; the GUI does not depend on parsing terminal strings.

## 5. Safety and recovery policies

- Single-writer lock per universe; a second launcher shows status rather than launching a second database.
- Database migration journal is durable and restartable. SQL DDL migrations may autocommit: do not falsely assume one giant SQL transaction can roll back schema changes.
- Before potentially irreversible migrations: verify backup and disk space; atomically stage new binaries; switch release only after health checks; preserve previous binary set.
- Back up using MariaDB-aware logical backup or stopped/cold snapshot (not a blind copy of a live InnoDB data directory).
- Preserve source `invTypes`/`invTypeMaterials`/`staStations` as read-only historical inputs. User economy overrides live in separate configuration/migration tables, not destructive edits of upstream SDE.
- Support offline launch by default; optional explicit opt-in updates after the base product works.
- Limit network listeners to local host for private play; default-off LAN or multiplayer access is a separate future milestone with its own security analysis.
- Redistributable server, database, and build runtimes require license/notice inventory and reproducible provenance. Client is user-provided.

## 6. Current observed developer-machine status (user screenshot, 2026-10-27)

- Windows service **MariaDB** running; 13.0.2 MariaDB server accessible on local port 3306.
- `evemu_test` database exists and had **0 tables** after creation; no EVEmu schema installed yet.
- Git for Windows installed (`git version 2.56.0.windows.4`).
- `go version` failed: Go is not installed or not on PATH. **This is not a blocker for future players.** Go may be used by a developer/CI to precompile EVEDBTool; avoid making the end-user install it.
- Earlier isolated 75 market checks are not proof of native Windows server, real MariaDB fills or game-client readiness.
- Do not alter the user's existing MariaDB service/`evemu_test` or GitHub repositories without targeted authorization; test launcher against separate disposable universe database when available.

## 7. Recommended immediate engineering task (ED-M00 -> ED-M02 spike)

**Create a minimum viable launcher with a fake/placeholder server first, then swap in a real packaged EVEmu build.** Specifically: define a signed/hashed manifest for Server, MariaDB, base SQL and migrations; implement `EveMuLauncher.exe` process supervisor, startup state journal, read-only diagnostics, and a test-double target. This requires no client and no new software installed on the user's PC. Next, get a verified native EVEmu x86-64 build and the complete historical SQL dump in CI; only then wire DB and actual server lifecycle.

Completion report must state precisely which scenarios were run on clean Windows, with real MariaDB, with original EVEmu code and with actual client versus test doubles. Make the GUI demonstrate failed and successful states rather than hiding blockers.

## References (verified October 27, 2026)

- Official MariaDB Windows ZIP guidance: https://mariadb.com/docs/server/server-management/install-and-upgrade-mariadb/installing-mariadb/binary-packages/installing-mariadb-windows-zip-packages
- MariaDB Windows initialization (`mariadb-install-db.exe`): https://mariadb.com/docs/server/server-management/install-and-upgrade-mariadb/installing-mariadb/installing-system-tables-mariadb-install-db/mariadb-install-db-exe
- EVEmu/Crucible base SQL: https://github.com/EvEmu-Project/evemu_Crucible/tree/master/sql/base
- EVEmu F42 selected research pin (not final integration fork): `Mrinnovvation/evemu_Crucible`, branch `fixes/2026-10-15-combat-and-fitting`, commit `c88496f6f08a6488b57bbe9e3f5e3a61fd2da092`.
- F42 schema and database installer: `sql/README.md`, `dep/evedbtool/`, `sql/migrations/20261013130100-market-sim.sql`, `20261015130100-market-fill-innodb.sql`.
- Eve-Mu prior documents: `/Eve-Mu/Eve-Mu_Master_Research_Plan.md`, S2-D and S2-E market-integration bundles.


## 8. ED-01A — Strict single-launcher, no-Docker consumer experience (approved 2026-10-27)

**Superseding UX clarification, explicitly approved by user:** Eve-Mu Desktop Edition is **one user-facing application**, **one Windows installation/package**, **one normal desktop shortcut**, and **one Play action**. This is not a developer server manager and must not recreate the upstream Docker Compose/CLI workflow behind a graphical wrapper. Ordinary players must not choose which backend to launch, run SQL scripts, use PowerShell, open a terminal, or separately download/install Git, Go, MariaDB, Docker, WSL, a server manager, or other developer tools. The first-time selection of an independently obtained compatible historical client is an explicit, documented exception; software whose distribution is not authorized must not be silently packaged.

**Single launcher means one *user-visible entry point*, not technically one OS process.** `Eve-Mu.exe` (working name) owns the full lifecycle of the bundled native EVEmu server, portable isolated MariaDB process, prepared database migrator, market-readiness gate, and optional compatible client. These remain supervised child processes/components, not separately installed user applications or Windows services. No separate desktop database utility is required to play.

**Nonnegotiable release contract:**

1. Fresh Windows x86-64 host with **no developer tools and no Docker**: install the Eve-Mu application once; choose/locate compatible separately supplied client at most once; click **Play**. No administrator privileges for normal play (installer mode may require elevation only when unavoidable; provide per-user mode).
2. On first Play, the launcher checks/pins packaged assets, creates only a private per-universe data directory, provisions the portable bundled database, runs pinned base schema and migrations from within the app, applies verified market configuration, starts the server, checks all prerequisites, and then starts the client. Status/progress and actionable failures are shown in the same GUI.
3. On subsequent Play, reuse existing local data; avoid duplicate item or money seeding, double-started backend services, and unnecessary schema reinstall. Close/Stop performs graceful client/server/database shutdown with timeouts and recoverable diagnostics.
4. No Docker CLI, Docker Desktop, containers, `docker compose`, WSL, or externally installed MariaDB required on the consumer machine. The **primary native Windows build and packaging process must also not depend on Docker**, though optional independent CI experiments need not dictate user installation.
5. Repair, Backup, Restore, Settings, and View Logs are **functions within the same launcher**, not new standalone applications. Any advanced administration remains an optional diagnostics view and is never part of normal onboarding.
6. Updates do not delete personal universes; installer does not alter an existing system MariaDB installation/service. Server binds loopback by default. Privileged operations and destructive repair require explicit, understandable confirmation.
7. The release criterion is a clean-VM, offline-from-startup user test, recorded on video or as a reproducible test transcript: **launch the single shortcut, configure the client once if needed, click Play, reach an actual working market, purchase an item, and sell ore**. There must be no hidden manual CLI/SQL step.

**Milestone implications:** ED-M02 is renamed *Single-Launcher GUI and Lifecycle Shell*; ED-M03/ED-M04 are wholly launcher-owned; ED-M05 must be completed before Play is shown as ready; ED-M07 is a client-selection screen within that launcher; ED-M09 must explicitly test absence of Docker, PowerShell, Go, Git and system MariaDB on a fresh Windows x86-64 VM. Packaging must not create separate day-to-day app shortcuts for server or database. 

**Current status:** Design decision accepted and documented; no final launcher or Windows installer has been built or tested. The user's installed MariaDB and `evemu_test` are development aids only, not runtime prerequisites for the finished product.
