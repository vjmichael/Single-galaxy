# Eve-Mu S2-D — Static-data crosswalk and market-bootstrap adapter

Date: 2026-10-27. **Private educational research; source inspection + an independent acceptance-test prototype. Not a running EVEmu server.**

## Scope and user decisions

- Use the EVEmu Crucible repository's own SQL base tables as the immediate source of truth, with historical CCP/EVE data as supplemental evidence when required.
- Avoid artificial scarcity or an empty station market on the first login to the compact single-player universe.
- Reduce EVE prices substantially: the first *experimental* setting is a 20x price divisor. Preserve equipment/mineral/refining economic relationships; don't merely slash some market prices while leaving balances and services unchanged.
- Original historical 10GB client remains read-only on user's own PC, untouched; this phase uses only public server-side source files.

## Directly inspected EVEmu base SQL: confirmations

Repo `EvEmu-Project/evemu_Crucible`, branch `master` (observed head `f55b488a006e3090470d3b481aee47a1d7a0dade`). All decompressed via the read-only connected GitHub API; the table blob SHA is a Git object identifier, not an executable build pass.

| SQL table | blob SHA | Outcome |
|---|---|---|
| `staStations.sql.gz` | `54125746dda0192331c71f59d0a162d95328c0ed` | Six complete original station tuples inspected; IDs, systems, regions, security and refinery fields extracted. |
| `invTypeMaterials.sql.gz` | `130c25ac3353cfb5bf23dfe19977522c70aab71b` | Reprocessing material tuples inspected for five starter/frontier ore IDs. |
| `invGroups.sql.gz` | `06a72b967b707a2990142810830d21b50a878d0f` | Verified decompressed CREATE TABLE and inventory-group records; no matching `invTypes` row proof inferred from it. |
| `invTypes.sql.gz` | `dbc7250a4ea22e99f5722fc1be9b18c37621b866` | Blob exists, but content was empty when requested via connected GitHub file action (repository size limitation). **Thirty historical candidate item rows, published and market-group status, portion sizes and basePrice are NOT verified against this dump in this session.** |

**Station tuples confirmed:**

- `60003760` Jita IV–4 Caldari Navy Assembly Plant; system `30000142`, region `10000002`, security `0.945913`, refinery efficiency `0.5`, station take `0.05`.
- `60008494` Amarr VIII (Oris) Emperor Family Academy; system `30002187`, region `10000043`, security `1.0`.
- `60011866` Dodixie IX–20 Federation Navy Assembly Plant; system `30002659`, region `10000032`, security `0.868407`.
- `60004588` Rens VI–8 Brutor Tribe Treasury; system `30002510`, region `10000030`, security `0.894582`.
- `60005686` Hek VIII–12 Boundless Creation Factory; system `30002053`, region `10000042`, security `0.549668`.
- `60014137` Ibaria III Thukker Mix Warehouse; system `30000053`, region `10000001`, security `0.730979`.

These are legitimate historical stations; Hek and Ibaria are **not** null-sec or low-sec stations, so do not invent such a classification to fill Eve-Mu's future frontier/outpost layout. Jita is the provisional verified high-sec hub only.

**Verified ore material rows, per recipe/batch (portion size still unverified):**

- Veldspar `1230` → Tritanium `34` × 1000.
- Scordite `1228` → Tritanium `34` × 833 + Pyerite `35` × 416.
- Pyroxeres `1224` → Tritanium `34` × 844, Pyerite `35` × 59, Mexallon `36` × 120, Nocxium `38` × 11.
- Plagioclase `18` → Tritanium `34` × 256, Pyerite `35` × 512, Mexallon `36` × 256.
- Kernite `20` → Tritanium `34` × 386, Mexallon `36` × 773, Isogen `37` × 386.

**Authoritative follow-up:** run `build_starter_catalog.py` on the small public `invTypes.sql.gz`, `staStations.sql.gz` and `invTypeMaterials.sql.gz` files. It extracts and cross-checks all 30 candidate IDs; a missing, unpublished or nonmarketable *essential* SKU prevents catalog issuance. The SQL dump can be checked on Windows without reading/uploading any files from the game client. Its returned sha256 fingerprints are recorded to identify the exact data used.

## Starter market / pricing adapter (implemented in isolated prototype)

Files: `build_starter_catalog.py`, updated `market_bootstrap.py`, `seed_policy.json`, source candidates CSV, `check_market_readiness.sql` and tests.

**Mandatory first-login orders** (candidate TypeIDs requiring final invTypes verification): at the verified Jita hub: sell Bantam `582`, Miner I `483`, Survey Scanner I `444`, Expanded Cargohold I `1317`; buy Veldspar `1230`, Scordite `1228`, Tritanium `34`. Civilian Miner `3651` is not required as a market SKU pending historical marketability validation; it may instead be granted as a starter item if appropriate.

**Policy:** normal ask prices are `invTypes.basePrice / 20 * 1.10`, other bid prices are `/20 * 0.90`, rounded to whole cents (minimum 1 cent). These are static metadata prices, not actual 2012 market histories. Manually reviewed alternate price anchors require positive amount, explicit review and HTTPS source URL; otherwise fail closed. Ore bids **do not** use the ore basePrice. They use verified output material quantities and mineral anchors, divided by the ore's actual `invTypes.portionSize`, multiplied by a conservative refinery-yield proxy `(station efficiency * (1 - station take))`, a tunable yield multiplier and an 0.80 ore-bid trade haircut. Actual skill/standing effects, refining quality and market arbitrage are still untested.

On successful verification, catalog kind `evemu-sde-validated-prototype` contains real TypeIDs and the selected real station; it is accepted by an updated **SQLite-only** version of the S2-C first-login market bootstrap. The bootstrap's existing one-time stock and escrow reservations, atomic settlement, stale-order checks and restart invariants are retained. No EVEmu MariaDB tables are modified, and no server fork was pushed or merged.

**Important price scaling follow-up:** Do not let a 20x item-price reduction create a 20x real player purchasing-power windfall. Initial wallet, NPC income, mission rewards, sales taxes, refining fees, and mining time must be balanced coherently. A 5,000 ISK illustrative starting wallet is not yet a validated live-server wallet policy; starter ship grants/equipment affordability remain design choices.

## Tests actually executed

- **42/42 unittest checks passed** in local Python 3.13. The suite includes the original 26 S2-C tests plus 16 new parser/catalog/price/rollback/restart checks.
- The 16 new tests generate explicitly **fabricated** invTypes/staStations input dumps in temporary directories with actual candidate ID numerals. They prove that a valid small SQL input leads to a real-ID SQLite bootstrap and buy/sell loop, and that false publication flags, missing items, invalid stations, missing base prices/recipes or forged proof structures block output. The ore-price sensitivity test checks that a mineral-price change propagates to the affected ore quote. They are **not** a pass of all 30 original historical `invTypes` rows.
- Actual SQL station and material records were inspected through the GitHub connector; the direct production `invTypes` row check was blocked by the file-size output constraint.
- **Zero** native EVEmu integrations, MariaDB boots, actual in-game market purchases, or client runtime tests were completed in this checkpoint. The earlier 15 real-server acceptance cases remain open.

## Native code investigation / un-applied patch proposal

F42/Revised's `MarketSimMgr::Initialize` invokes `World::Seed` before `World::Start`, which schedules initial dirty cells across up to 60 seconds. The existing GM command `/mktsim seed` invokes `Seed` after the scheduler is running, `RunUntilIdle` to process due work, and the production `MarketSimDB::Flush`/gateway. The proposed patch in the ZIP reproduces that second scheduling step **on fresh startup only**. It has **not** been applied, built, benchmarked, or verified as a complete readiness guarantee. It may cause broad order-writing workload in the unpruned universe.

A production implementation must (1) apply calibration and sim migrations, (2) select a compact station/map topology, (3) create inventory and escrow in the actual ledger, (4) post essential orders immediately, (5) confirm each required order is truly live and fillable via `MarketSimMgr::CanFill`, (6) reject login or enter a visible maintenance state when the required catalog is not ready, (7) avoid idempotency/restart double issuance, and (8) run complete client-to-MariaDB buy/sell/restart tests. Old `seed_market.sql`, `seed_station_market.sql` and random Trader Joe rows are **not** sufficient, and directly inserting into `mktOrders` is inappropriate for the ledger-backed F42 engine.

## Next gates

1. Execute the verifier against the **actual** compressed `invTypes` dump; inspect missing/unmarketable IDs, `portionSize` and basePrice, and revise offer selection. No synthetic test outputs substitute for this step.
2. Audit prices using actual mineral recipe outputs and low-scale trading; set starter grant/wallet and station roles with genuine small-world map compatibility.
3. Compile and run a **native** F42/Revised market simulator harness or full server, with the proposed startup code reviewed and benchmarked.
4. Add native first-login SKU/backing barrier and test fresh seed, partial fills, restart, depletion/restock and fault-injected item creation with MariaDB.

**Links**: [EVEmu SQL base](https://github.com/EvEmu-Project/evemu_Crucible/tree/master/sql/base); [2012 Crucible SDE forum discussion](https://forums-archive.eveonline.com/message/1064377/); [CCP current SDE docs](https://developers.eveonline.com/docs/services/static-data/); [EVE University SDE table guide](https://wiki.eveuniversity.org/Static_Data_Export).
