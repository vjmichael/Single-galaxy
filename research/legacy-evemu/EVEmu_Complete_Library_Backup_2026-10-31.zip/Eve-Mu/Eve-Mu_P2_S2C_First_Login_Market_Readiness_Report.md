# Eve-Mu — S2-C First-Login Market Bootstrap and Readiness

**Date:** 2026-10-27  
**Scope:** Public EVEmu code review and a new, isolated executable bootstrap prototype with automated tests.  
**Target world:** Compact hub + medium-security frontier + null-security resource outpost; optional wormhole deferred.  
**Original historical client:** Not accessed or transferred.  
**Source repositories:** Inspected read-only. No production EVEmu repository or database was modified.

## Decision implemented at prototype level

A **new character must not encounter an empty market**. The first-login readiness gate must require real *ask* offers that deliver starter hulls and equipment and *bid* offers that actually have the resources to pay for starting ores/minerals. Mere SQL order rows do not suffice. Seed a bounded catalog before opening character/session entry; check it, fail closed with actionable diagnostics, and only then enable first login.

For the small-world experiment, the initial market should be predictable and purposeful, not random or sized like the original Tranquility universe. A market created at startup should stay durable and **not mint more goods or money on every restart**. Later restocking is a distinct, bounded economy feature.

## Source review: original EVEmu and leading candidates

**Baseline EVEmu `EvEmu-Project/evemu_Crucible`, master, commit** `f55b488a006e3090470d3b481aee47a1d7a0dade`:

1. `sql/seed_and_clean/seed_market.sql`, blob `6d8c36ba1d143af562160e3d24d1b178f4d307e9`, inserts broad market order rows with a fixed Windows FILETIME `132478179209572976` (2020-10-22 05:25 UTC), 250-day duration and item quantity 550. Its nominal expiry was **2021-06-29 05:25 UTC**; not appropriate for contemporary fresh seed orders. It uses random station selection, not a guaranteed starter catalog. SQL order existence is not proof of reserved inventory/escrow.
2. `sql/seed_and_clean/seed_station_market.sql`, blob `11b3f956403d8d4ac19673623d7bdc80798889c6`, targets one hard-coded station and likewise uses a fixed creation timestamp. Its comment estimates ~11,004 orders per station, far above our needs. It is not a guaranteed stocked/stable starting market.
3. `src/eve-server/market/MarketBotMgr.cpp`, blob `9be7ff937b4e134f8957062415319d3607817083`: `Initialize` sets `m_nextRunTime = now + DataRefreshTime`; its first automatic refresh is delayed; item selection is random; it writes orders using `MarketDB::StoreOrder`. `ForceRun` exists but is not an automated first-login readiness barrier. Random placement cannot guarantee essential items.
4. `src/eve-server/market/NPCMarket.cpp`, blob `b2f2eefc89a107a55316257e744b5e3a16460909`: older XML seeding references `market_orders` rather than `mktOrders`. Its startup call in `eve-server.cpp` is commented out. This is not an established current seeding pathway.

**F59 `sargentscrufy/evemu_Crucible`, `phase-1-commerce`, commit** `0fa6cac5422902d28c29358d694dd7369b9eb407`: keeps largely the same delayed/random MarketBot startup pattern. Its `tools/simfleet/market_fill_test.py` adds useful market-settlement assertions, but stages orders directly. It should be reused as a regression-test reference, not used as proof of first-login market availability.

**F42 `Mrinnovvation/evemu_Crucible`, `fixes/2026-10-15-combat-and-fitting`, commit** `c88496f6f08a6488b57bbe9e3f5e3a61fd2da092`, sharing substantial code lineage with `rennr/evemu_Revised`:

1. `MarketSimMgr.cpp` (blob `9c4e84e2f2ac0a35baa1ea98baeea70f24b7fa89`): `Initialize()` checks `TablesReady`, calibration tables and nodes. Fresh startup calls `m_world->Seed(now)`, `Start`, `PostMissingVendorOrders` and `FlushOrders`. It logs that initial books can take the configured cold-cell time to fill. No guaranteed starter-item readiness barrier was located.
2. `SimWorld.cpp` (blob `fd3ec9298cfde0a6fe42499b0070bf48c032f689`): `World::Seed()` fills target stock and working money with named ledger faucets, marks cells dirty and schedules processing; `Start()` queues dirty cells at `now + (jitter % 60)` seconds. That is not necessarily immediate for all required types. Admin `/mktsim seed` calls `Seed`, `RunUntilIdle`, and `Flush`; this is a useful integration reference, **not an automatic production-ready boot path**.
3. `MarketMgr.cpp` (blob `09752e240ec50cb1a812e8ac9ac5957f559ba099`): `IsBackedNpcOrder()` calls `sMktSim.CanFill(...)`, explicitly rejecting unbacked legacy NPC seed/Trader Joe orders for actual settlement. Directly inserting NPC rows into `mktOrders` without integrating the simulator is therefore unsafe/incompatible.
4. The market simulator's sample config lists several original EVE trade hubs, `RegionalNodes=auto`, potentially hundreds of thousands of orders, and depends on `mktCal*` calibration/migration data. A restricted local universe requires *deliberate station/type scoping*, migration validation and a bounded resource budget.
5. The included `src/eve-market-sim/CMakeLists.txt` defines an offline `eve-market-sim` harness with market-match, ledger, and economy tests. Its presence is source-verified; the entire harness was not built here. The existing target does not itself demonstrate first-login availability of a curated starter set.

**Interpretation:** F42/Revised supplies the stronger architectural base for *backed* NPC supply and demand. Its startup lifecycle needs an additional readiness contract. Avoid mixing the original broad seed scripts into F42 without a ledger-backed migration.

## Prototype built and executed — independent fixture, NOT server integration

Files: `market_bootstrap.py`, `starter_catalog.json`, `test_market_bootstrap.py`, `tests.log`, `bootstrap_run.log`. Python 3 standard library and in-memory or file-backed SQLite only. No external dependencies, EVE client files or MariaDB instance.

Catalog fixture is explicitly synthetic, containing **3 test station IDs**, **9 starter-item asks**, **5 ore/mineral bids** (14 orders). Example goods include a mining frigate, miners, scanner, cargo equipment, shield booster, skillbook and ammunition. Example bids cover ore/minerals. **These IDs, names, prices, wallet sizes and starting quantities must not be imported into EVEmu.** A later static-data crosswalk will replace them using actual `staStations`, `invTypes`, fitting/skill and market metadata.

The bootstrap prototype:
- Explicitly seeds a declared catalog, no random item selection.
- Reserves seller stock and buyer money and verifies those reserves against outstanding order quantities.
- Uses a single DB transaction and a stable seed key for first issue; tests demonstrate rollback on simulated interruption.
- Gives orders current timestamps and a bounded 90-day expiration policy, checks temporal validity, and does **not** extend expiry merely because the server restarted.
- Checks each required order, side, owner, station, type, price, quantity, time window and backing before marking a world ready.
- Runs transactional buy and sell settlement tests; wrong-station trades, underfunded players, missing ore and attempted oversells are rejected.
- Deliberately fails readiness after starter stock is exhausted rather than silently minting a new order on restart. Future restocking requires its own rules.

### Test evidence

```
python -m unittest -v test_market_bootstrap
Ran 26 tests in 0.056s
OK
```

The measured **0.71 ms** fixture seeding time is an in-memory SQLite result for only 14 prototype orders on this environment, **not a valid throughput estimate for the production MySQL/MariaDB engine or the F42 simulation**. Source compilation and server startup were not performed in this checkpoint.

`bootstrap_run.log` output reports a ready market with 3 stations, 14 offers, 9 asks, 5 bids, and 8,910,000 integer cents reserved behind the bids. The prototype buyer and seller accounts are fixture-only.

### What this DOES NOT validate

- No live `mktOrders` rows or actual EVE market service methods were changed or called.
- No MariaDB/MySQL `mktSim*`, `mktCal*`, `staStations`, `invTypes`, `account` or `entity` tables were connected.
- No real IDs, fit-compatible equipment, player starting wallets, broker fees, taxes, market caches, NPC vendor contracts or station scope have been validated.
- No EVEmu server, executable client, client UI or in-game session was started.
- Synthetic accounting does not automatically reproduce F42/EVEmu cash transfer and inventory behavior.

## Recommended production integration gate — S2-D

1. **Choose actual playable station IDs.** One high-security hub, medium-sec outpost, null-sec optional trading node; verify `staStations` region/solar-system references and client map restrictions before changing any static data. Preserve original IDs where possible.
2. **Verify actual item catalog.** Resolve startup hull, miners, scanner, cargo and shield equipment, books, basic supplies, and ore/mineral bids through `invTypes`, group/category, skill/fitting requirements and price references. Every required SKU has a clear side, station, minimum quantity and affordable price.
3. **Prove engine-backed issuance.** Prefer F42/Revised `World::Seed`, `RunUntilIdle`, `ServerMarketGateway`, and `MarketMgr` integration, or a narrowly scoped native C++ bootstrap using those APIs. Do not issue direct fake NPC orders disconnected from `mktSimOrder`, `mktSimInventory` and `mktSimActor` / escrow. Validate persisted balances and seeded ledger faucets.
4. **Add bounded synchronous boot readiness.** Before accepting first in-world character/session entry, initialize data, seed the bounded allowed nodes and types, process due starter quotations, flush and verify required asks and bids with the same `CanFill` backing rules as live trading. On missing calibration or incomplete book, stay not-ready and log missing station/type/side/reserve; optionally allow administrative repair, not silent login to an empty market. Bound CPU/time and measure startup cost.
5. **Do not silently reseed on every restart.** Persist bootstrap version and scope and audit one-time asset/money creation. Support bounded, supply-backed future restock separately; retest expiry, depleted orders and resuming after crashes.
6. **End-to-end tests:** (a) database boots empty; (b) bootstrap creates small market; (c) real market RPC lists expected orders before pilot login; (d) character can afford and buy beginner miner; (e) character mines and sells ore into a backed bid; (f) item, funds and escrow conserved, taxes/fees validated; (g) restart preserves transactions and no duplicated stock; (h) missing migration/depleted stock/failed DB commit blocks readiness; (i) 2 pilots cannot buy last item twice; (j) hub and frontier scope / client-visible market cache verified.
7. **Keep source provenance.** First use F42 native economy infrastructure as reference. Decide merge/selection only after a clean Windows x86-64 build and MariaDB-backed test. Mining functionality remains relevant, but the immediate user pain point is first-login market supply.

**Gate status:** S2-C offline bootstrap prototype **passed 26/26**; S2-D original-server market bootstrap integration **not started/not passed**. The 15 prior full-server acceptance gates remain open.
