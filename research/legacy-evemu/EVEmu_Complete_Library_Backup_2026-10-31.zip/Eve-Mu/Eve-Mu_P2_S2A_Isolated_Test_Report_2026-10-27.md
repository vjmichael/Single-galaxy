# Eve-Mu P2 — isolated mining, market and asteroid regression tests

**Date:** 2026-10-27 (UTC). **Phase:** S2-A initial reproducible fault models. **Execution:** 7 of 7 isolated model assertions met; the assertions include *expected failures* in the old/unchanged behavior. **NOT** a successful EVEmu build, server process, MariaDB integration test, client test, or verification that a candidate fork works.

## Environment and reproducibility

- Linux x86-64 research container; `g++` C++17, `sqlite3` development headers/library, AddressSanitizer and UndefinedBehaviorSanitizer. This is **not** the intended Windows x86-64 application build.
- GitHub code reviewed through read-only GitHub connector. Direct `git ls-remote` from test container failed (no DNS/network). No complete source tree, MariaDB server, or historical EVE client was available for execution.
- Build and run (from this directory): `g++ -std=c++17 -O0 -g -Wall -Wextra -Wpedantic -fsanitize=address,undefined -fno-omit-frame-pointer isolated_regression_models.cpp -lsqlite3 -o isolated_regression_models && ASAN_OPTIONS=detect_leaks=1 ./isolated_regression_models`.
- The test source comprises **original, reduced behavioral models** reflecting the inspected statement order and key state transitions. It does not compile or link the original EVEmu methods. Because a model throws an explicit `NullTargetUse` instead of dereferencing a null pointer, sanitizer success does not itself establish safety of the real code. SQLite tests use the same *transaction sequence idea*, not the server's MariaDB connector, storage engines or `AccountService`.

## Source pinning — repository commits

| Label | Repository and branch | Observed commit SHA |
|---|---|---|
| M0 | `EvEmu-Project/evemu_Crucible` / `master` | `f55b488a006e3090470d3b481aee47a1d7a0dade` |
| F42 | `Mrinnovvation/evemu_Crucible` / `fixes/2026-10-15-combat-and-fitting` | `c88496f6f08a6488b57bbe9e3f5e3a61fd2da092` |
| Revised | `rennr/evemu_Revised` / `revised` | `2f1675b9d710bdb1158cbbd5cf46858a0e9e341a` |
| F59 | `sargentscrufy/evemu_Crucible` / `phase-1-commerce` | `0fa6cac5422902d28c29358d694dd7369b9eb407` |

## Test results (all are **model results**, not EVEmu integration passes)

| ID | Model test | Observed model outcome | Real-world verification still required |
|---|---|---|---|
| MARKET-A | F42/Revised `FillAgainstSellOrder` when `SpawnItem` returns null **without a database statement failure** | Buyer 1000→900, seller 0→100, order 5→4, no goods delivered, journal row inserted: **inconsistent commit reproduced in SQLite model** | Inject null inventory factory result without failing the DB transaction; inspect actual wallet, journal, inventory and order rows |
| MARKET-B | Explicit rollback guard in the same model | Buyer 1000, seller 0, order 5, no item or journal: **reference mitigation preserved invariants** | Verify suitable return/rollback and in-memory state recovery in actual EVEmu flow |
| MARKET-C | `DBTransaction`-style destructor that commits on scope exit when exception is thrown | Debit persists after a thrown exception in model; **throw alone is unsafe if destructor auto-commits** | Verify DBCore failure flags and rollback for exceptions/aborts, query failures and missing items |
| MINING-A | F42-style direct `m_targetSE` after partial-cargo `CargoFull` | Nested `Deactivate` → `MiningLaser::DeactivateCycle` → `ProcessCycle(abort)` → `ActiveModule::Clear`; model detects **use of cleared target** | Run instrumented original fork with partial cargo and active cycle, obtain stack trace, determine if game loop reaches this sequence |
| MINING-B | Revised saved `pTarget` around the same sequence | Model avoids null target, but records **8 units taken from rock vs. 4 delivered to cargo** under a 4-unit free-capacity fixture | Test actual `HasAvailableSpace`, `MergeTypesInCargo`, module state and cycle timing; this imbalance is a **model hypothesis**, not a proven Revised bug |
| BELT-A | Radius loaded/saved twice | With type radius 5 and stored radius 200, upstream style calculates 1000 then 5000; Revised/F42 style holds radius at 200 | Test real `AsteroidSE::GetRadius`, SQL `sysAsteroids` persistence, system reload and ice/gas types |
| CLIENT-BOUNDARY-A | Crucible mining destination for a ship with `AttrOreHoldCapacity` | Upstream selects specialized ore hold; F59 retains `flagCargoHold` | Verify historical-client inventory visibility and capacity, not just C++ flag selection |

## Directly verified source paths and line anchors

- **F42 mining lifecycle:** [`MiningLaser.cpp` lines 165–260](https://github.com/Mrinnovvation/evemu_Crucible/blob/c88496f6f08a6488b57bbe9e3f5e3a61fd2da092/src/eve-server/ship/modules/MiningLaser.cpp#L165-L260), blob `0591c86d557d371d770390c038c3b4ffd71d8f85`: when cargo is insufficient, calls `m_shipRef->CargoFull()`, then base deactivation, and later reads `m_targetSE->GetAsteroidSE()`.
- **Synchronous deactivation:** [`ModuleManager.cpp` lines 1537–1554](https://github.com/Mrinnovvation/evemu_Crucible/blob/c88496f6f08a6488b57bbe9e3f5e3a61fd2da092/src/eve-server/ship/modules/ModuleManager.cpp#L1537-L1554) calls module `Deactivate()`. [`ActiveModule.cpp` lines 563–584](https://github.com/Mrinnovvation/evemu_Crucible/blob/c88496f6f08a6488b57bbe9e3f5e3a61fd2da092/src/eve-server/ship/modules/ActiveModule.cpp#L563-L584) immediately calls virtual `DeactivateCycle(true)` for mining. [`ActiveModule.cpp` lines 241–259](https://github.com/Mrinnovvation/evemu_Crucible/blob/c88496f6f08a6488b57bbe9e3f5e3a61fd2da092/src/eve-server/ship/modules/ActiveModule.cpp#L241-L259) resets `m_targetSE` to null.
- **Revised retained pointer:** [`MiningLaser.cpp` lines 182–260](https://github.com/rennr/evemu_Revised/blob/2f1675b9d710bdb1158cbbd5cf46858a0e9e341a/src/eve-server/ship/modules/MiningLaser.cpp#L182-L260), blob `4f7ddec5d595c32233d87b6f1cf6a754d3ba337c`. F42 has removed this target copy.
- **Market failure:** [`MarketMgr.cpp` lines 1008–1099](https://github.com/Mrinnovvation/evemu_Crucible/blob/c88496f6f08a6488b57bbe9e3f5e3a61fd2da092/src/eve-server/market/MarketMgr.cpp#L1008-L1099), blob `09752e240ec50cb1a812e8ac9ac5957f559ba099`: wallet transfer precedes item creation; null result merely logs before trade recording and order adjustment. Identical market-manager blob was found in Revised, so this concern should be attributed to **both** development lines.
- **Transaction guard semantics:** [`dbcore.h` lines 174–248](https://github.com/Mrinnovvation/evemu_Crucible/blob/c88496f6f08a6488b57bbe9e3f5e3a61fd2da092/src/eve-core/database/dbcore.h#L174-L248), blob `06a55f28918c02b4cf4c03e52e0a3056795d7305`: `DBTransaction` destructor calls commit unless explicit `Rollback()` / `Commit()`. DB driver failure flags can force rollback; the modeled error requires a null factory result *without* a failing DB statement.
- **Belt radius:** [`BeltMgr.cpp` M0](https://github.com/EvEmu-Project/evemu_Crucible/blob/f55b488a006e3090470d3b481aee47a1d7a0dade/src/eve-server/system/cosmicMgrs/BeltMgr.cpp#L141-L217) multiplies the saved radius by `itemRef->type().radius()` on loading; Revised/F42 [`BeltMgr.cpp`](https://github.com/Mrinnovvation/evemu_Crucible/blob/c88496f6f08a6488b57bbe9e3f5e3a61fd2da092/src/eve-server/system/cosmicMgrs/BeltMgr.cpp#L175-L260) stores/loads raw radius and `originalQuantity` directly; its belt file matches Revised by Git blob SHA `3de37d10935fe579e6d54efa808e705a256c04c8`.
- **F59 cargo selection:** [`MiningLaser.cpp` lines 24–115](https://github.com/sargentscrufy/evemu_Crucible/blob/0fa6cac5422902d28c29358d694dd7369b9eb407/src/eve-server/ship/modules/MiningLaser.cpp#L24-L115), blob `751ede42b524ffd84a17e740c6f39407eaf70d4a`. Diff against M0 changes only the `flagOreHold` handling and nearby comment in this source file; gas hold retains its own branch.

## Findings and decisions

1. **Priority 1 — block selection of F42 wholesale.** It lacks the defensive target snapshot in Revised; the synchronous deactivation call chain makes a genuine runtime failure plausible. Verify with actual original C++ as soon as a build is available, and do not assume blindly restoring the snapshot solves every issue (see MINING-B).
2. **Priority 1 — market inventory/wallet invariants.** F42/Revised may permit a paid but undelivered trade on an item-factory failure with no database error. A protective implementation needs all-or-nothing settlement and explicit failure/rollback, including safe restoration of any in-memory changes. Do not infer safety from SQL transactions alone.
3. **Priority 2 — belt persistence.** Upstream has a plausible radius multiplication defect; Revised/F42 implementation corrects that specific formula in the model. Real save/reload, original quantity restoration and ice/gas cases are unverified.
4. **Priority 2 — client compatibility.** F59 small cargo-flag change appears valuable for Crucible-era UI. Verify with the historical client at a later user-authorized time.
5. **Provenance:** Revised and F42 share exact file blobs for `BeltMgr.cpp`, `ReprocessingService.cpp`, `MarketMgr.cpp`, the market ledger and the market gateway. Treat F42 as a derivative with incremental changes, not the inventor of all those systems.

## Unresolved infrastructure/build gates

- No upstream, F42, Revised or F59 full C++ build performed.
- No MariaDB, EVEmu process, real networking, client, or direct fork regression binary executed.
- No actual source patch applied, no GitHub repository changed and no client data accessed.
- Later: acquire source in an approved reproducible workspace; compile target revisions, run original-code tests with instrumentation; inject failures in item factory and DB services; check invariants across database and in-memory state; test save/reload. **The source-level model is only a prioritization tool for that work.**
