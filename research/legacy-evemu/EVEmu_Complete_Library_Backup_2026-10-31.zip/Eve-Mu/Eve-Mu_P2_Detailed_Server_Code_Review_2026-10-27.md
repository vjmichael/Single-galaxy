# Eve-Mu — P2 Detailed Source Comparison, Pass A

**Checkpoint:** 2026-10-27. **Scope:** Read-only source-level analysis of upstream, F59, F42 and `rennr/evemu_Revised`; targeted market transaction and asteroid lifecycle assessment. **No code merged, no original client touched, no full server compiled and no live EVEmu tests run.** Findings distinguish directly observed code paths from predictions needing reproduction.

## Pinned reference identities

| Label | Repository and branch examined | Head SHA at time of inspection |
|---|---|---|
| M0 | `EvEmu-Project/evemu_Crucible:master` | `f55b488a006e3090470d3b481aee47a1d7a0dade` |
| F59 | `sargentscrufy/evemu_Crucible:phase-1-commerce` | `0fa6cac5422902d28c29358d694dd7369b9eb407` |
| F42 | `Mrinnovvation/evemu_Crucible:fixes/2026-10-15-combat-and-fitting` | `c88496f6f08a6488b57bbe9e3f5e3a61fd2da092` |
| Revised | `rennr/evemu_Revised:revised` | `2f1675b9d710bdb1158cbbd5cf46858a0e9e341a` |

**Reference semantics:** Branch heads may change after this report. Blob SHAs below identify exact *file content*. Commit SHAs above identify repository snapshots; the review was read-only. The historical EVE client (approximately 10 GB) remains local to the user; client testing is deferred.

## SR-01 — F59 fixes historically incompatible ore-hold routing (source-level candidate improvement)

- Source: `src/eve-server/ship/modules/MiningLaser.cpp`.
- Exact content: M0 blob `8443058efe2066c885fd11bb526d5262ad57b630`; F59 blob `751ede42b524ffd84a17e740c6f39407eaf70d4a`.
- A line-by-line diff produced **four small change segments**. F59 removes the three `if (m_shipRef->HasAttribute(AttrOreHoldCapacity)) m_holdFlag = flagOreHold;` assignments for standard ore, Mercoxit and ice mining. It explicitly documents that the Crucible client build 360229 predates ore bays, so an ore-hold flag may render ore invisible to the client.
- Source-based assessment: **Likely valuable era-compatibility fix, untested in a real client.** It is narrow and may be adopted independently after reproducing the problem. Avoid treating all F59 mining logic as rewritten; the rest of the sampled `MiningLaser.cpp` is unchanged from M0.
- Independent tests: barge whose server static data contains `AttrOreHoldCapacity`, process a mining cycle, then inspect `flagCargoHold` and the Crucible client's cargo display; repeat with ice/Mercoxit. Test explicitly whether cargo capacity enforcement still works.
- Caveat: This study has not checked exact client binary behavior; the historical-client claim is from F59's source comment, and client data may include later-era attributes.

## SR-02 — F42 removes a target lifetime guard found in `rennr/evemu_Revised` (credible regression candidate)

- Source: `MiningLaser.cpp`, Revised blob `4f7ddec5d595c32233d87b6f1cf6a754d3ba337c`, F42 blob `0591c86d557d371d770390c038c3b4ffd71d8f85`.
- Exact diff: Revised stores `SystemEntity* pTarget(m_targetSE)` before processing cargo-full and depletion paths, null-checks it, and uses this saved pointer. F42 removes that safety copy and substitutes `m_targetSE` again in ore-target and depletion operations.
- In F42 `MiningLaser::ProcessCycle()`, cargo-full handling calls `m_shipRef->CargoFull()` and `ActiveModule::DeactivateCycle(true)`, then execution may continue to dereference `m_targetSE` in `m_targetSE->GetAsteroidSE()` or `m_targetSE->TargetMgr()`.
- Cross-file proof of hazardous invalidation: F42 `ActiveModule.cpp` blob `c49a093b7931f3f4e1166eadc3d2017b91d37362`; `ActiveModule::DeactivateCycle()` calls `Clear()`, and `Clear()` assigns `m_targetSE = nullptr`. `ModuleManager::CargoFull()` iterates active mining modules and requests deactivation as well. This is a **concrete risky source path**; the exact sequence under a real mining module state has not been reproduced.
- Source assessment: **High-priority possible null-dereference regression**, not a confirmed user-visible crash. Don't copy F42's removed-guard behavior into Eve-Mu. Reproduction should enable sanitizers and capture call stacks for a nearly full hold after an active mining cycle.
- Other F42 mining differences (asteroid callbacks, client radius broadcasts) require independent accounting tests.

## SR-03 — F42 market settlement continues after item-spawn failure (source-level correctness defect)

- Source: F42 `src/eve-server/market/MarketMgr.cpp` blob `09752e240ec50cb1a812e8ac9ac5957f559ba099`, `FillAgainstSellOrder()` (approximately lines 1008–1096).
- Normal path: begins `DBTransaction tx`, calls `AccountService::TransferFunds` from buyer to seller, calculates tax, attempts `sItemFactory.SpawnItem(idata)` to create purchased goods, calls `RecordTrade`, may call `sMktSim.OnSimAskFilled`, and updates/removes the market order.
- Failure branch: `if (iRef.get() == nullptr)` logs an error but **does not return false, throw, or call `tx.Rollback()`**; execution falls through to trade recording, simulator settlement and order update, and returns true. This is observable from code even without executing the server. Whether a given item creation failure can be triggered naturally is untested.
- Related `FillAgainstBuyOrder` similarly may log a failed spawned item for a sim seller and continue. Check that branch separately in fault injection.
- `DBTransaction` implementation: `src/eve-core/database/dbcore.h` blob `06a55f28918c02b4cf4c03e52e0a3056795d7305`: destructor calls `CommitTransaction()` when not explicitly completed. The implementation (`dbcore.cpp`, `e13455addc81f3365af1079de1e3a47e3fbb330b`) supports nested transaction tracking and server rollback on query/connection failures. **A plain log-and-continue is not itself a rollback signal.** The table migration `20261015130100-market-fill-innodb.sql` switches inventory and corporation wallet tables to InnoDB; that is a meaningful durability improvement, but it cannot correct application-level acceptance of a failed spawn.
- Source assessment: **Likely serious fault-handling defect**. The remedy should require pre-validating item creation and/or explicit rollback upon failure; then independently verify funds, order quantity, delivered items, simulator ledger and transaction records all remain unchanged after an injected failure. Do not assume simply throwing is sufficient because the RAII transaction destructor commits by default.

## SR-04 — F42/Revised improve asteroid radius handling and regrowth; provenance matters

- Original M0 `BeltMgr.cpp` blob `600b1651607dab625e4b6d6a67f06a51a1076fda`: `Save()` persists the entity `GetRadius()` and a quantity reconstructed from `25000*log(radius)-112404.8`; `Load()` sets `AttrRadius` to `itemRef->type().radius() * entity.radius`. `SystemEntity.cpp` (`b9b9655d1909405c83ba11146be7f9c04ca20c0b`) initializes `m_radius` from `AttrRadius`, so repeated round trips are at risk of rescaling a previously persisted effective radius by the type radius. **Test with a real asteroid type radius != 1; not yet a reproduced DB/live bug.** Reconstructing quantity from radius may also mishandle ice and gas.
- M0 `AsteroidSE::Grow()` (blob `bd4ba47ad9c2461ed03159ce6a858f3d18eb6b8a`) contains commented-out quantity updates and merely disables its growth timer; it does not visibly replenish ore.
- F42 and Revised share identical `BeltMgr.cpp` blob `3de37d10935fe579e6d54efa808e705a256c04c8`, **not independent F42 invention**. The improved `Load()` sets `AttrRadius` directly to persisted `entity.radius`; `Save()` uses `GetQuantity()` and `GetOriginalQuantity()` instead of recalculating from radius. Revised/F42 manage partial depletion, `OnMined`, cooldown and regrowth. F42 `Asteroid.cpp` blob `4b83b44b1694695787845dd5761424e58dd4b3ae` implements `AsteroidSE::Grow()`, `SetQuantity()`, `RemoveQuantity()` and `RadiusForQuantity()` with broadcasting via destiny manager. This is substantially more complete source than upstream, **still untested**.
- Test requirements: round-trip radius and quantity for ore, ice and gas; compare before/after two save-load cycles; regrow after eligible delay only when no player in belt; reject negative quantities; notify clients of radius changes; verify industrial indices and depletion callbacks do not double count.

## SR-05 — Most of F42's economy core predates F42 and comes from Revised

| File | F42 vs Revised content identity |
|---|---|
| `src/eve-server/system/cosmicMgrs/BeltMgr.cpp` | Identical blob `3de37d10935fe579e6d54efa808e705a256c04c8` |
| `src/eve-server/station/ReprocessingService.cpp` | Identical blob `1f0f81af6392dd05e1211945226f3ecd471a30ed` |
| `src/eve-server/market/MarketMgr.cpp` | Identical blob `09752e240ec50cb1a812e8ac9ac5957f559ba099` |
| `src/eve-server/market/sim/SimLedger.cpp` | Identical blob `7cd6d34ea2c8a62745b1927f8493d3ae036b6c4a` |
| `src/eve-server/market/sim/ServerMarketGateway.cpp` | Identical blob `9a631ba9a645d766e74937abf803b9da34e1e936` |
| `MarketSimMgr.cpp` | Nearly identical; four limited line-change segments (3 removed configuration/field lines, one 3-vs-4 argument change) |
| `MiningLaser.cpp` | Differs, including removal of target-pointer safeguard as detailed above |

This revises the sourcing strategy: compare `rennr/evemu_Revised` directly with upstream as a major candidate line, and audit **F42's incremental differences** separately. Do not merge F42 wholesale assuming every change is independently its own or benign. File identity is stronger evidence than README marketing claims.

## SR-06 — F59 has executable integration-test scripts but uses pre-staged DB fixtures

- `tools/simfleet/market_fill_test.py` blob `d51a8135a2d6405b911eb0c633f24e88f089ed5e`: checks partial fills, order prices, inventory decrement and wallet movement, order crossing, no-match invariants. It stages items and orders directly into database for repeatability.
- `tools/simfleet/reprocess_test.py` blob `0c2d2c731f9662610f1e5084639ba8aac5eb29c8`: connects as protocol test client and exercises the reprocessing service, but stages Veldspar and a docked character directly in DB.
- `tools/simfleet/industry_chain_test.py` blob `bd52189c559362da2b447b2499883d785c9da086`: refines ore and manufactures an item from staged materials/blueprint, with inventory consumption checks.
- F59 is a good source of testing patterns, NOT proof that undock → mine → dock → refine → sell succeeds on an unmodified private server. Its miner delta above is a stronger direct improvement candidate than broad functionality claims.

## Formal classification at this checkpoint

| ID | Observation | Classification | Independent runtime tests |
|---|---|---|---|
| SR-01 | F59 ore-hold compatibility adjustment | Likely improvement (untested) | 0 |
| SR-02 | F42 removes pointer guard before post-deactivation dereferences | Regression candidate (high priority) | 0 |
| SR-03 | F42/Revised fill handler does not fail/rollback after item creation failure | Source-level defect candidate (high priority) | 0 |
| SR-04 | F42/Revised asteroid persistence/regrowth against M0 | Likely improvement (untested) | 0 |
| SR-05 | F42 mostly inherits Revised market/sim/asteroid work | Verified source provenance at sampled file level | n/a |
| SR-06 | F59 scripted QA staging | Verified existence and assertion intent; pass status unknown | 0 |

## Next gates / do not claim complete

1. **S2-A:** isolated reproducible unit/fault-injection tests for F42 `SpawnItem` failure, database statement failure, cargo-full module state after `ActiveModule::Clear`, and radius/quantity roundtrips. Save exact test outputs and build environments, not just pass claims.
2. **S2-B:** compare Revised versus M0 migration chain and dependencies; inspect whether F42 changed interfaces are compatible (`SimFacilityMgr::Capacity` signature and static-data calibration). Also verify rollback semantics across *all* relevant InnoDB tables and journal writes.
3. **S2-C:** port and run F59's market, refining and manufacturing test scripts against clean isolated databases with known fixture snapshots; test normal gameplay state setup separately from direct DB inserts.
4. **S3:** only after a compatible client is available locally in a future authorized session: login → undock → travel → mine → dock → refine → sell → save/reload. **No client upload to Library.**

## Links to inspected files

- Upstream miner: https://github.com/EvEmu-Project/evemu_Crucible/blob/master/src/eve-server/ship/modules/MiningLaser.cpp
- F59 miner: https://github.com/sargentscrufy/evemu_Crucible/blob/phase-1-commerce/src/eve-server/ship/modules/MiningLaser.cpp
- F42 miner: https://github.com/Mrinnovvation/evemu_Crucible/blob/fixes/2026-10-15-combat-and-fitting/src/eve-server/ship/modules/MiningLaser.cpp
- Revised miner: https://github.com/rennr/evemu_Revised/blob/revised/src/eve-server/ship/modules/MiningLaser.cpp
- F42 market manager: https://github.com/Mrinnovvation/evemu_Crucible/blob/fixes/2026-10-15-combat-and-fitting/src/eve-server/market/MarketMgr.cpp
- F42 transaction wrapper: https://github.com/Mrinnovvation/evemu_Crucible/blob/fixes/2026-10-15-combat-and-fitting/src/eve-core/database/dbcore.h
- F42 belt manager: https://github.com/Mrinnovvation/evemu_Crucible/blob/fixes/2026-10-15-combat-and-fitting/src/eve-server/system/cosmicMgrs/BeltMgr.cpp
- F59 market QA: https://github.com/sargentscrufy/evemu_Crucible/blob/phase-1-commerce/tools/simfleet/market_fill_test.py
