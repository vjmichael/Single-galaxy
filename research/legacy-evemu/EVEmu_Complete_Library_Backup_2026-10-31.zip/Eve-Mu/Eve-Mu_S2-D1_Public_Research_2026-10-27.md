# Eve-Mu — S2-D1 Online EVE Static-Data and TypeID Research

**Date:** 2026-10-27  
**Scope:** Public research for Crucible-era starter-market identifiers, *not* client inspection and *not* a full database import.  
**Evidence status:** public type IDs cross-checked with EVE Ref and older public ID lists; **2012 exact-db verification remains open**. These are *candidate IDs for Eve-Mu*, not certified 1.6.5 production values.

## Primary findings

1. **CCP released game static data to developers.** Current official SDE documentation is https://developers.eveonline.com/docs/services/static-data/ . SDE contains item types, group names, stations, attributes and blueprints. It is static data—not live market buy/sell orders or player wallets.
2. **A period-specific SDE existed.** A March 28, 2012 developer-forum post identifies a CCP-issued Crucible 1.6 static data archive `Crucible_1.6_65449_db.zip`: https://forums-archive.eveonline.com/message/1064377/ . This is the better historical cross-check than today's SDE. Availability of the original download has NOT been verified. Do not confuse its `65449` export identification with the client build 360229 in EVEmu's version constant.
3. **The public EVEmu repo itself carries SQL static tables** (`sql/base/invTypes.sql.gz`, `invGroups.sql.gz`, `staStations.sql.gz`, `crpNPCCorporationTrades.sql.gz`, etc): https://github.com/EvEmu-Project/evemu_Crucible/tree/master/sql/base . GitHub metadata verified the files exist; compressed binaries could not be imported into this session for row-by-row verification.
4. **Important version boundary:** CCP confirms that the Venture mining frigate was introduced in Retribution (December 4, 2012), after the Crucible period: https://www.eveonline.com/news/view/the-new-ships-of-retribution-price-indices-december-2012 . Its TypeID 32880 must NOT be seeded into the Crucible-era world without intentional modifications, and 2026 data about mining holds and ship bonuses must not be blindly used.
5. **Station identifier example (not chosen as Eve-Mu's hub):** Jita IV - Moon 4 - Caldari Navy Assembly Plant = `stationID 60003760` per https://wiki.eveuniversity.org/Trade_hubs . Station IDs and regions must be checked against the selected server data and the eventual compact topology.

## Draft starter catalog

The attached CSV contains **30 item TypeID candidates**, across **9 ore, 7 mineral, 8 module_or_drone, 6 ship**. The initial mandatory bootstrap scope should be narrower than the full CSV:

- **Starter sell inventory**: Civilian Miner 3651, Miner I 483, Survey Scanner I 444, Expanded Cargohold I 1317; choose a compatible frigate (Bantam 582 or Navitas 592) after checking the historical fitting and skill requirements.
- **Starter buy-side demand**: Veldspar 1230, Scordite 1228, Pyroxeres 1224, Plagioclase 18 and core minerals Tritanium 34, Pyerite 35, Mexallon 36. Keep NPC bids backed by reserved money and avoid claiming prices from current live EVE.
- **Progression**: Procurer 17480 / Retriever 17478, Strip Miner I 17482, mining drones 10246 and hauling with Badger 648 after confirming historical skills and module behavior.
- **Later frontier**: Kernite 20, Omber 1227, Crokite 1225, Bistot 1223, Arkonor 22, and the remainder of the seven core minerals as appropriate. Locations/yields are game-balance design choices and must not be inferred from today's resource geography.

Modern EVE Ref source for TypeIDs: https://everef.net/types/1230 , https://everef.net/types/483 and the per-row links in the CSV. An older 2018 public TypeID table at https://omochin.github.io/eveonline-type-ids/ provides additional but **not 2012-proof** historical support for many IDs.

## Important distinctions

- **`typeID`** identifies item classes; **`itemID`** refers to individual instances; **`stationID`** locates markets; **`marketGroupID`** categorizes market items. Never substitute one for another.
- **The SDE is not seeded market orders.** Seeded market functionality must separately place *fillable* orders with associated stock, escrow/funds, valid issue dates, sane durations, and database-consistent ownership.
- **Do not adopt modern volume, price, blueprint materials or mining-barge ore-hold attributes as 2012 truth.** Those have changed, including the introduction of ore holds and the later Venture.
- The `sql/seed_and_clean/seed_station_market.sql` code in EVEmu generates market order records but does not itself validate inventory, escrow, expiry or match execution, as found in S2-C. The newer F42/Revised simulation ledger rejects unsupported legacy NPC orders.

## S2-D1 verification acceptance (open)

A. Obtain a permissible Crucible 1.6 SDE snapshot or the identical EVEmu `invTypes` data and run the supplied **read-only SQL** to confirm each name, typeID, groupID, published status and marketGroupID. Reject mismatches automatically.
B. Verify proposed station IDs and region/system topology against `staStations` and `mapSolarSystems`. Do NOT choose a starter system just because Jita is a famous hub.
C. Verify skills, historical module fitting and ore/cargo hold behavior against the Crucible-version dogma tables.
D. Choose deterministic unit quantities, starter money and prices only after historical database verification. These should be Eve-Mu-defined economics, not current EVE price quotations.
E. Test actual first-login market orders with a running EVEmu server and MariaDB. None of these tests was performed by this online research.

**Status:** Research completed for publicly available candidate identifiers; exact Crucible-database validation and production integration pending. No game client files were accessed, no repository was modified, and no market orders were created.
