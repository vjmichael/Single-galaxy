# Eve-Mu — Private Educational Study of Space-MMORPG Client–Server Architecture

**Research log / living document**  
**Initiated:** 2026-10-27  
**Status:** P0 complete for 120 named forks; P1 fork metadata, default-branch comparison, and branch-name survey completed 2026-10-27. Full source/build/behavior audits belong to P2; 3 fork-counter names unresolved.

## Goal
**Current user direction (2026-10-27):** Eve-Mu is **strictly a private, educational research effort** to learn how the EVEmu server and a compatible EVE-era client work together as a space MMORPG. **No distribution is planned**; the user is investigating this for personal use and learning. Analyze both sides of the client–server boundary, how the full game works, and what the EVEmu forks teach us. A small, offline, mining-focused private world remains the desired experiment, not a product launch or a reason to bypass the historical client. Developing an original independent game is a **contingency / possible downstream application**, not the default plan. Respect applicable licenses and avoid assuming proprietary client source is available.

## Fixed world brief (provisional map)
- High-security hub: beginner-safe system/cluster with major NPC corporations, stations, market and trade.
- Medium-security frontier: resources and moderate hazards; connected directly to the high-security hub and null-sec frontier.
- Null-security frontier: high-value resources and serious danger; connected directly to the medium-security frontier.
- Optional fourth wormhole area: exploration/mining anomaly, reachable **only from medium-security**, with the wormhole behavior assessed for reliability.
- Suggested starting interpretation: four compact **star-system clusters**, not four literal galaxies. Actual system count, gate travel, map assets, NPC traffic, respawn rates and economy will be determined after code audit.

## P0 — Inventory and workflow (current)
1. Identify the main repository and distinguish its forks (actual parent/source relationship) from copies, independently named descendants and unrelated projects.
2. Record for each inventory entry: stable ID, GitHub owner/repository name, URL, repository ID when possible, parent or relationship confidence, branch, latest accessible commit, accessibility, and status.
3. Freeze an inventory snapshot with date and evidence; mark incomplete or inaccessible forks explicitly. Avoid implying GitHub's fork badge equals the number of reviewable codebases.
4. Assign identifiers: `P1-M0` for the main; `P1-F1` through `P1-FN` for confirmed fork entries. Separate `P1-X#` candidates whose ancestry needs verification.
5. Save the P0 inventory to the Library **before** deep analysis. During later P1 and P2, save a separate checkpoint after every repository; never postpone documentation until the entire collection is finished.

**Verified main candidate:** `P1-M0` = `EvEmu-Project/evemu_Crucible` — https://github.com/EvEmu-Project/evemu_Crucible (public; `master` at time of query). GitHub's current repository API reports **123 forks** (retrieved 2026-10-27; count changes). The main repository page search snippet has shown stale estimates around 116–119. Our source-verified census below identifies **120 public fork-lineage repositories by owner and name**, with **3 still unidentified**. Therefore the current working count is 124 repositories (main + 123 reported forks), of which 121 have confirmed names (main + 120 forks).

**Important note:** An older, similarly named `evemuproject/evemu_crucible` also exists. Its relation to the newer main source must be checked rather than counted automatically as a fork.

## P1 — One bounded repository record per codebase
- `P1-M0`: main repository source/commit/branches/docs/build/DB/client compatibility/basic mining systems and known limitations.
- `P1-F1 ... P1-FN`: fork-by-fork records, each independently saved once completed. Inspect default branch and materially relevant other branches, releases, open PRs, commits and actual executable changes where accessible.
- Each record: source provenance, snapshot SHA, upstream divergence, high-level subsystem map, user-value claims, evidence, testing feasibility, risks, prerequisites and mining/offline relevance.
- **Checkpoint discipline:** Commit/save each completed record to Library as soon as it is reviewed; keep the index updated with complete / partial / blocked states.

## P2 — Evidence-based implementation assessment
- Do not produce exhaustive diff logs. Measure meaningful behavior changes: mining lasers and ore yields, asteroid belts/respawn, cargo and refining, selling/markets and NPC orders, industry, solo viability, login/character progression, docking and ship control, warp/gates, wormholes, PvE AI, save-state/data integrity, and Windows-local install.
- Classify each apparent change as: verified improvement / likely improvement (untested) / experimental / cosmetic-refactor / regression / unknown. Cite paths, commits, tests and observable evidence.
- For promising forks, design narrow reproducible tests (build, server startup, login, ship spawn, belt mine-cycle, ore storage, refinery/market, travel) before adopting code.

## P3 — Compare, contrast and shortlist
- Cross-reference only useful improvements against `P1-M0`; show feature, best source, evidence, conflicts, integration cost, licensing, test status and fit to the small world.
- Select a **minimal viable playable path** first, then optional mining/economy depth, PvE and wormholes. Do not assume every fork is superior or should be merged.
- End P3 with an explicit go/no-go recommendation: (A) locally run a compatible EVEmu server with lawfully obtained compatible client and permitted assets, or (B) build a distinct small single-player space simulator inspired by the learning, using legally appropriate code/assets.

## Engineering and legal cautions (gates, not conclusions)
- EVEmu is a **server emulator**, not a complete self-contained single-player game; client binaries, game data, art, networking and authentication may be separate dependencies.
- Private/local execution does not itself resolve game client, trademark, copyrighted assets, license, or EULA terms. Review individual repository licenses and relevant terms before planning distribution or asset extraction.
- An emulator running offline with one account is not automatically a balanced single-player game. Markets, NPC supply/demand, corporation functions and unattended world events may need synthetic actors and deterministic offline simulation.
- A direct replacement of EVE's universe database with only four systems may break SQL IDs, station links, agents, map services, spawn assumptions and client-side maps. Favor a logical playable subset / custom map overlay until data dependencies are understood.

## Research state and next checkpoint
- **P0 main and 120 named forks verified; discrepancy of 3 unresolved.**
- P1 and P2 source audits **not begun**; P3 not begun. No claim yet about actual gameplay support or tested compatibility.
- Next action: resolve the three unlisted fork names if GitHub permits, then proceed P1-M0. The roster below is frozen so subsequent progress can be saved independently without renumbering.

## Initial public sources
- https://github.com/EvEmu-Project/evemu_Crucible
- https://github.com/EvEmu-Project/evemu_Crucible/blob/master/doc/ChangeLog.md
- https://github.com/evemuproject/evemu_crucible


---

## P0 — Verified GitHub fork-lineage roster (2026-10-27 snapshot)

**Counter caveat.** GitHub REST repository metadata currently reports `forks_count=123` for `EvEmu-Project/evemu_Crucible`. A search and individual `GET /repos/{owner}/{repo}` verification located **120** accessible repositories whose `source.full_name` resolves to `EvEmu-Project/evemu_Crucible`. This includes one fork-of-fork (`pet1100`, immediate parent `ozatomic`). Three reported forks were not found by name through this search and are **not assigned invented owners**. Counters/search indexes need not agree at a particular instant. Treat 123 as reported count rather than independently enumerated count.

| P1 ID | GitHub owner / repo | Source-relationship status |
|---|---|---|
| P1-F1 | [ozatomic/evemu_crucible_current](https://github.com/ozatomic/evemu_crucible_current) | Verified source = current main |
| P1-F2 | [AzediZ/evemu_Crucible](https://github.com/AzediZ/evemu_Crucible) | Verified source = current main |
| P1-F3 | [ion9/evemu_Crucible](https://github.com/ion9/evemu_Crucible) | Verified source = current main |
| P1-F4 | [triple111/evemu_Crucible](https://github.com/triple111/evemu_Crucible) | Verified source = current main |
| P1-F5 | [GameModForks/evemu_Crucible](https://github.com/GameModForks/evemu_Crucible) | Verified source = current main |
| P1-F6 | [ToddRosenkrantz/evemu_Crucible](https://github.com/ToddRosenkrantz/evemu_Crucible) | Verified source = current main |
| P1-F7 | [ziggozoggo/evemu_crucible](https://github.com/ziggozoggo/evemu_crucible) | Verified source = current main |
| P1-F8 | [pet1100/evemu_crucible](https://github.com/pet1100/evemu_crucible) | Verified through `ozatomic` (fork-of-fork) |
| P1-F9 | [chengood5000/evemu_Crucible](https://github.com/chengood5000/evemu_Crucible) | Verified source = current main |
| P1-F10 | [chuengjoanna/evemu_Crucible](https://github.com/chuengjoanna/evemu_Crucible) | Verified source = current main |
| P1-F11 | [luokery/evemu_Crucible](https://github.com/luokery/evemu_Crucible) | Verified source = current main |
| P1-F12 | [pixelcatburglar/evemu_Crucible](https://github.com/pixelcatburglar/evemu_Crucible) | Verified source = current main |
| P1-F13 | [DavidStinson/evemu_Crucible](https://github.com/DavidStinson/evemu_Crucible) | Verified source = current main |
| P1-F14 | [bnaambo/evemu_Crucible](https://github.com/bnaambo/evemu_Crucible) | Verified source = current main |
| P1-F15 | [novafacing/evemu_Crucible](https://github.com/novafacing/evemu_Crucible) | Verified source = current main |
| P1-F16 | [sangohan/evemu_Crucible](https://github.com/sangohan/evemu_Crucible) | Verified source = current main |
| P1-F17 | [idolord/evemu_Crucible](https://github.com/idolord/evemu_Crucible) | Verified source = current main |
| P1-F18 | [ImTorbin/evemu_Crucible3.0](https://github.com/ImTorbin/evemu_Crucible3.0) | Verified source = current main |
| P1-F19 | [cingulari/evemu_Crucible](https://github.com/cingulari/evemu_Crucible) | Verified source = current main |
| P1-F20 | [seren1tyy/evemu_Crucible](https://github.com/seren1tyy/evemu_Crucible) | Verified source = current main |
| P1-F21 | [locvez/evemu_Crucible](https://github.com/locvez/evemu_Crucible) | Verified source = current main |
| P1-F22 | [strikersix23/evemu_Crucible](https://github.com/strikersix23/evemu_Crucible) | Verified source = current main |
| P1-F23 | [d10sfan/evemu_Crucible](https://github.com/d10sfan/evemu_Crucible) | Verified source = current main |
| P1-F24 | [charles-m-knox/evemu_Crucible](https://github.com/charles-m-knox/evemu_Crucible) | Verified source = current main |
| P1-F25 | [Avi-E-Koenig/evemu_Crucible](https://github.com/Avi-E-Koenig/evemu_Crucible) | Verified source = current main |
| P1-F26 | [chuengeric/evemu_Crucible](https://github.com/chuengeric/evemu_Crucible) | Verified source = current main |
| P1-F27 | [dd667/evemu_Crucible](https://github.com/dd667/evemu_Crucible) | Verified source = current main |
| P1-F28 | [x0S37h0x/evemu_Crucible](https://github.com/x0S37h0x/evemu_Crucible) | Verified source = current main |
| P1-F29 | [DeerHunt3r/evemu_Crucible](https://github.com/DeerHunt3r/evemu_Crucible) | Verified source = current main |
| P1-F30 | [SilverXarrow/evemu_Crucible](https://github.com/SilverXarrow/evemu_Crucible) | Verified source = current main |
| P1-F31 | [devedse/evemu_Crucible](https://github.com/devedse/evemu_Crucible) | Verified source = current main |
| P1-F32 | [01Hub/evemu_Crucible](https://github.com/01Hub/evemu_Crucible) | Verified source = current main |
| P1-F33 | [phillipwgardner/evemu_Crucible](https://github.com/phillipwgardner/evemu_Crucible) | Verified source = current main |
| P1-F34 | [alycecil/evemu_Crucible](https://github.com/alycecil/evemu_Crucible) | Verified source = current main |
| P1-F35 | [donato/evemu_Crucible](https://github.com/donato/evemu_Crucible) | Verified source = current main |
| P1-F36 | [swaric/evemu_Crucible](https://github.com/swaric/evemu_Crucible) | Verified source = current main |
| P1-F37 | [afarazit/evemu_Crucible](https://github.com/afarazit/evemu_Crucible) | Verified source = current main |
| P1-F38 | [kenneaal/evemu_Crucible](https://github.com/kenneaal/evemu_Crucible) | Verified source = current main |
| P1-F39 | [dawa11/evemu_Crucible](https://github.com/dawa11/evemu_Crucible) | Verified source = current main |
| P1-F40 | [soesbeek/evemu_crucible](https://github.com/soesbeek/evemu_crucible) | Verified source = current main |
| P1-F41 | [PHX-TeamPhoenix/evemu_Crucible](https://github.com/PHX-TeamPhoenix/evemu_Crucible) | Verified source = current main |
| P1-F42 | [Mrinnovvation/evemu_Crucible](https://github.com/Mrinnovvation/evemu_Crucible) | Verified source = current main |
| P1-F43 | [gatesry/evemu_Crucible](https://github.com/gatesry/evemu_Crucible) | Verified source = current main |
| P1-F44 | [rrfarmer/evemu_Crucible](https://github.com/rrfarmer/evemu_Crucible) | Verified source = current main |
| P1-F45 | [AceGamesUser/evemu_Crucible](https://github.com/AceGamesUser/evemu_Crucible) | Verified source = current main |
| P1-F46 | [SynieztroLedPar/evemu_Crucible](https://github.com/SynieztroLedPar/evemu_Crucible) | Verified source = current main |
| P1-F47 | [I-89762345-I/evemu_Crucible](https://github.com/I-89762345-I/evemu_Crucible) | Verified source = current main |
| P1-F48 | [sephcasiah/evemu_Crucible](https://github.com/sephcasiah/evemu_Crucible) | Verified source = current main |
| P1-F49 | [d4rkf0x/evemu_Crucible](https://github.com/d4rkf0x/evemu_Crucible) | Verified source = current main |
| P1-F50 | [dgerabagi/evemu_Crucible](https://github.com/dgerabagi/evemu_Crucible) | Verified source = current main |
| P1-F51 | [xrizonx/evemu_Crucible](https://github.com/xrizonx/evemu_Crucible) | Verified source = current main |
| P1-F52 | [gebainixyz/evemu_Crucible](https://github.com/gebainixyz/evemu_Crucible) | Verified source = current main |
| P1-F53 | [Almamu/evemu_crucible](https://github.com/Almamu/evemu_crucible) | Verified source = current main |
| P1-F54 | [Pursche/evemu_Crucible](https://github.com/Pursche/evemu_Crucible) | Verified source = current main |
| P1-F55 | [Mezzarius/evemu_Crucible](https://github.com/Mezzarius/evemu_Crucible) | Verified source = current main |
| P1-F56 | [hxhieu/evemu_Crucible](https://github.com/hxhieu/evemu_Crucible) | Verified source = current main |
| P1-F57 | [SpirytusMoe/evemu_Crucible](https://github.com/SpirytusMoe/evemu_Crucible) | Verified source = current main |
| P1-F58 | [AviiNL/evemu_Crucible](https://github.com/AviiNL/evemu_Crucible) | Verified source = current main |
| P1-F59 | [sargentscrufy/evemu_Crucible](https://github.com/sargentscrufy/evemu_Crucible) | Verified source = current main |
| P1-F60 | [GrumpyDrago/evemu_Crucible](https://github.com/GrumpyDrago/evemu_Crucible) | Verified source = current main |
| P1-F61 | [favoms/evemu_Crucible](https://github.com/favoms/evemu_Crucible) | Verified source = current main |
| P1-F62 | [salartarium/evemu_Crucible](https://github.com/salartarium/evemu_Crucible) | Verified source = current main |
| P1-F63 | [celinor1982/evemu_Crucible](https://github.com/celinor1982/evemu_Crucible) | Verified source = current main |
| P1-F64 | [aliyajadzia/evemu_Crucible](https://github.com/aliyajadzia/evemu_Crucible) | Verified source = current main |
| P1-F65 | [kroryan/evemu_Crucible](https://github.com/kroryan/evemu_Crucible) | Verified source = current main |
| P1-F66 | [innocentius/evemu_Crucible](https://github.com/innocentius/evemu_Crucible) | Verified source = current main |
| P1-F67 | [no23/evemu_Crucible](https://github.com/no23/evemu_Crucible) | Verified source = current main |
| P1-F68 | [beelitzs/evemu_Crucible](https://github.com/beelitzs/evemu_Crucible) | Verified source = current main |
| P1-F69 | [jionychiow/evemu_Crucible](https://github.com/jionychiow/evemu_Crucible) | Verified source = current main |
| P1-F70 | [tylerengland89/evemu_Crucible](https://github.com/tylerengland89/evemu_Crucible) | Verified source = current main |
| P1-F71 | [Conan1996-2/evemu_Crucible](https://github.com/Conan1996-2/evemu_Crucible) | Verified source = current main |
| P1-F72 | [wytsa/evemu_Crucible](https://github.com/wytsa/evemu_Crucible) | Verified source = current main |
| P1-F73 | [Gargash/evemu_Crucible](https://github.com/Gargash/evemu_Crucible) | Verified source = current main |
| P1-F74 | [TheOneJohiah/evemu_Crucible](https://github.com/TheOneJohiah/evemu_Crucible) | Verified source = current main |
| P1-F75 | [almirosmanovic/evemu_Crucible](https://github.com/almirosmanovic/evemu_Crucible) | Verified source = current main |
| P1-F76 | [JiwekLabs/evemu_Crucible](https://github.com/JiwekLabs/evemu_Crucible) | Verified source = current main |
| P1-F77 | [xxdolcexx/evemu_Crucible](https://github.com/xxdolcexx/evemu_Crucible) | Verified source = current main |
| P1-F78 | [dkstiler/evemu_Crucible](https://github.com/dkstiler/evemu_Crucible) | Verified source = current main |
| P1-F79 | [ganymedex/evemu_Crucible](https://github.com/ganymedex/evemu_Crucible) | Verified source = current main |
| P1-F80 | [sonicj/evemu_Crucible](https://github.com/sonicj/evemu_Crucible) | Verified source = current main |
| P1-F81 | [masternerdguy/evemu_Crucible](https://github.com/masternerdguy/evemu_Crucible) | Verified source = current main |
| P1-F82 | [KaldarAralay/evemu_Crucible](https://github.com/KaldarAralay/evemu_Crucible) | Verified source = current main |
| P1-F83 | [SantjagoCorkez/evemu_Crucible](https://github.com/SantjagoCorkez/evemu_Crucible) | Verified source = current main |
| P1-F84 | [Valkyrien04/evemu_Crucible](https://github.com/Valkyrien04/evemu_Crucible) | Verified source = current main |
| P1-F85 | [AlbertPope/evemu_Crucible](https://github.com/AlbertPope/evemu_Crucible) | Verified source = current main |
| P1-F86 | [nicti/evemu_Crucible](https://github.com/nicti/evemu_Crucible) | Verified source = current main |
| P1-F87 | [Worlgun/evemu_Crucible](https://github.com/Worlgun/evemu_Crucible) | Verified source = current main |
| P1-F88 | [ZyenDomani/evemu_Crucible](https://github.com/ZyenDomani/evemu_Crucible) | Verified source = current main |
| P1-F89 | [kroryon/evemu_Crucible](https://github.com/kroryon/evemu_Crucible) | Verified source = current main |
| P1-F90 | [zhyrohaad/evemu_Crucible](https://github.com/zhyrohaad/evemu_Crucible) | Verified source = current main |
| P1-F91 | [katz1/evemu_Crucible](https://github.com/katz1/evemu_Crucible) | Verified source = current main |
| P1-F92 | [fumikejin/evemu_Crucible](https://github.com/fumikejin/evemu_Crucible) | Verified source = current main |
| P1-F93 | [rhammond17/evemu_Crucible](https://github.com/rhammond17/evemu_Crucible) | Verified source = current main |
| P1-F94 | [alive1986/evemu_Crucible](https://github.com/alive1986/evemu_Crucible) | Verified source = current main |
| P1-F95 | [jdhirst/evemu_Crucible](https://github.com/jdhirst/evemu_Crucible) | Verified source = current main |
| P1-F96 | [CyborgYL/evemu_Crucible](https://github.com/CyborgYL/evemu_Crucible) | Verified source = current main |
| P1-F97 | [brandonbelisle/evemu_Crucible](https://github.com/brandonbelisle/evemu_Crucible) | Verified source = current main |
| P1-F98 | [xchgeax/evemu_Crucible](https://github.com/xchgeax/evemu_Crucible) | Verified source = current main |
| P1-F99 | [Trav41514/evemu_Crucible](https://github.com/Trav41514/evemu_Crucible) | Verified source = current main |
| P1-F100 | [Stranho/evemu_Crucible](https://github.com/Stranho/evemu_Crucible) | Verified source = current main |
| P1-F101 | [mcp77/evemu_Crucible](https://github.com/mcp77/evemu_Crucible) | Verified source = current main |
| P1-F102 | [boldblue/evemu_Crucible](https://github.com/boldblue/evemu_Crucible) | Verified source = current main |
| P1-F103 | [solette1/evemu_Crucible](https://github.com/solette1/evemu_Crucible) | Verified source = current main |
| P1-F104 | [TohkaPrincess/evemu_Crucible](https://github.com/TohkaPrincess/evemu_Crucible) | Verified source = current main |
| P1-F105 | [Stars-22/evemu_Crucible](https://github.com/Stars-22/evemu_Crucible) | Verified source = current main |
| P1-F106 | [robertbriggsgames/evemu_Crucible](https://github.com/robertbriggsgames/evemu_Crucible) | Verified source = current main |
| P1-F107 | [VizanArkonin/evemu_Crucible](https://github.com/VizanArkonin/evemu_Crucible) | Verified source = current main |
| P1-F108 | [FrostSoul/evemu_Crucible](https://github.com/FrostSoul/evemu_Crucible) | Verified source = current main |
| P1-F109 | [hrluo93/evemu_Crucible](https://github.com/hrluo93/evemu_Crucible) | Verified source = current main |
| P1-F110 | [closet13/evemu_Crucible](https://github.com/closet13/evemu_Crucible) | Verified source = current main |
| P1-F111 | [FeenieRU/evemu_Crucible](https://github.com/FeenieRU/evemu_Crucible) | Verified source = current main |
| P1-F112 | [comet0/evemu_crucible](https://github.com/comet0/evemu_crucible) | Verified source = current main |
| P1-F113 | [melkordoran/evemu_Crucible](https://github.com/melkordoran/evemu_Crucible) | Verified source = current main |
| P1-F114 | [ThisIsSietandre/evemu_Crucible](https://github.com/ThisIsSietandre/evemu_Crucible) | Verified source = current main |
| P1-F115 | [marsara9/evemu_Crucible](https://github.com/marsara9/evemu_Crucible) | Verified source = current main |
| P1-F116 | [SySAttic/evemu_Crucible](https://github.com/SySAttic/evemu_Crucible) | Verified source = current main |
| P1-F117 | [chuengeric2020/evemu_Crucible_ch](https://github.com/chuengeric2020/evemu_Crucible_ch) | Verified source = current main |
| P1-F118 | [rumpelstompskin/evemu_Crucible_Claude](https://github.com/rumpelstompskin/evemu_Crucible_Claude) | Verified source = current main |
| P1-F119 | [mythkina/evemu_Crucible-1](https://github.com/mythkina/evemu_Crucible-1) | Verified source = current main |
| P1-F120 | [Black007Angel/evemu_Crucible-physics](https://github.com/Black007Angel/evemu_Crucible-physics) | Verified source = current main |
| P1-F121 | **Unidentified / reserved** | GitHub reports additional forks; owner not yet verified |
| P1-F122 | **Unidentified / reserved** | GitHub reports additional forks; owner not yet verified |
| P1-F123 | **Unidentified / reserved** | GitHub reports additional forks; owner not yet verified |

### Exclusions and adjacent repositories
- **Legacy lineage (different main):** [`evemuproject/evemu_crucible`](https://github.com/evemuproject/evemu_crucible), from the older 2012 repository network. Not `P1-M0`.
- **Older-lineage fork excluded:** [`mythkina/evemu_crucible`](https://github.com/mythkina/evemu_crucible) has `source.full_name=evemuproject/evemu_crucible` and was excluded even though its name appears in modern-repo searches.
- **Other EVEmu organization projects:** `EvEmu-Project/EVEDBTool`, `EvEmu-Project/evemu_SDK`, and `EvEmu-Project/evemu_web` are companion repositories, not forks. During P1-M0, check the database tool and SDK as **build/runtime dependencies**, not as numbered Crucible forks.
- **Separate branches and PR branches:** not counted as additional repositories. P1 records will inventory materially relevant branches inside each named repository.

### Per-repository durable checkpoint format
Create one standalone Library document, `P1-M0_Analysis.md` or `P1-F###_Analysis.md`, after each completed inspection, with: fixed URL/repository ID/branch/commit SHA; setup and data dependencies; mining-focused subsystem findings; test evidence; applicability to offline solo play; regressions and legal notes; next action. If interrupted, only the current uncheckpointed inspection is at risk. Then update the main master index. P2 adds tests/evidence to the same per-repository record or a companion `P2-...` record; P3 compares the verified improvement ledger.

### P1 execution schedule
1. **P1-M0 first:** architecture/readme, database schema, build/runtime on Windows x86-64, exact compatible client requirements, mining/refining/market and travel code paths, then save checkpoint.
2. **P1-F1 … P1-F120:** run systematic high-level source assessment, checkpoint each immediately. Prioritize evidence of changed mining/economy/travel/gameplay, but do not skip entry-level review of low-activity forks.
3. **P1-F121 … P1-F123:** reserved pending discovery. Do not falsely mark reviewed. Reconcile count or explicitly close as unavailable/hidden/deleted with evidence.
4. **P2:** targeted behavior tests on promising forks only; frozen test fixtures and repeatable outcomes.
5. **P3:** merge/no-merge recommendations and a simple three-zone plus optional wormhole implementation roadmap.

### Initial architectural hypotheses — not confirmed test results
The current main's published changelog **claims** features including a MarketBot, automatic market seeding, wormholes, NPC AI and server-side functionality, but those claims require source-level inspection and tests to establish actual playability. A mining-first offline build likely needs (i) a stable movement/mining/refining/inventory loop, (ii) simulated NPC buy orders or economy pricing, (iii) minimal locations/stations and save persistence, (iv) an optional wormhole route, and (v) a lawful client/asset strategy. The project should avoid full-universe reproduction and avoid wasting work merging trivial forks.


---

## P1-F1–F120 checkpoint — 2026-10-27

**Completed:** GitHub repository metadata, main-branch ancestry comparisons and additional-branch name inventory for all 120 named forks. Full methodology and 120-row results: `Eve-Mu_P1_Fork_Survey_Report.md`; structured record: `Eve-Mu_P1_Fork_Registry.json`.

- `master` comparisons: **34 identical, 46 behind, 30 diverged, 9 ahead, and 1 uncomparable** (no common ancestor).
- **70 forks** expose nondefault branches (**205 additional branch names**); some branches may be inherited/copies and are not yet evaluated as improvements.
- P2 leads: F118 (market, wormhole, NPC systems), F120 (MarketBotMgr, inventory, physics), F2 (broad server features), F12 (API), F69 (protocol/agents), F97 (ship physics), and branches addressing commerce, industry, NPC spawns or player bots. These are **unverified implementation leads**, not gameplay claims.
- P1 residuals: 3 unresolved fork counter names remain outside F1–F120; exact branch commit SHA snapshots, build compatibility and gameplay tests remain pending. **Do not mark P2 complete.**
- **Fixed player objective:** smallest stable offline Windows-local world with high-sec corporate hub ↔ medium-sec frontier ↔ null-sec frontier, plus optional wormhole accessible only from medium-sec; ore mining/refining/selling/persistence take precedence over full-universe simulation.

### P2 next checkpoint
Inspect code and migrations in highest-value fork branches and verify functional differences. Save evidence per repository and checkpoint before incorporating changes.


---

## P2 checkpoint — 80 forks with no independent default-branch work (2026-10-27)

- Completed GitHub comparative screening of **all 80** forks with `master` identical/behind and **all 148** associated non-default branches; source code/documents inspected for leading candidates, but **no builds or gameplay verification** yet.
- **31** forks have no other branches, **6** have alternative branches with no upstream-ahead work, and **43** have some alternative branch history ahead of current upstream; shared historical branches mean these are not 43 independent improvements.
- Strongest targeted P2 leads: **P1-F42 `Mrinnovvation/evemu_Crucible`** (`fixes/2026-10-15-combat-and-fitting`, 429 ahead), **P1-F59 `sargentscrufy/evemu_Crucible`** (`phase-1-commerce`, 178 ahead). Additional relevant work: F63 Trader Joe, F50 combat missions/autopilot, F7 movement, F106 belt rat spawn, F38 market SQL index, F1 tutorial/warp and F76 inventory.
- False lead: F108 `player-bot` compares identical to upstream; it is not evidence of a new bot implementation. The 33 `destiny-rework` branches are behind current main; 20 `dungeon_editor` branches largely repeat older variants.
- Evidence stored at `/Eve-Mu/Eve-Mu_P2_80Fork_Findings.md`, `/Eve-Mu/Eve-Mu_P2_80Fork_Branch_Audit.md`, and `/Eve-Mu/Eve-Mu_P2_80Fork_Branch_Audit.json`. No work has been performed on GitHub.
- Next engineering phase: pin commits, independently build F59/F42, verify lawful compatible client and database, test mining→cargo→refining→market→save/reload on one system, then expand to four small connected systems. Record functional improvements only after tests.

---

## Scope and client-side research decision — 2026-10-27
**User decision:** No distribution; this is a personal educational investigation of MMORPG space simulation. **Primary track:** EVEmu server and corresponding Crucible-era client behavior together, with a private local mining experience as the experimental target. **Alternative original game:** deferred option only if technically necessary or desirable, not a predetermined pivot.

### Client research track (C0–C5)
1. **C0 — Client availability and provenance:** Identify compatible historical build(s), documented client protocol/API assumptions, whether any lawfully available source exists, and distinguish binaries, static data, assets, tooling, and server-provided data. Do not assume the client is open-source.
2. **C1 — Connection flow:** Map startup, version checks, login handshake, session creation, character creation/selection, world entry and logout; align with `src/eve-common/network`, `src/eve-server/Client.cpp` and packet serialization, documenting evidence and uncertainties.
3. **C2 — Gameplay round trips:** For undock → travel → asteroid targeting → mining module cycle → inventory → docking → refining → sell order, record client request, server handler, database effects, response/notification and UI behavior.
4. **C3 — Presentation and static data:** Identify what the historical client renders locally (ships, HUD, effects, maps, objects), which static IDs/resources must match, and what maps/station UIs cannot be freely changed server-side.
5. **C4 — Local reproducibility:** On user-controlled Windows x86-64 environment, verify startup and loopback session, capture traces only where lawfully/technically available, and run controlled tests. Avoid claiming success without a real client session.
6. **C5 — Architectural lessons:** Produce diagrams and implementation notes for authority boundaries, prediction/synchronization, persistence, NPC simulation, economy and server scalability; inform a possible original game only later.

**Confirmed reference from upstream source:** `EvEmu-Project/evemu_Crucible/src/eve-common/EVEVersion.h` specifies Crucible v1.6.5, build 360229, protocol/version constants including `MachoNetVersion = 320`. This is a declared target, not a demonstrated connection in our environment.

### Server research track (S0–S4)
- S0: Baseline source build, databases/config, C++ services, packet schemas, license provenance.
- S1: Compare priority forks (F42, F59, F118, F120, F2 and focused branches) by actual code behavior and tests, not commit counts or README promises.
- S2: Trace mining, item/inventory state, refining/manufacturing, NPC markets and bot pilots.
- S3: Trace travel and movement, gates, security-zone behavior, wormholes and NPC/asteroid spawning.
- S4: End-to-end local tests and evidence ledger with reproducible configurations and failures.

**Research gates:** distinguish publicly inspectable server source from proprietary client source; preserve exact source versions, do not redistribute client binaries/assets or presume client source access; analyze observable protocols and permitted local files without bypassing access controls. Documentation and research may be kept in the private Eve-Mu Library.

**Checkpoint deliverable:** `/Eve-Mu/Eve-Mu_Client_Server_Educational_Research_Charter.md` — scope, tracks, detailed client/server test matrix.



---

## Server P2 source-reconnaissance checkpoint — 2026-10-27

**User clarification:** The 120-fork inventory and 80-fork branch census were designed to *find candidates for later careful code review*, not certify improvements; preserve this distinction in all research. The locally held ~10 GB historical client remains untouched, and its deep analysis is deferred to another day. The user also identified a possible **future independently developed original space game** informed by general MMORPG architecture lessons; do not automatically pivot away from the current private educational EVEmu study or assume proprietary software/assets can be copied.

**New evidence report:** `/Eve-Mu/Eve-Mu_P2_Server_Code_Trace_2026-10-27.md`. The initial source trace confirms upstream mining/refining/market/belt mechanisms; F42's market simulation source is actually integrated into server startup, main loop and order execution, but requires specialized calibration tables and independent testing; F59 includes meaningful protocol-based market/industry/refining QA scripts but pre-stages database state and has not been independently run; F118 and F120 do not modify upstream mining and refining blobs, though both may have useful changes elsewhere.

**Not accomplished:** executable server build, migrations, end-to-end client/server tests, benchmarks, complete code reviews, or final integration decisions. Continue P2 with precise diff/provenance and isolated tests; P3 decisions follow only after independent verification.

---

## 2026-10-27 — P2 Detailed Source Comparison, Pass A (saved checkpoint)

**Document:** `/Eve-Mu/Eve-Mu_P2_Detailed_Server_Code_Review_2026-10-27.md`  
**Runnable acceptance-plan register (15 not-yet-run cases):** `/Eve-Mu/Eve-Mu_P2_Server_Test_Matrix_2026-10-27.csv`

**Snapshot head commits:** M0 `f55b488a006e3090470d3b481aee47a1d7a0dade`; F59 `0fa6cac5422902d28c29358d694dd7369b9eb407`; F42 `c88496f6f08a6488b57bbe9e3f5e3a61fd2da092`; `rennr/evemu_Revised` `2f1675b9d710bdb1158cbbd5cf46858a0e9e341a`.

**Findings:** F59 has a narrow Crucible-era ore-hold compatibility candidate that removes routing to `flagOreHold` for ore/ice; F42 removed a lifetime guard present in Revised's `MiningLaser.cpp`, creating a credible cargo-full null-dereference path; the F42/Revised market sell handler logs and continues after a failed `SpawnItem` even though `DBTransaction` auto-commits on destructor. Revised/F42's belt persistence and asteroid regrowth code is substantially more developed than M0's, but runtime efficacy remains untested. F42's BeltMgr, ReprocessingService, MarketMgr, SimLedger and ServerMarketGateway blobs are **identical to Revised**; the actual source-lineage attribution matters. F59 includes concrete market/refining/industry QA scripts, but they stage fixtures in SQL; no clean normal-play end-to-end pass has been independently shown.

**Classification:** Source-reviewed candidates and source-level risk findings. Zero independently run original-server tests, zero client tests; no fork approved to merge. **Next:** isolate failure injection and asteroid round-trip tests; separately examine F42 versus Revised changed interfaces and required data migrations, then run test suites only against clean isolated environments. Maintain read-only original EVE client policy and private educational scope. The option of eventually developing an independently implemented original game remains deferred, not assumed.

---

## 2026-10-27 — P2 S2-A Initial Isolated Fault-Injection Tests (executed)

**Documents:**
- `/Eve-Mu/Eve-Mu_P2_S2A_Isolated_Test_Report_2026-10-27.md` — source provenance, execution and limitations.
- `/Eve-Mu/Eve-Mu_P2_S2A_Isolated_Test_Bundle_2026-10-27.zip` — compilable C++17/SQLite behavioral model, source, sanitizer log, test manifest and status matrix.
- `/Eve-Mu/Eve-Mu_P2_Server_Test_Matrix_2026-10-27.csv` — updated: only four of fifteen cases have isolated-model evidence; **all** still require EVEmu runtime verification.

**Environment:** Linux x86-64 research container, g++ C++17, SQLite in-memory fixture and ASan/UBSan. Direct GitHub clone failed due to DNS and no full EVEmu source checkout or MariaDB/client executable was available; GitHub source read through authorized read-only connector. Repository heads pinned to the same SHA identifiers from P2 Pass A.

**Execution:** Seven isolated behavior checks returned expected results (7/7). This includes expected reproduction of an inconsistent commit on an item-spawn-failure model, a missing target on synchronous cargo-full deactivation in the F42-like model, nested mining-volume discrepancy in a Revised-like model, upstream asteroid radius growth across synthetic roundtrips and the F59 ore hold selection. A reference explicit rollback model retains the SQLite invariants. None of this is equivalent to running the original server; the harness uses reduced models of observed control flow, not linked original classes. The sanitizer run did not trigger memory issues in the safe harness because it intentionally detects null use by throwing instead of dereferencing. A GitHub workflow-run lookup returned no matching runs for any pinned target commit; this is not a build verdict.

**Priority next:** (1) obtain/compile original fork source in a reproducible environment (eventual Win x86-64 target), (2) test F42 vs Revised partial-cargo activation with instrumentation, (3) inject `SpawnItem()` non-SQL failure and verify market journal/ownership/escrow and explicit rollback, (4) test belt radius and quantities against real database and server restart; (5) run and extend F59 headless protocol tests, noting direct DB pre-staging. Keep historical client local and untouched pending user-directed client analysis; do not change GitHub or merge before the above gates.

---

## 2026-10-27 — P2 S2-B Source-extracted Original C++ Tests (executed)

**New evidence:** `/Eve-Mu/Eve-Mu_P2_S2B_Original_Source_Test_Report_2026-10-27.md` and `/Eve-Mu/Eve-Mu_P2_S2B_Original_Source_Test_Bundle_2026-10-27.zip`; updated `/Eve-Mu/Eve-Mu_P2_Server_Test_Matrix_2026-10-27.csv` with stronger source-body evidence **without marking real-server gates complete**.

**What was actually executed:** Original/transcribed method bodies from public pinned EVEmu C++ files compiled with a C++17 compiler and UBSan against small test-only dependency replacements: `SimEconomy.cpp` (11 checks), F42 asteroid functions (9), F42's `DBTransaction` class (4), original upstream `AsteroidSE::Grow` (1), and F42/Revised `MiningLaser::ProcessCycle` normal and partial cargo (4). **29 checked outcomes**, including one deliberately expected nonzero failing execution, all matched the test runner's expectations. On partial cargo, the source-extracted F42 mining method emitted a UBSan null-pointer member-call diagnostic. The Revised method completed but removed more ore than the simulated hold received; this **may arise from the mocked reentrant module/ship behavior** and is not a proven production discrepancy. The upstream Grow method leaves quantity unchanged and disables its timer; Revised/F42's Grow has working quantity restoration logic in the isolated test.

**Boundary:** This is original source-function execution, not a complete upstream/F42/Revised server build. Header and manager dependencies were simulated; Revised miner body reconstructed from the separately read public diff. GitHub Git clone was blocked by container DNS. MariaDB/InnoDB, real item factory, original `ActiveModule` and `ShipItem` integrated execution, real item persistence, actual 10GB client and Win x86-64 binary remain **NOT TESTED**. An extracted `DBTransaction` destructor auto-commit test is not itself a complete market `FillAgainstSellOrder` production defect reproduction.

**Next real integration targets:** clean source checkout, linked production `MiningLaser` + module manager/inventory with sanitizer, actual `MarketMgr`/`DBcore` + MariaDB failure injection and transaction rollback, `BeltMgr`/`ManagerDB` actual save/reload and growth. Do not select a fork, merge, or claim a gameplay pass without these gates. No GitHub or local historical client changes were made.


---

## P2 S2-C checkpoint — first-login seeded marketplace (2026-10-27)

**User priority:** Past independent EVEmu testing found empty markets even though mining mechanics appeared workable. Eve-Mu must guarantee that a new player can purchase starter goods and sell mined ores/minerals at first login in the limited universe. Do not prioritize extra mining debugging over this immediate bootstrapping contract.

**Source-verified findings:** M0 has legacy seed SQL with fixed 2020 timestamps, random/wide seeding, and no proven backing; Trader Joe delays its initial cycle and randomly picks items. F42/Revised has ledger-backed NPC economy, but calibration and startup quote scheduling do not guarantee a curated ready starter catalog at the instant a player first enters. F42 `IsBackedNpcOrder` explicitly refuses legacy fake NPC orders. Prefer its simulator/gateway for future native integration; no source was merged or modified.

**S2-C done:** built an **original independent SQLite/Python prototype** `Eve-Mu_P2_S2C_First_Login_Market_Readiness_Report.md` + reproducible ZIP containing a synthetic 3-station, 14-order starter market with actual reserved buyer cash/seller stock in the fixture, one-time atomic issuance, price/owner/station/time validation and strict startup-ready gate. Automated test result: **26/26 passed**. Includes order expiry, failure injection, buy/sell proof, restart and exhausted-item fail-closed behavior. These are not original EVEmu/production server integration tests; 15 earlier full-server gates remain open.

**Next S2-D:** resolve real EVE static item/station IDs and compatible starter equipment; build/link F42 market sim and migrations with MariaDB; implement bounded early market quote/flush and a native readiness barrier, then prove real market RPC purchases/sales, accounting and reboot persistence before any client-local analysis. Keep original 10 GB client entirely local and untouched until the user reauthorizes client analysis.

---

## 2026-10-27 — S2-D Historical SQL Crosswalk and Price-Aware Bootstrap Adapter

**User decisions:** EVEmu included SQL becomes the initial static-data authority. Missing data may be researched from public CCP/community references. The compact offline universe must have a functional starter market immediately, with prices reduced by configurable multiples of ten (default experimental 20x), but coherent commodity/refining pricing, order backing and economics.

**Verified directly:** Six `staStations` historical tuples (hub candidate Jita 60003760) and `invTypeMaterials` outputs for Veldspar, Scordite, Pyroxeres, Plagioclase and Kernite. Source Git blob SHAs and rows are captured in `/Eve-Mu/Eve-Mu_S2-D_Validated_Data_and_Bootstrap_Report_2026-10-27.md`. The larger compressed `invTypes` exists but the repository connector returned zero content. Consequently full row-level ID/name/published/marketGroupID/basePrice/portionSize **verification remains OPEN**, not a pass.

**Implemented:** `Eve-Mu_S2D_Starter_Market_Integration_2026-10-27.zip` contains read-only SQL.gz parser/candidate verifier; a seven-offer Jita starter policy using real published ID *candidates*; optional documented price anchors; conservative ore pricing from material yields/portion size; compatible `evemu-sde-validated-prototype` SQLite catalog adapter; native F42 `MarketSimMgr` immediate seed *proposal* (NOT applied); read-only live-market SQL diagnostics; station and recipe excerpts; instructions; and tests. **42/42 tests passed**, 26 old S2-C checks + 16 adapter checks; adapter inputs fabricated but visibly labeled, no production DB or real invTypes tests.

**Gates still open:** Run verifier with entire `invTypes.sql.gz`, align market anchors/refining/rewards with historical base data, choose actual compact map and non-high-sec stations, apply F42 market sim migrations and build, patch/review startup posting and true `CanFill` readiness checks, verify real MariaDB/Client trades and restart. Do not treat the optional patch as a server installation or a passed native gate. No 10GB client files touched, no GitHub mutations.

## S2-E — Native starter-market stage (2026-10-27, provisional)

User authorized verifying the complete historical `invTypes.sql.gz` item records, integrating a backed market bootstrap into F42/Revised, and running live MariaDB transactions. **These three production milestones are not completed.** The large 1,096,511-byte `invTypes` gzip was recognized/pinned in GitHub but inaccessible as bytes through the available connector and runtime DNS. MariaDB server/CLI are absent and cannot be installed due DNS restrictions. Do not promote candidate item rows to validated status.

New reviewable candidate source package `Eve-Mu_S2E_Production_Market_Stage_2026-10-27.zip` contains C++17 first-login market readiness core, native F42 adapter, 20x monetary anchor price-scaling helper, direct source patch, header generator gated on complete original SQL.gz hashes, guarded disposable MariaDB engine probe, source refs and logs. Verified code contexts include `World::Requote`, `RunUntilIdle`, `MarketSimMgr::Initialize`, `World::Orders`, ledger accounts/stock, `MarketDB::GetOrderInfo`, and server startup call; native patch not applied, `git apply --check` against full repo not run, no Windows build. Native header cannot be produced without verified item dump.

**Executed locally:** 42 earlier S2-D Python SQLite regression checks, 15 C++ readiness checks, 4 C++ reference price-scaling checks, 4 native-bridge mock interface checks, 10 Python catalog hash/required-SKU gate checks; all **75 isolated tests passed**. MariaDB probe returned `BLOCKED (77)`. Full EVEmu market, SQL migrations, real trade/rollback, client, and reboot tests still open. No source or GitHub mutations and no client files touched.

Next: obtain public 1.1 MB compressed `invTypes` dump by permitted means, run the fail-closed verifier (ensure actual output is from original rows, not fabricated fixtures), generate verified native requirements, apply patch on a pinned isolated branch, build and run migrated native MariaDB server, inspect `mktOrders`/sim ledger, fault-inject actual item delivery and order fill, verify repeat bootstrap, rebalance the scaled economy and its starting wallet.


---

## Decision ED-01 — Eve-Mu Desktop Edition, approved 2026-10-27

**User decision:** Prioritize a Windows x86-64 zero-configuration, one-click desktop application for private offline-first Eve-Mu. Ordinary users must not need to install Git, Go, a database server, or use a terminal or SQL commands. Deliver the EVEmu server, portable per-user MariaDB runtime, precompiled database migrator, historical static-data payload, backed starter-market bootstrap, process supervisor, UI health feedback, compatible user-supplied client detection, backups/restore, safe updater and installer as one coordinated product. Preserve personal universe data separately from installed binaries. The user-provided compatible historical client remains separate and is not bundled. This does not authorize modifying the user's existing MariaDB database/service or any GitHub repository.

**Architecture record and phased acceptance gates:** `Eve-Mu_ED01_Desktop_Edition_Architecture_and_Roadmap_2026-10-27.md` (same Library folder). Work tracks ED-M00 source/manifests, ED-M01 native build, ED-M02 GUI shell, ED-M03 portable DB, ED-M04 first-run schema, ED-M05 starter market, ED-M06 server lifecycle, ED-M07 client attachment, ED-M08 backup/update/repair, ED-M09 clean-Windows validation. Continue historical server/market testing as enabling work, not as a consumer setup burden. The first actionable coding spike is a minimal launcher and process supervisor that can launch a test double without requiring a client or user-installed dependencies.

**Observed PC status from screenshot (not remotely verified by tools):** MariaDB 13.0.2 on port 3306 is running; isolated `evemu_test` was created with zero tables; Git 2.56.0 installed; Go not recognized. All ED production gates remain unpassed as of decision acceptance.


## Decision ED-01A — A truly single consumer launcher, not a Docker/server-admin experience (2026-10-27)

**Confirmed refinement from user:** Eve-Mu will expose **one** Windows x86-64 desktop application, one installer/package, one normal desktop shortcut and one **Play** action. The typical player must never need Docker, Docker Desktop, WSL, CLI/PowerShell, Git, Go, separately installed MariaDB, manual SQL/schema loading, or server process management. Repair, backup, restore, logs, diagnostics and settings are built into the *same* launcher rather than separate user-installed tools. The compatible user-supplied historical EVE client may need to be located once; it is not redistributed without rights.

The launcher privately supervises packaged native EVEmu, bundled portable MariaDB, prebuilt migrations, verified first-login market bootstrap, and optional client as internal child processes. **One user-facing app does not mean a single OS process.** All backend services stay off the public network by default; persistent universe data is protected from updates/uninstall; no mutation of the user's existing MariaDB instance. Mainline Windows installation, launch, test and packaging must function **without Docker**.

**New ED-M09 mandatory acceptance gate:** on a clean offline Windows x86-64 VM containing no Git, Go, Docker, WSL, SQL client or system MariaDB service: install Eve-Mu once, select compatible independent client once if needed, click Play, buy a starter item and sell ore; no manual commands or second application; confirm restart/repair/backup from within launcher. Development status unchanged: not yet implemented.

Detailed normative UX and milestone implications are in `Eve-Mu_ED01_Desktop_Edition_Architecture_and_Roadmap_2026-10-27.md`, section 8.
