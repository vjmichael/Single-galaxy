-- READ ONLY: validate proposed TypeIDs against the EXACT EVEmu instance used for Eve-Mu.
-- '2012 compatibility' requires checking the Crucible 1.6/1.6.5 dataset, not merely a modern site.
SELECT typeID, typeName, groupID, marketGroupID, published, basePrice
FROM invTypes
WHERE typeID IN (18, 20, 22, 34, 35, 36, 37, 38, 39, 40, 444, 483, 582, 592, 648, 1223, 1224, 1225, 1227, 1228, 1230, 1317, 2454, 3651, 10246, 17476, 17478, 17480, 17482, 22542)
ORDER BY typeID;

-- Investigate whether any proposed items are missing, unpublished, or lack a market group.
-- For a chosen start station, verify its system/region/owner before creating any orders:
SELECT stationID, stationName, solarSystemID, regionID, corporationID
FROM staStations
WHERE stationID IN (60003760,60008494,60011866,60004588,60005686);

-- Count existing market orders, by station and bid/ask, BEFORE any seeding.
-- Bid format is 1=buy, 0=sell in EVEmu mktOrders.
SELECT stationID, typeID, bid, COUNT(*) AS orders, SUM(volRemaining) AS units
FROM mktOrders
WHERE volRemaining > 0
GROUP BY stationID, typeID, bid
ORDER BY stationID, typeID, bid;
