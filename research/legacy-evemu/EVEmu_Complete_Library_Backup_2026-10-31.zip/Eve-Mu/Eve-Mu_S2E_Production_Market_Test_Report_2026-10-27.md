# Eve-Mu S2-E — Production market integration: execution report
Date: 2026-10-27

## Acceptance gates (do NOT conflate isolated tests with integration)

| Gate | Status | Evidence |
|---|---|---|
| Full `invTypes.sql.gz` item-row verification (30 candidates; required seven offers) | **BLOCKED** | GitHub provides blob SHA `dbc7250a4ea22e99f5722fc1be9b18c37621b866` and 1,096,511-byte size, but the connector suppresses its content and the runtime has no external DNS. Actual `invTypes` row checks remain unexecuted. |
| Historical station records, subset of refinery materials | **PREVIOUSLY VERIFIED** | EVEmu SQL dump compressed rows fetched/decompressed: `staStations.sql.gz` and `invTypeMaterials.sql.gz`. Some ingredient recipes obtained; `portionSize` remains unverified without `invTypes`. |
| S2-D SQLite prototype test regression | **PASS 42/42** | `logs/prior_s2d_regression.log`; *fabricated* item metadata. |
| C++ order/escrow readiness logic | **PASS 15/15** | `logs/native_asan.log`; isolated native code compiled with sanitizers. |
| C++ whole-anchor 20× monetary policy | **PASS 4/4** | `logs/price_policy_tests.log`; no production price calibration performed. |
| Native bridge against EVEmu-shaped test interfaces | **PASS 4/4** | `logs/native_bridge_mock_tests.log`; mocks not full server headers. |
| Verified-catalog/header emitter | **PASS 10/10** | `logs/catalog_emitter_tests.log`; fabricated file inputs used to exercise refusal/acceptance. **No real verified catalog emitted.** |
| F42 original source patch parsing and expected call sites | **PARTIAL** | `git apply --numstat` parsed patch; GitHub fetched `MarketSimMgr.cpp` blob `9c4e84e2f2ac0a35baa1ea98baeea70f24b7fa89` and `eve-server.cpp` blob `3a6d72188ea72d40c3b688c0aa4c0228bfc02dce`, with required call-site strings. No full `git apply --check` or compile against repository. |
| Native EVEmu market integration | **PREPARED, NOT APPLIED** | C++ header + F42 source patch inside `native/`. Missing genuine generated item catalog and native checkout. |
| MariaDB/InnoDB live transaction test | **BLOCKED** | `logs/mariadb_probe.log`: no MariaDB CLI/server. `apt-get update` failed due external DNS. Probe exited 77. |
| Full server market buy/sell, rollback, restart, windows x86-64 and historical client | **NOT RUN** | No full checkout/migrated MariaDB server or game client executed. |

## Executed count

**75 / 75 isolated unit/prototype checks passed**: 42 Python SQLite regression + 15 C++ reservation checker + 4 C++ scaling + 4 C++ native adapter mock + 10 Python manifest emitter tests. This does **not** close any of the blocked production gates above.

## Key source findings

- Upstream EVEmu includes an automatic market seed option (`SEED_MARKET`) and `seed_market.sql`, but those legacy order rows do not satisfy F42/Revised `IsBackedNpcOrder` / `CanFill` checks. Never treat a visible order as buyable or sellable without backing.
- F42 `World::Seed` creates stock/funds as one-time faucets; `World::Requote(typeID,now)` can schedule quotes without a second stock/funds seed; `RunUntilIdle` flushes due work. Provisional patch uses this safer startup path.
- `MarketSimMgr` requires `mktCal*` calibration migrations and enabled simulation. It currently logs missing market as disabled without failing startup. Provisional patch converts this into fail-closed server startup, checks source-validated required SKUs, persisted orders, reserved goods/ISK, write-behind state and price-policy version.
- 20× price reduction must be applied to calibrated fair-price references, estimated build cost and NPC vendor base prices together. Startup refuses to reuse saved state generated under a different divisor. Actual economic balance and non-`TypeData` fees remain open.
- For an EVEmu native server test, also verify settlement with `MarketMgr::FillAgainstBuyOrder` and `FillAgainstSellOrder`, `MarketSimDB`, `MarketDB` and a real MariaDB transaction. A disposable temporary-table probe alone is insufficient.

## Exact code references

- `https://github.com/EvEmu-Project/evemu_Crucible/tree/f55b488a006e3090470d3b481aee47a1d7a0dade/sql/base`
- `https://github.com/Mrinnovvation/evemu_Crucible/blob/c88496f6f08a6488b57bbe9e3f5e3a61fd2da092/src/eve-server/market/sim/MarketSimMgr.cpp`
- `https://github.com/Mrinnovvation/evemu_Crucible/blob/c88496f6f08a6488b57bbe9e3f5e3a61fd2da092/src/eve-server/market/sim/SimWorld.cpp`
- `https://github.com/Mrinnovvation/evemu_Crucible/blob/c88496f6f08a6488b57bbe9e3f5e3a61fd2da092/src/eve-server/market/MarketMgr.cpp`
- `https://github.com/EvEmu-Project/evemu_Crucible/blob/master/docker-compose.yml`

## Next executable acceptance sequence

1. Download the public 1.1 MB `invTypes.sql.gz` file and run `build_starter_catalog.py` on original bytes alongside actual station/material dumps. Verify the 30 rows and fail on missing, unpublished, wrong name/group, invalid price, or bad portion size. Do **not** substitute a modern CSV for historical source.
2. Use `emit_verified_native_catalog.py` to produce `EveMuVerifiedStarterCatalog.h`. The candidate patch intentionally has an unresolved include until a genuine verified manifest exists.
3. Obtain the exact F42 checkout at the pinned revision; `git apply --check`, review and compile native C++ code. Never push to GitHub before tests.
4. Install/run MariaDB locally against an isolated database with original migrations, and run the guarded engine test and server integration tests, including startup, quote persistence, buy/sell, fault injection, and repeat boot.
5. Validate client visibility, refine profitability, ISK scale, starter-wallet economics, seller stock, NPC buy escrow and Windows x86-64 behavior.

No GitHub modifications, no destructive data writes, no local EVE client access.
