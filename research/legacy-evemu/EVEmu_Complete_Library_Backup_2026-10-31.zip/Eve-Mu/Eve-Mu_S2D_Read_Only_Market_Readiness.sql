-- READ-ONLY diagnostic for F42/Revised after mktSim* migrations are applied.
-- Not intended for original upstream without the simulation tables.
-- Identifies posted market orders that can be associated with sim ownership.
-- Further runtime checks MUST call MarketSimMgr::CanFill() for order validation.
SELECT o.orderID,o.stationID,o.typeID,o.bid,o.price,o.volRemaining,
       s.actorID,s.nodeID,
       a.wallet AS sim_wallet_cents,a.reserved AS sim_reserved_cents,
       i.qty AS sim_free_stock,i.reservedQty AS sim_reserved_stock
FROM mktOrders AS o
JOIN mktSimOrder AS s ON s.orderID=o.orderID
LEFT JOIN mktSimActor AS a ON a.actorID=s.actorID
LEFT JOIN mktSimInventory AS i ON i.actorID=s.actorID
 AND i.nodeID=s.nodeID AND i.typeID=s.typeID
WHERE o.stationID=60003760 AND o.typeID IN (582,483,444,1317,1230,1228,34)
  AND o.volRemaining>0
ORDER BY o.typeID,o.bid,o.price;

-- Detect unbacked sale offers at the order-owner / item / node level.
SELECT s.actorID,s.nodeID,s.typeID,
       SUM(o.volRemaining) AS quantity_on_asks,
       COALESCE(i.reservedQty,0) AS reserved_in_ledger
FROM mktOrders o JOIN mktSimOrder s ON o.orderID=s.orderID
LEFT JOIN mktSimInventory i ON i.actorID=s.actorID AND i.nodeID=s.nodeID AND i.typeID=s.typeID
WHERE o.bid=0 AND o.volRemaining>0
GROUP BY s.actorID,s.nodeID,s.typeID,i.reservedQty
HAVING SUM(o.volRemaining)>COALESCE(i.reservedQty,0);

-- Detect buy orders whose aggregate obligations exceed ledger escrow.
-- Cents are rounded to match market-sim's integer-cents convention.
SELECT s.actorID,
       SUM(ROUND(o.price*100)*o.volRemaining) AS outstanding_buy_cents,
       MAX(COALESCE(a.reserved,0)) AS ledger_reserved_cents
FROM mktOrders o JOIN mktSimOrder s ON o.orderID=s.orderID
LEFT JOIN mktSimActor a ON a.actorID=s.actorID
WHERE o.bid=1 AND o.volRemaining>0
GROUP BY s.actorID
HAVING SUM(ROUND(o.price*100)*o.volRemaining)>MAX(COALESCE(a.reserved,0));

-- Independently check historical metadata in the loaded EVEmu database.
SELECT t.typeID,t.typeName,t.published,t.marketGroupID,t.basePrice,t.portionSize,
       t.groupID,g.categoryID
FROM invTypes t JOIN invGroups g ON g.groupID=t.groupID
WHERE t.typeID IN (582,483,444,1317,1230,1228,34,35)
ORDER BY t.typeID;

-- Read-only per-unit ore yield: multiply mineral quantities by refinery yield
-- and divide by ore's historical portionSize before pricing a buy order.
SELECT m.typeID AS oreTypeID,t.typeName,t.portionSize,
       m.materialTypeID,minerals.typeName AS mineral,m.quantity AS yield_per_batch
FROM invTypeMaterials m
JOIN invTypes t ON t.typeID=m.typeID
JOIN invTypes minerals ON minerals.typeID=m.materialTypeID
WHERE m.typeID IN (1230,1228,1224,18,20)
ORDER BY m.typeID,m.materialTypeID;
