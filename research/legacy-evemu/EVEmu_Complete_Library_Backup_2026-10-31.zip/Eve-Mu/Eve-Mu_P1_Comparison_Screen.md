# Eve-Mu — P1 upstream divergence screening

**Checked:** 120 of 120 named forks; **screen date:** 2026-10-27.

Each result compares `EvEmu-Project/evemu_Crucible:master` to the fork’s `master` using GitHub compare. This reports commit ancestry and a file count, not whether the fork contains a good change. No builds or gameplay tests have run.

**Current distribution:** identical=34, ahead=9, behind=46, diverged=30, error=1

| Fork ID | Repository | Relationship | Ahead | Behind | Files in compare |
|---|---|---|---:|---:|---:|
| P1-F1 | [ozatomic/evemu_crucible_current](https://github.com/ozatomic/evemu_crucible_current) | identical | 0 | 0 | 0 |
| P1-F2 | [AzediZ/evemu_Crucible](https://github.com/AzediZ/evemu_Crucible) | ahead | 51 | 0 | 174 |
| P1-F3 | [ion9/evemu_Crucible](https://github.com/ion9/evemu_Crucible) | behind | 0 | 395 | 0 |
| P1-F4 | [triple111/evemu_Crucible](https://github.com/triple111/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F5 | [GameModForks/evemu_Crucible](https://github.com/GameModForks/evemu_Crucible) | diverged | 2 | 243 | 1 |
| P1-F6 | [ToddRosenkrantz/evemu_Crucible](https://github.com/ToddRosenkrantz/evemu_Crucible) | diverged | 3 | 382 | 5 |
| P1-F7 | [ziggozoggo/evemu_crucible](https://github.com/ziggozoggo/evemu_crucible) | identical | 0 | 0 | 0 |
| P1-F8 | [pet1100/evemu_crucible](https://github.com/pet1100/evemu_crucible) | identical | 0 | 0 | 0 |
| P1-F9 | [chengood5000/evemu_Crucible](https://github.com/chengood5000/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F10 | [chuengjoanna/evemu_Crucible](https://github.com/chuengjoanna/evemu_Crucible) | behind | 0 | 1 | 0 |
| P1-F11 | [luokery/evemu_Crucible](https://github.com/luokery/evemu_Crucible) | diverged | 1 | 243 | 1 |
| P1-F12 | [pixelcatburglar/evemu_Crucible](https://github.com/pixelcatburglar/evemu_Crucible) | ahead | 7 | 0 | 82 |
| P1-F13 | [DavidStinson/evemu_Crucible](https://github.com/DavidStinson/evemu_Crucible) | diverged | 2 | 243 | 1 |
| P1-F14 | [bnaambo/evemu_Crucible](https://github.com/bnaambo/evemu_Crucible) | behind | 0 | 243 | 0 |
| P1-F15 | [novafacing/evemu_Crucible](https://github.com/novafacing/evemu_Crucible) | diverged | 2 | 243 | 1 |
| P1-F16 | [sangohan/evemu_Crucible](https://github.com/sangohan/evemu_Crucible) | diverged | 2 | 243 | 1 |
| P1-F17 | [idolord/evemu_Crucible](https://github.com/idolord/evemu_Crucible) | diverged | 1 | 67 | 2 |
| P1-F18 | [ImTorbin/evemu_Crucible3.0](https://github.com/ImTorbin/evemu_Crucible3.0) | identical | 0 | 0 | 0 |
| P1-F19 | [cingulari/evemu_Crucible](https://github.com/cingulari/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F20 | [seren1tyy/evemu_Crucible](https://github.com/seren1tyy/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F21 | [locvez/evemu_Crucible](https://github.com/locvez/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F22 | [strikersix23/evemu_Crucible](https://github.com/strikersix23/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F23 | [d10sfan/evemu_Crucible](https://github.com/d10sfan/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F24 | [charles-m-knox/evemu_Crucible](https://github.com/charles-m-knox/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F25 | [Avi-E-Koenig/evemu_Crucible](https://github.com/Avi-E-Koenig/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F26 | [chuengeric/evemu_Crucible](https://github.com/chuengeric/evemu_Crucible) | ahead | 3 | 0 | 13 |
| P1-F27 | [dd667/evemu_Crucible](https://github.com/dd667/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F28 | [x0S37h0x/evemu_Crucible](https://github.com/x0S37h0x/evemu_Crucible) | diverged | 6 | 243 | 5 |
| P1-F29 | [DeerHunt3r/evemu_Crucible](https://github.com/DeerHunt3r/evemu_Crucible) | diverged | 2 | 383 | 1 |
| P1-F30 | [SilverXarrow/evemu_Crucible](https://github.com/SilverXarrow/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F31 | [devedse/evemu_Crucible](https://github.com/devedse/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F32 | [01Hub/evemu_Crucible](https://github.com/01Hub/evemu_Crucible) | diverged | 1 | 243 | 1 |
| P1-F33 | [phillipwgardner/evemu_Crucible](https://github.com/phillipwgardner/evemu_Crucible) | diverged | 5 | 243 | 4 |
| P1-F34 | [alycecil/evemu_Crucible](https://github.com/alycecil/evemu_Crucible) | diverged | 5 | 243 | 4 |
| P1-F35 | [donato/evemu_Crucible](https://github.com/donato/evemu_Crucible) | diverged | 6 | 1 | 8 |
| P1-F36 | [swaric/evemu_Crucible](https://github.com/swaric/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F37 | [afarazit/evemu_Crucible](https://github.com/afarazit/evemu_Crucible) | diverged | 5 | 243 | 4 |
| P1-F38 | [kenneaal/evemu_Crucible](https://github.com/kenneaal/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F39 | [dawa11/evemu_Crucible](https://github.com/dawa11/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F40 | [soesbeek/evemu_crucible](https://github.com/soesbeek/evemu_crucible) | diverged | 1 | 1 | 1 |
| P1-F41 | [PHX-TeamPhoenix/evemu_Crucible](https://github.com/PHX-TeamPhoenix/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F42 | [Mrinnovvation/evemu_Crucible](https://github.com/Mrinnovvation/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F43 | [gatesry/evemu_Crucible](https://github.com/gatesry/evemu_Crucible) | diverged | 3 | 380 | 3 |
| P1-F44 | [rrfarmer/evemu_Crucible](https://github.com/rrfarmer/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F45 | [AceGamesUser/evemu_Crucible](https://github.com/AceGamesUser/evemu_Crucible) | diverged | 1 | 30 | 2 |
| P1-F46 | [SynieztroLedPar/evemu_Crucible](https://github.com/SynieztroLedPar/evemu_Crucible) | diverged | 6 | 243 | 5 |
| P1-F47 | [I-89762345-I/evemu_Crucible](https://github.com/I-89762345-I/evemu_Crucible) | behind | 0 | 243 | 0 |
| P1-F48 | [sephcasiah/evemu_Crucible](https://github.com/sephcasiah/evemu_Crucible) | behind | 0 | 1 | 0 |
| P1-F49 | [d4rkf0x/evemu_Crucible](https://github.com/d4rkf0x/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F50 | [dgerabagi/evemu_Crucible](https://github.com/dgerabagi/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F51 | [xrizonx/evemu_Crucible](https://github.com/xrizonx/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F52 | [gebainixyz/evemu_Crucible](https://github.com/gebainixyz/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F53 | [Almamu/evemu_crucible](https://github.com/Almamu/evemu_crucible) | diverged | 7 | 243 | 4 |
| P1-F54 | [Pursche/evemu_Crucible](https://github.com/Pursche/evemu_Crucible) | diverged | 3 | 243 | 2 |
| P1-F55 | [Mezzarius/evemu_Crucible](https://github.com/Mezzarius/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F56 | [hxhieu/evemu_Crucible](https://github.com/hxhieu/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F57 | [SpirytusMoe/evemu_Crucible](https://github.com/SpirytusMoe/evemu_Crucible) | behind | 0 | 243 | 0 |
| P1-F58 | [AviiNL/evemu_Crucible](https://github.com/AviiNL/evemu_Crucible) | diverged | 2 | 1 | 5 |
| P1-F59 | [sargentscrufy/evemu_Crucible](https://github.com/sargentscrufy/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F60 | [GrumpyDrago/evemu_Crucible](https://github.com/GrumpyDrago/evemu_Crucible) | diverged | 3 | 243 | 2 |
| P1-F61 | [favoms/evemu_Crucible](https://github.com/favoms/evemu_Crucible) | behind | 0 | 243 | 0 |
| P1-F62 | [salartarium/evemu_Crucible](https://github.com/salartarium/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F63 | [celinor1982/evemu_Crucible](https://github.com/celinor1982/evemu_Crucible) | behind | 0 | 1 | 0 |
| P1-F64 | [aliyajadzia/evemu_Crucible](https://github.com/aliyajadzia/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F65 | [kroryan/evemu_Crucible](https://github.com/kroryan/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F66 | [innocentius/evemu_Crucible](https://github.com/innocentius/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F67 | [no23/evemu_Crucible](https://github.com/no23/evemu_Crucible) | ahead | 1 | 0 | 1 |
| P1-F68 | [beelitzs/evemu_Crucible](https://github.com/beelitzs/evemu_Crucible) | behind | 0 | 1 | 0 |
| P1-F69 | [jionychiow/evemu_Crucible](https://github.com/jionychiow/evemu_Crucible) | diverged | 10 | 1 | 80 |
| P1-F70 | [tylerengland89/evemu_Crucible](https://github.com/tylerengland89/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F71 | [Conan1996-2/evemu_Crucible](https://github.com/Conan1996-2/evemu_Crucible) | ahead | 8 | 0 | 3 |
| P1-F72 | [wytsa/evemu_Crucible](https://github.com/wytsa/evemu_Crucible) | behind | 0 | 243 | 0 |
| P1-F73 | [Gargash/evemu_Crucible](https://github.com/Gargash/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F74 | [TheOneJohiah/evemu_Crucible](https://github.com/TheOneJohiah/evemu_Crucible) | diverged | 2 | 243 | 1 |
| P1-F75 | [almirosmanovic/evemu_Crucible](https://github.com/almirosmanovic/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F76 | [JiwekLabs/evemu_Crucible](https://github.com/JiwekLabs/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F77 | [xxdolcexx/evemu_Crucible](https://github.com/xxdolcexx/evemu_Crucible) | diverged | 1 | 243 | 1 |
| P1-F78 | [dkstiler/evemu_Crucible](https://github.com/dkstiler/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F79 | [ganymedex/evemu_Crucible](https://github.com/ganymedex/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F80 | [sonicj/evemu_Crucible](https://github.com/sonicj/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F81 | [masternerdguy/evemu_Crucible](https://github.com/masternerdguy/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F82 | [KaldarAralay/evemu_Crucible](https://github.com/KaldarAralay/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F83 | [SantjagoCorkez/evemu_Crucible](https://github.com/SantjagoCorkez/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F84 | [Valkyrien04/evemu_Crucible](https://github.com/Valkyrien04/evemu_Crucible) | diverged | 1 | 243 | 1 |
| P1-F85 | [AlbertPope/evemu_Crucible](https://github.com/AlbertPope/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F86 | [nicti/evemu_Crucible](https://github.com/nicti/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F87 | [Worlgun/evemu_Crucible](https://github.com/Worlgun/evemu_Crucible) | error | -1 | -1 | -1 |
| P1-F88 | [ZyenDomani/evemu_Crucible](https://github.com/ZyenDomani/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F89 | [kroryon/evemu_Crucible](https://github.com/kroryon/evemu_Crucible) | behind | 0 | 1 | 0 |
| P1-F90 | [zhyrohaad/evemu_Crucible](https://github.com/zhyrohaad/evemu_Crucible) | behind | 0 | 244 | 0 |
| P1-F91 | [katz1/evemu_Crucible](https://github.com/katz1/evemu_Crucible) | behind | 0 | 380 | 0 |
| P1-F92 | [fumikejin/evemu_Crucible](https://github.com/fumikejin/evemu_Crucible) | behind | 0 | 243 | 0 |
| P1-F93 | [rhammond17/evemu_Crucible](https://github.com/rhammond17/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F94 | [alive1986/evemu_Crucible](https://github.com/alive1986/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F95 | [jdhirst/evemu_Crucible](https://github.com/jdhirst/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F96 | [CyborgYL/evemu_Crucible](https://github.com/CyborgYL/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F97 | [brandonbelisle/evemu_Crucible](https://github.com/brandonbelisle/evemu_Crucible) | ahead | 16 | 0 | 6 |
| P1-F98 | [xchgeax/evemu_Crucible](https://github.com/xchgeax/evemu_Crucible) | behind | 0 | 243 | 0 |
| P1-F99 | [Trav41514/evemu_Crucible](https://github.com/Trav41514/evemu_Crucible) | behind | 0 | 243 | 0 |
| P1-F100 | [Stranho/evemu_Crucible](https://github.com/Stranho/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F101 | [mcp77/evemu_Crucible](https://github.com/mcp77/evemu_Crucible) | behind | 0 | 243 | 0 |
| P1-F102 | [boldblue/evemu_Crucible](https://github.com/boldblue/evemu_Crucible) | diverged | 1 | 243 | 1 |
| P1-F103 | [solette1/evemu_Crucible](https://github.com/solette1/evemu_Crucible) | ahead | 2 | 0 | 2 |
| P1-F104 | [TohkaPrincess/evemu_Crucible](https://github.com/TohkaPrincess/evemu_Crucible) | behind | 0 | 1 | 0 |
| P1-F105 | [Stars-22/evemu_Crucible](https://github.com/Stars-22/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F106 | [robertbriggsgames/evemu_Crucible](https://github.com/robertbriggsgames/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F107 | [VizanArkonin/evemu_Crucible](https://github.com/VizanArkonin/evemu_Crucible) | behind | 0 | 244 | 0 |
| P1-F108 | [FrostSoul/evemu_Crucible](https://github.com/FrostSoul/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F109 | [hrluo93/evemu_Crucible](https://github.com/hrluo93/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F110 | [closet13/evemu_Crucible](https://github.com/closet13/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F111 | [FeenieRU/evemu_Crucible](https://github.com/FeenieRU/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F112 | [comet0/evemu_crucible](https://github.com/comet0/evemu_crucible) | diverged | 3 | 1 | 5 |
| P1-F113 | [melkordoran/evemu_Crucible](https://github.com/melkordoran/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F114 | [ThisIsSietandre/evemu_Crucible](https://github.com/ThisIsSietandre/evemu_Crucible) | identical | 0 | 0 | 0 |
| P1-F115 | [marsara9/evemu_Crucible](https://github.com/marsara9/evemu_Crucible) | behind | 0 | 30 | 0 |
| P1-F116 | [SySAttic/evemu_Crucible](https://github.com/SySAttic/evemu_Crucible) | diverged | 1 | 30 | 1 |
| P1-F117 | [chuengeric2020/evemu_Crucible_ch](https://github.com/chuengeric2020/evemu_Crucible_ch) | behind | 0 | 1 | 0 |
| P1-F118 | [rumpelstompskin/evemu_Crucible_Claude](https://github.com/rumpelstompskin/evemu_Crucible_Claude) | ahead | 41 | 0 | 42 |
| P1-F119 | [mythkina/evemu_Crucible-1](https://github.com/mythkina/evemu_Crucible-1) | diverged | 3 | 243 | 2 |
| P1-F120 | [Black007Angel/evemu_Crucible-physics](https://github.com/Black007Angel/evemu_Crucible-physics) | ahead | 5 | 0 | 30 |

## Follow-on source inspections

- Forks marked `ahead` or `diverged` merit P2 comparison of actual changed subsystems, error handling, behavior and build support.
- Forks marked `behind` may have historical implementations, but have no fork-only commits on this branch relative to the current upstream.
- Forks marked `identical` contain no unique commits on this branch at this snapshot; inspect other branches before dismissing the repository entirely.
- GitHub compare limits file listings and commit histories; a reported count is not an exhaustive code review.
