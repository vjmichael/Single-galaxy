# Eve-Mu — P1-F1–F120 Individual Fork Records

**Date:** 2026-10-27  
**Status:** Every fork has publicly observed metadata, `master` ancestry comparison, and a branch-name inventory. Runtime and feature quality tests have not been done.

Comparisons are against `EvEmu-Project/evemu_Crucible:master`; ahead/behind counts indicate commit ancestry, not quality. Snapshot SHAs remain to be pinned for implementation-oriented P2.

## P1-F1 — ozatomic/evemu_crucible_current

- **Owner:** `ozatomic`; **repository:** [evemu_crucible_current](https://github.com/ozatomic/evemu_crucible_current); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `feature/tutorial-disable`, `fix/warp-formula-and-packets`, `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F2 — AzediZ/evemu_Crucible

- **Owner:** `AzediZ`; **repository:** [evemu_Crucible](https://github.com/AzediZ/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `ahead`; ahead `51` / behind `0`; GitHub changed-file count `174`.
- **Branches found:** `master`, `revised`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F3 — ion9/evemu_Crucible

- **Owner:** `ion9`; **repository:** [evemu_Crucible](https://github.com/ion9/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `395`; GitHub changed-file count `0`.
- **Branches found:** `dashboard/phpmyadmin`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F4 — triple111/evemu_Crucible

- **Owner:** `triple111`; **repository:** [evemu_Crucible](https://github.com/triple111/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`, `staging`, `testing`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F5 — GameModForks/evemu_Crucible

- **Owner:** `GameModForks`; **repository:** [evemu_Crucible](https://github.com/GameModForks/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `2` / behind `243`; GitHub changed-file count `1`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F6 — ToddRosenkrantz/evemu_Crucible

- **Owner:** `ToddRosenkrantz`; **repository:** [evemu_Crucible](https://github.com/ToddRosenkrantz/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `3` / behind `382`; GitHub changed-file count `5`.
- **Branches found:** `fix-108`, `master`, `patch-1`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F7 — ziggozoggo/evemu_crucible

- **Owner:** `ziggozoggo`; **repository:** [evemu_crucible](https://github.com/ziggozoggo/evemu_crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `feature/physics`, `fix/repair-service-and-warp-desync`, `master`, `stage`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F8 — pet1100/evemu_crucible

- **Owner:** `pet1100`; **repository:** [evemu_crucible](https://github.com/pet1100/evemu_crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `ozatomic/evemu_crucible_current`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `bugfix/undocking`, `dev`, `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F9 — chengood5000/evemu_Crucible

- **Owner:** `chengood5000`; **repository:** [evemu_Crucible](https://github.com/chengood5000/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F10 — chuengjoanna/evemu_Crucible

- **Owner:** `chuengjoanna`; **repository:** [evemu_Crucible](https://github.com/chuengjoanna/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `1`; GitHub changed-file count `0`.
- **Branches found:** `apple_compatible`, `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F11 — luokery/evemu_Crucible

- **Owner:** `luokery`; **repository:** [evemu_Crucible](https://github.com/luokery/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `1` / behind `243`; GitHub changed-file count `1`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F12 — pixelcatburglar/evemu_Crucible

- **Owner:** `pixelcatburglar`; **repository:** [evemu_Crucible](https://github.com/pixelcatburglar/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `ahead`; ahead `7` / behind `0`; GitHub changed-file count `82`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F13 — DavidStinson/evemu_Crucible

- **Owner:** `DavidStinson`; **repository:** [evemu_Crucible](https://github.com/DavidStinson/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `2` / behind `243`; GitHub changed-file count `1`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F14 — bnaambo/evemu_Crucible

- **Owner:** `bnaambo`; **repository:** [evemu_Crucible](https://github.com/bnaambo/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `243`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F15 — novafacing/evemu_Crucible

- **Owner:** `novafacing`; **repository:** [evemu_Crucible](https://github.com/novafacing/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `2` / behind `243`; GitHub changed-file count `1`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `patch/boost_1.74.0_compat`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F16 — sangohan/evemu_Crucible

- **Owner:** `sangohan`; **repository:** [evemu_Crucible](https://github.com/sangohan/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `2` / behind `243`; GitHub changed-file count `1`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F17 — idolord/evemu_Crucible

- **Owner:** `idolord`; **repository:** [evemu_Crucible](https://github.com/idolord/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `1` / behind `67`; GitHub changed-file count `2`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F18 — ImTorbin/evemu_Crucible3.0

- **Owner:** `ImTorbin`; **repository:** [evemu_Crucible3.0](https://github.com/ImTorbin/evemu_Crucible3.0); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F19 — cingulari/evemu_Crucible

- **Owner:** `cingulari`; **repository:** [evemu_Crucible](https://github.com/cingulari/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F20 — seren1tyy/evemu_Crucible

- **Owner:** `seren1tyy`; **repository:** [evemu_Crucible](https://github.com/seren1tyy/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F21 — locvez/evemu_Crucible

- **Owner:** `locvez`; **repository:** [evemu_Crucible](https://github.com/locvez/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F22 — strikersix23/evemu_Crucible

- **Owner:** `strikersix23`; **repository:** [evemu_Crucible](https://github.com/strikersix23/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F23 — d10sfan/evemu_Crucible

- **Owner:** `d10sfan`; **repository:** [evemu_Crucible](https://github.com/d10sfan/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dev`, `dungeon_editor`, `master`, `probe-crash`, `staging`, `test`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F24 — charles-m-knox/evemu_Crucible

- **Owner:** `charles-m-knox`; **repository:** [evemu_Crucible](https://github.com/charles-m-knox/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F25 — Avi-E-Koenig/evemu_Crucible

- **Owner:** `Avi-E-Koenig`; **repository:** [evemu_Crucible](https://github.com/Avi-E-Koenig/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F26 — chuengeric/evemu_Crucible

- **Owner:** `chuengeric`; **repository:** [evemu_Crucible](https://github.com/chuengeric/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `ahead`; ahead `3` / behind `0`; GitHub changed-file count `13`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F27 — dd667/evemu_Crucible

- **Owner:** `dd667`; **repository:** [evemu_Crucible](https://github.com/dd667/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `fix-108`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F28 — x0S37h0x/evemu_Crucible

- **Owner:** `x0S37h0x`; **repository:** [evemu_Crucible](https://github.com/x0S37h0x/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `6` / behind `243`; GitHub changed-file count `5`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F29 — DeerHunt3r/evemu_Crucible

- **Owner:** `DeerHunt3r`; **repository:** [evemu_Crucible](https://github.com/DeerHunt3r/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `2` / behind `383`; GitHub changed-file count `1`.
- **Branches found:** `#105`, `CommandCenter-pin-error`, `fix-108`, `master`, `patch-1`, `piPins-sql`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F30 — SilverXarrow/evemu_Crucible

- **Owner:** `SilverXarrow`; **repository:** [evemu_Crucible](https://github.com/SilverXarrow/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F31 — devedse/evemu_Crucible

- **Owner:** `devedse`; **repository:** [evemu_Crucible](https://github.com/devedse/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F32 — 01Hub/evemu_Crucible

- **Owner:** `01Hub`; **repository:** [evemu_Crucible](https://github.com/01Hub/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `1` / behind `243`; GitHub changed-file count `1`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F33 — phillipwgardner/evemu_Crucible

- **Owner:** `phillipwgardner`; **repository:** [evemu_Crucible](https://github.com/phillipwgardner/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `5` / behind `243`; GitHub changed-file count `4`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F34 — alycecil/evemu_Crucible

- **Owner:** `alycecil`; **repository:** [evemu_Crucible](https://github.com/alycecil/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `5` / behind `243`; GitHub changed-file count `4`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `main`, `master`, `staged`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F35 — donato/evemu_Crucible

- **Owner:** `donato`; **repository:** [evemu_Crucible](https://github.com/donato/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `6` / behind `1`; GitHub changed-file count `8`.
- **Branches found:** `3`, `cmake`, `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F36 — swaric/evemu_Crucible

- **Owner:** `swaric`; **repository:** [evemu_Crucible](https://github.com/swaric/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `feature/packet-capture`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F37 — afarazit/evemu_Crucible

- **Owner:** `afarazit`; **repository:** [evemu_Crucible](https://github.com/afarazit/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `5` / behind `243`; GitHub changed-file count `4`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F38 — kenneaal/evemu_Crucible

- **Owner:** `kenneaal`; **repository:** [evemu_Crucible](https://github.com/kenneaal/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `market-solarSystemIndex`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F39 — dawa11/evemu_Crucible

- **Owner:** `dawa11`; **repository:** [evemu_Crucible](https://github.com/dawa11/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F40 — soesbeek/evemu_crucible

- **Owner:** `soesbeek`; **repository:** [evemu_crucible](https://github.com/soesbeek/evemu_crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `1` / behind `1`; GitHub changed-file count `1`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F41 — PHX-TeamPhoenix/evemu_Crucible

- **Owner:** `PHX-TeamPhoenix`; **repository:** [evemu_Crucible](https://github.com/PHX-TeamPhoenix/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F42 — Mrinnovvation/evemu_Crucible

- **Owner:** `Mrinnovvation`; **repository:** [evemu_Crucible](https://github.com/Mrinnovvation/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `fix/gettimeparts-now`, `fixes/2026-10-15-combat-and-fitting`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F43 — gatesry/evemu_Crucible

- **Owner:** `gatesry`; **repository:** [evemu_Crucible](https://github.com/gatesry/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `3` / behind `380`; GitHub changed-file count `3`.
- **Branches found:** `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F44 — rrfarmer/evemu_Crucible

- **Owner:** `rrfarmer`; **repository:** [evemu_Crucible](https://github.com/rrfarmer/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F45 — AceGamesUser/evemu_Crucible

- **Owner:** `AceGamesUser`; **repository:** [evemu_Crucible](https://github.com/AceGamesUser/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `1` / behind `30`; GitHub changed-file count `2`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F46 — SynieztroLedPar/evemu_Crucible

- **Owner:** `SynieztroLedPar`; **repository:** [evemu_Crucible](https://github.com/SynieztroLedPar/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `6` / behind `243`; GitHub changed-file count `5`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F47 — I-89762345-I/evemu_Crucible

- **Owner:** `I-89762345-I`; **repository:** [evemu_Crucible](https://github.com/I-89762345-I/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `243`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F48 — sephcasiah/evemu_Crucible

- **Owner:** `sephcasiah`; **repository:** [evemu_Crucible](https://github.com/sephcasiah/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `1`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F49 — d4rkf0x/evemu_Crucible

- **Owner:** `d4rkf0x`; **repository:** [evemu_Crucible](https://github.com/d4rkf0x/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F50 — dgerabagi/evemu_Crucible

- **Owner:** `dgerabagi`; **repository:** [evemu_Crucible](https://github.com/dgerabagi/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `feature/autopilot-fix`, `feature/combat-missions`, `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F51 — xrizonx/evemu_Crucible

- **Owner:** `xrizonx`; **repository:** [evemu_Crucible](https://github.com/xrizonx/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F52 — gebainixyz/evemu_Crucible

- **Owner:** `gebainixyz`; **repository:** [evemu_Crucible](https://github.com/gebainixyz/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F53 — Almamu/evemu_crucible

- **Owner:** `Almamu`; **repository:** [evemu_crucible](https://github.com/Almamu/evemu_crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `7` / behind `243`; GitHub changed-file count `4`.
- **Branches found:** `master`, `refactor/python-types-rewrite`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F54 — Pursche/evemu_Crucible

- **Owner:** `Pursche`; **repository:** [evemu_Crucible](https://github.com/Pursche/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `3` / behind `243`; GitHub changed-file count `2`.
- **Branches found:** `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F55 — Mezzarius/evemu_Crucible

- **Owner:** `Mezzarius`; **repository:** [evemu_Crucible](https://github.com/Mezzarius/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F56 — hxhieu/evemu_Crucible

- **Owner:** `hxhieu`; **repository:** [evemu_Crucible](https://github.com/hxhieu/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `chore/hxh-dockerfile`, `chore/local-debug`, `chore/pyrep-lite-build`, `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F57 — SpirytusMoe/evemu_Crucible

- **Owner:** `SpirytusMoe`; **repository:** [evemu_Crucible](https://github.com/SpirytusMoe/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `243`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F58 — AviiNL/evemu_Crucible

- **Owner:** `AviiNL`; **repository:** [evemu_Crucible](https://github.com/AviiNL/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `2` / behind `1`; GitHub changed-file count `5`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F59 — sargentscrufy/evemu_Crucible

- **Owner:** `sargentscrufy`; **repository:** [evemu_Crucible](https://github.com/sargentscrufy/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `master`, `phase-0-foundation`, `phase-1-commerce`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F60 — GrumpyDrago/evemu_Crucible

- **Owner:** `GrumpyDrago`; **repository:** [evemu_Crucible](https://github.com/GrumpyDrago/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `3` / behind `243`; GitHub changed-file count `2`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F61 — favoms/evemu_Crucible

- **Owner:** `favoms`; **repository:** [evemu_Crucible](https://github.com/favoms/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `243`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F62 — salartarium/evemu_Crucible

- **Owner:** `salartarium`; **repository:** [evemu_Crucible](https://github.com/salartarium/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `patch-1`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F63 — celinor1982/evemu_Crucible

- **Owner:** `celinor1982`; **repository:** [evemu_Crucible](https://github.com/celinor1982/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `1`; GitHub changed-file count `0`.
- **Branches found:** `dbupgrade`, `destiny-rework`, `dungeon_editor`, `master`, `staging`, `staging_autopilot`, `staging_test`, `staging_traderjoe_1_0`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F64 — aliyajadzia/evemu_Crucible

- **Owner:** `aliyajadzia`; **repository:** [evemu_Crucible](https://github.com/aliyajadzia/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F65 — kroryan/evemu_Crucible

- **Owner:** `kroryan`; **repository:** [evemu_Crucible](https://github.com/kroryan/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F66 — innocentius/evemu_Crucible

- **Owner:** `innocentius`; **repository:** [evemu_Crucible](https://github.com/innocentius/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F67 — no23/evemu_Crucible

- **Owner:** `no23`; **repository:** [evemu_Crucible](https://github.com/no23/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `ahead`; ahead `1` / behind `0`; GitHub changed-file count `1`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F68 — beelitzs/evemu_Crucible

- **Owner:** `beelitzs`; **repository:** [evemu_Crucible](https://github.com/beelitzs/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `1`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F69 — jionychiow/evemu_Crucible

- **Owner:** `jionychiow`; **repository:** [evemu_Crucible](https://github.com/jionychiow/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `10` / behind `1`; GitHub changed-file count `80`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F70 — tylerengland89/evemu_Crucible

- **Owner:** `tylerengland89`; **repository:** [evemu_Crucible](https://github.com/tylerengland89/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F71 — Conan1996-2/evemu_Crucible

- **Owner:** `Conan1996-2`; **repository:** [evemu_Crucible](https://github.com/Conan1996-2/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `ahead`; ahead `8` / behind `0`; GitHub changed-file count `3`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F72 — wytsa/evemu_Crucible

- **Owner:** `wytsa`; **repository:** [evemu_Crucible](https://github.com/wytsa/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `243`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F73 — Gargash/evemu_Crucible

- **Owner:** `Gargash`; **repository:** [evemu_Crucible](https://github.com/Gargash/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F74 — TheOneJohiah/evemu_Crucible

- **Owner:** `TheOneJohiah`; **repository:** [evemu_Crucible](https://github.com/TheOneJohiah/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `2` / behind `243`; GitHub changed-file count `1`.
- **Branches found:** `destiny-rework`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F75 — almirosmanovic/evemu_Crucible

- **Owner:** `almirosmanovic`; **repository:** [evemu_Crucible](https://github.com/almirosmanovic/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F76 — JiwekLabs/evemu_Crucible

- **Owner:** `JiwekLabs`; **repository:** [evemu_Crucible](https://github.com/JiwekLabs/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `feature/stationmenus`, `inventory`, `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F77 — xxdolcexx/evemu_Crucible

- **Owner:** `xxdolcexx`; **repository:** [evemu_Crucible](https://github.com/xxdolcexx/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `1` / behind `243`; GitHub changed-file count `1`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F78 — dkstiler/evemu_Crucible

- **Owner:** `dkstiler`; **repository:** [evemu_Crucible](https://github.com/dkstiler/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `destiny-staging`, `fix-108`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F79 — ganymedex/evemu_Crucible

- **Owner:** `ganymedex`; **repository:** [evemu_Crucible](https://github.com/ganymedex/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F80 — sonicj/evemu_Crucible

- **Owner:** `sonicj`; **repository:** [evemu_Crucible](https://github.com/sonicj/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F81 — masternerdguy/evemu_Crucible

- **Owner:** `masternerdguy`; **repository:** [evemu_Crucible](https://github.com/masternerdguy/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `defect/20260607-incorrect-spawn-class`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F82 — KaldarAralay/evemu_Crucible

- **Owner:** `KaldarAralay`; **repository:** [evemu_Crucible](https://github.com/KaldarAralay/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F83 — SantjagoCorkez/evemu_Crucible

- **Owner:** `SantjagoCorkez`; **repository:** [evemu_Crucible](https://github.com/SantjagoCorkez/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `boost_174_build_fix`, `destiny-rework`, `giveallskills_fix`, `iHub_management_open`, `master`, `odb_models`, `staging`, `target_destroyed_modules_deactivate_segfault`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F84 — Valkyrien04/evemu_Crucible

- **Owner:** `Valkyrien04`; **repository:** [evemu_Crucible](https://github.com/Valkyrien04/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `1` / behind `243`; GitHub changed-file count `1`.
- **Branches found:** `feature-env-var-support`, `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F85 — AlbertPope/evemu_Crucible

- **Owner:** `AlbertPope`; **repository:** [evemu_Crucible](https://github.com/AlbertPope/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F86 — nicti/evemu_Crucible

- **Owner:** `nicti`; **repository:** [evemu_Crucible](https://github.com/nicti/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F87 — Worlgun/evemu_Crucible

- **Owner:** `Worlgun`; **repository:** [evemu_Crucible](https://github.com/Worlgun/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `error`; ahead `unavailable` / behind `unavailable`; GitHub changed-file count `unavailable`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.
- **Comparison exception:** GitHub compare failed: no common ancestor between upstream master and fork master (HTTP 404). Fork metadata is available, but comparable lineage is not established for master.

## P1-F88 — ZyenDomani/evemu_Crucible

- **Owner:** `ZyenDomani`; **repository:** [evemu_Crucible](https://github.com/ZyenDomani/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F89 — kroryon/evemu_Crucible

- **Owner:** `kroryon`; **repository:** [evemu_Crucible](https://github.com/kroryon/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `1`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F90 — zhyrohaad/evemu_Crucible

- **Owner:** `zhyrohaad`; **repository:** [evemu_Crucible](https://github.com/zhyrohaad/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `244`; GitHub changed-file count `0`.
- **Branches found:** `allan-destiny`, `destiny-rework`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F91 — katz1/evemu_Crucible

- **Owner:** `katz1`; **repository:** [evemu_Crucible](https://github.com/katz1/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `380`; GitHub changed-file count `0`.
- **Branches found:** `manufacturing-fix`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F92 — fumikejin/evemu_Crucible

- **Owner:** `fumikejin`; **repository:** [evemu_Crucible](https://github.com/fumikejin/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `243`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F93 — rhammond17/evemu_Crucible

- **Owner:** `rhammond17`; **repository:** [evemu_Crucible](https://github.com/rhammond17/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F94 — alive1986/evemu_Crucible

- **Owner:** `alive1986`; **repository:** [evemu_Crucible](https://github.com/alive1986/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F95 — jdhirst/evemu_Crucible

- **Owner:** `jdhirst`; **repository:** [evemu_Crucible](https://github.com/jdhirst/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`, `missions_rework`, `posplot`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F96 — CyborgYL/evemu_Crucible

- **Owner:** `CyborgYL`; **repository:** [evemu_Crucible](https://github.com/CyborgYL/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F97 — brandonbelisle/evemu_Crucible

- **Owner:** `brandonbelisle`; **repository:** [evemu_Crucible](https://github.com/brandonbelisle/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `ahead`; ahead `16` / behind `0`; GitHub changed-file count `6`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F98 — xchgeax/evemu_Crucible

- **Owner:** `xchgeax`; **repository:** [evemu_Crucible](https://github.com/xchgeax/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `243`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F99 — Trav41514/evemu_Crucible

- **Owner:** `Trav41514`; **repository:** [evemu_Crucible](https://github.com/Trav41514/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `243`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F100 — Stranho/evemu_Crucible

- **Owner:** `Stranho`; **repository:** [evemu_Crucible](https://github.com/Stranho/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F101 — mcp77/evemu_Crucible

- **Owner:** `mcp77`; **repository:** [evemu_Crucible](https://github.com/mcp77/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `243`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F102 — boldblue/evemu_Crucible

- **Owner:** `boldblue`; **repository:** [evemu_Crucible](https://github.com/boldblue/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `1` / behind `243`; GitHub changed-file count `1`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F103 — solette1/evemu_Crucible

- **Owner:** `solette1`; **repository:** [evemu_Crucible](https://github.com/solette1/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `ahead`; ahead `2` / behind `0`; GitHub changed-file count `2`.
- **Branches found:** `copilot/implement-faction-territory-warfare`, `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F104 — TohkaPrincess/evemu_Crucible

- **Owner:** `TohkaPrincess`; **repository:** [evemu_Crucible](https://github.com/TohkaPrincess/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `1`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F105 — Stars-22/evemu_Crucible

- **Owner:** `Stars-22`; **repository:** [evemu_Crucible](https://github.com/Stars-22/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F106 — robertbriggsgames/evemu_Crucible

- **Owner:** `robertbriggsgames`; **repository:** [evemu_Crucible](https://github.com/robertbriggsgames/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `Staging`, `belt-rat-spawns-(high-value,-isolated-diff)`, `destiny-move-desync-275`, `master`, `modules-loader`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F107 — VizanArkonin/evemu_Crucible

- **Owner:** `VizanArkonin`; **repository:** [evemu_Crucible](https://github.com/VizanArkonin/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `244`; GitHub changed-file count `0`.
- **Branches found:** `contracts_implementation`, `destiny-rework`, `master`, `revert-1-staging`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F108 — FrostSoul/evemu_Crucible

- **Owner:** `FrostSoul`; **repository:** [evemu_Crucible](https://github.com/FrostSoul/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`, `player-bot`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F109 — hrluo93/evemu_Crucible

- **Owner:** `hrluo93`; **repository:** [evemu_Crucible](https://github.com/hrluo93/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F110 — closet13/evemu_Crucible

- **Owner:** `closet13`; **repository:** [evemu_Crucible](https://github.com/closet13/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F111 — FeenieRU/evemu_Crucible

- **Owner:** `FeenieRU`; **repository:** [evemu_Crucible](https://github.com/FeenieRU/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F112 — comet0/evemu_crucible

- **Owner:** `comet0`; **repository:** [evemu_crucible](https://github.com/comet0/evemu_crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `3` / behind `1`; GitHub changed-file count `5`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F113 — melkordoran/evemu_Crucible

- **Owner:** `melkordoran`; **repository:** [evemu_Crucible](https://github.com/melkordoran/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F114 — ThisIsSietandre/evemu_Crucible

- **Owner:** `ThisIsSietandre`; **repository:** [evemu_Crucible](https://github.com/ThisIsSietandre/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `identical`; ahead `0` / behind `0`; GitHub changed-file count `0`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F115 — marsara9/evemu_Crucible

- **Owner:** `marsara9`; **repository:** [evemu_Crucible](https://github.com/marsara9/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `30`; GitHub changed-file count `0`.
- **Branches found:** `destiny-rework`, `dungeon_editor`, `feature/minor-fixes`, `feature/outpost-manufacturing`, `feature/pos-manufacturing`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F116 — SySAttic/evemu_Crucible

- **Owner:** `SySAttic`; **repository:** [evemu_Crucible](https://github.com/SySAttic/evemu_Crucible); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `1` / behind `30`; GitHub changed-file count `1`.
- **Branches found:** `dbupgrade`, `destiny-rework`, `dungeon_editor`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F117 — chuengeric2020/evemu_Crucible_ch

- **Owner:** `chuengeric2020`; **repository:** [evemu_Crucible_ch](https://github.com/chuengeric2020/evemu_Crucible_ch); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `behind`; ahead `0` / behind `1`; GitHub changed-file count `0`.
- **Branches found:** `beta_v0.1`, `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F118 — rumpelstompskin/evemu_Crucible_Claude

- **Owner:** `rumpelstompskin`; **repository:** [evemu_Crucible_Claude](https://github.com/rumpelstompskin/evemu_Crucible_Claude); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `ahead`; ahead `41` / behind `0`; GitHub changed-file count `42`.
- **Branches found:** `claude/wonderful-cori-veosq7`, `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F119 — mythkina/evemu_Crucible-1

- **Owner:** `mythkina`; **repository:** [evemu_Crucible-1](https://github.com/mythkina/evemu_Crucible-1); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `diverged`; ahead `3` / behind `243`; GitHub changed-file count `2`.
- **Branches found:** `fix-108`, `master`, `staging`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

## P1-F120 — Black007Angel/evemu_Crucible-physics

- **Owner:** `Black007Angel`; **repository:** [evemu_Crucible-physics](https://github.com/Black007Angel/evemu_Crucible-physics); **default branch:** `master`; **status:** public, not archived.
- **Source lineage:** `EvEmu-Project/evemu_Crucible`; **immediate parent:** `EvEmu-Project/evemu_Crucible`.
- **Main-branch ancestry comparison:** `ahead`; ahead `5` / behind `0`; GitHub changed-file count `30`.
- **Branches found:** `master`.
- **P1 outcome:** code branch and lineage surveyed; no feature-performance or gameplay claim. **P2 status:** unassessed.

