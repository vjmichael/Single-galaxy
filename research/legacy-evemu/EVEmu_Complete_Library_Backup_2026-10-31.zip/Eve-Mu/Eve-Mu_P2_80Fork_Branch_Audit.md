# Eve-Mu — P2 targeted branch audit: 80 master-identical or master-behind forks

**Research checkpoint:** 2026-10-27. **Scope:** 80 fork repositories, 148 named non-default branches across 49 forks. No live client/server/gameplay tests. Branch names alone are not proof of working improvements.

## Durable workflow
Each 80-fork record below is preserved; compare actual branch commit history, then inspect code for the promising branches. Do not treat common historical staging/destiny/dungeon branches as unique without evidence. Repeated copies share review findings.

**Current branch comparison results retained:** 148.

## Branch inspection matrix

| Fork | Default history | Other branches | Screened | Assessment |
|---|---|---|---:|---|
| P1-F1 [ozatomic/evemu_crucible_current](https://github.com/ozatomic/evemu_crucible_current) | identical | `feature/tutorial-disable`, `fix/warp-formula-and-packets` | 2 | TARGETED candidate: utility/warp/inventory/mission changes |
| P1-F3 [ion9/evemu_Crucible](https://github.com/ion9/evemu_Crucible) | behind | `dashboard/phpmyadmin`, `staging` | 2 | Limited or historical independent branch changes; low/medium priority |
| P1-F4 [triple111/evemu_Crucible](https://github.com/triple111/evemu_Crucible) | behind | `staging`, `testing` | 2 | Limited or historical independent branch changes; low/medium priority |
| P1-F7 [ziggozoggo/evemu_crucible](https://github.com/ziggozoggo/evemu_crucible) | identical | `feature/physics`, `fix/repair-service-and-warp-desync`, `stage` | 3 | HIGH candidate: movement, missions, economic activity, NPC spawn fixes |
| P1-F8 [pet1100/evemu_crucible](https://github.com/pet1100/evemu_crucible) | identical | `bugfix/undocking`, `dev` | 2 | TARGETED candidate: utility/warp/inventory/mission changes |
| P1-F9 [chengood5000/evemu_Crucible](https://github.com/chengood5000/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F10 [chuengjoanna/evemu_Crucible](https://github.com/chuengjoanna/evemu_Crucible) | behind | `apple_compatible` | 1 | Limited or historical independent branch changes; low/medium priority |
| P1-F14 [bnaambo/evemu_Crucible](https://github.com/bnaambo/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F18 [ImTorbin/evemu_Crucible3.0](https://github.com/ImTorbin/evemu_Crucible3.0) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F19 [cingulari/evemu_Crucible](https://github.com/cingulari/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F20 [seren1tyy/evemu_Crucible](https://github.com/seren1tyy/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F21 [locvez/evemu_Crucible](https://github.com/locvez/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F22 [strikersix23/evemu_Crucible](https://github.com/strikersix23/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F23 [d10sfan/evemu_Crucible](https://github.com/d10sfan/evemu_Crucible) | behind | `destiny-rework`, `dev`, `dungeon_editor`, `probe-crash`, `staging`, `test` | 6 | Limited or historical independent branch changes; low/medium priority |
| P1-F24 [charles-m-knox/evemu_Crucible](https://github.com/charles-m-knox/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F25 [Avi-E-Koenig/evemu_Crucible](https://github.com/Avi-E-Koenig/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F27 [dd667/evemu_Crucible](https://github.com/dd667/evemu_Crucible) | behind | `fix-108`, `staging` | 2 | Non-default branches present, but no ahead commits against current upstream |
| P1-F30 [SilverXarrow/evemu_Crucible](https://github.com/SilverXarrow/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F31 [devedse/evemu_Crucible](https://github.com/devedse/evemu_Crucible) | identical | `destiny-rework`, `staging` | 2 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F36 [swaric/evemu_Crucible](https://github.com/swaric/evemu_Crucible) | identical | `destiny-rework`, `feature/packet-capture`, `staging` | 3 | Limited or historical independent branch changes; low/medium priority |
| P1-F38 [kenneaal/evemu_Crucible](https://github.com/kenneaal/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `market-solarSystemIndex`, `staging` | 4 | TARGETED candidate: utility/warp/inventory/mission changes |
| P1-F39 [dawa11/evemu_Crucible](https://github.com/dawa11/evemu_Crucible) | identical | `destiny-rework`, `staging` | 2 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F41 [PHX-TeamPhoenix/evemu_Crucible](https://github.com/PHX-TeamPhoenix/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F42 [Mrinnovvation/evemu_Crucible](https://github.com/Mrinnovvation/evemu_Crucible) | identical | `destiny-rework`, `fix/gettimeparts-now`, `fixes/2026-10-15-combat-and-fitting`, `staging` | 4 | TOP candidate: extensive simulation, NPC economy/miners; author-tested claims |
| P1-F44 [rrfarmer/evemu_Crucible](https://github.com/rrfarmer/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F47 [I-89762345-I/evemu_Crucible](https://github.com/I-89762345-I/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F48 [sephcasiah/evemu_Crucible](https://github.com/sephcasiah/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F49 [d4rkf0x/evemu_Crucible](https://github.com/d4rkf0x/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F50 [dgerabagi/evemu_Crucible](https://github.com/dgerabagi/evemu_Crucible) | identical | `feature/autopilot-fix`, `feature/combat-missions` | 2 | HIGH candidate: movement, missions, economic activity, NPC spawn fixes |
| P1-F51 [xrizonx/evemu_Crucible](https://github.com/xrizonx/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F52 [gebainixyz/evemu_Crucible](https://github.com/gebainixyz/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F55 [Mezzarius/evemu_Crucible](https://github.com/Mezzarius/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F56 [hxhieu/evemu_Crucible](https://github.com/hxhieu/evemu_Crucible) | identical | `chore/hxh-dockerfile`, `chore/local-debug`, `chore/pyrep-lite-build`, `destiny-rework`, `dungeon_editor`, `staging` | 6 | Limited or historical independent branch changes; low/medium priority |
| P1-F57 [SpirytusMoe/evemu_Crucible](https://github.com/SpirytusMoe/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F59 [sargentscrufy/evemu_Crucible](https://github.com/sargentscrufy/evemu_Crucible) | identical | `destiny-rework`, `phase-0-foundation`, `phase-1-commerce`, `staging` | 4 | TOP candidate: private single-player-friendly economy + bots; author-tested claims |
| P1-F61 [favoms/evemu_Crucible](https://github.com/favoms/evemu_Crucible) | behind | `destiny-rework`, `staging` | 2 | Non-default branches present, but no ahead commits against current upstream |
| P1-F62 [salartarium/evemu_Crucible](https://github.com/salartarium/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `patch-1`, `staging` | 4 | Limited or historical independent branch changes; low/medium priority |
| P1-F63 [celinor1982/evemu_Crucible](https://github.com/celinor1982/evemu_Crucible) | behind | `dbupgrade`, `destiny-rework`, `dungeon_editor`, `staging`, `staging_autopilot`, `staging_test`, `staging_traderjoe_1_0` | 7 | HIGH candidate: movement, missions, economic activity, NPC spawn fixes |
| P1-F64 [aliyajadzia/evemu_Crucible](https://github.com/aliyajadzia/evemu_Crucible) | behind | `destiny-rework`, `staging` | 2 | Non-default branches present, but no ahead commits against current upstream |
| P1-F65 [kroryan/evemu_Crucible](https://github.com/kroryan/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F66 [innocentius/evemu_Crucible](https://github.com/innocentius/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F68 [beelitzs/evemu_Crucible](https://github.com/beelitzs/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F70 [tylerengland89/evemu_Crucible](https://github.com/tylerengland89/evemu_Crucible) | identical | `destiny-rework`, `staging` | 2 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F72 [wytsa/evemu_Crucible](https://github.com/wytsa/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F73 [Gargash/evemu_Crucible](https://github.com/Gargash/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F75 [almirosmanovic/evemu_Crucible](https://github.com/almirosmanovic/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F76 [JiwekLabs/evemu_Crucible](https://github.com/JiwekLabs/evemu_Crucible) | identical | `feature/stationmenus`, `inventory` | 2 | TARGETED candidate: utility/warp/inventory/mission changes |
| P1-F78 [dkstiler/evemu_Crucible](https://github.com/dkstiler/evemu_Crucible) | identical | `destiny-rework`, `destiny-staging`, `fix-108`, `staging` | 4 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F79 [ganymedex/evemu_Crucible](https://github.com/ganymedex/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F80 [sonicj/evemu_Crucible](https://github.com/sonicj/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F81 [masternerdguy/evemu_Crucible](https://github.com/masternerdguy/evemu_Crucible) | identical | `defect/20260607-incorrect-spawn-class`, `staging` | 2 | Limited or historical independent branch changes; low/medium priority |
| P1-F82 [KaldarAralay/evemu_Crucible](https://github.com/KaldarAralay/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F83 [SantjagoCorkez/evemu_Crucible](https://github.com/SantjagoCorkez/evemu_Crucible) | behind | `boost_174_build_fix`, `destiny-rework`, `giveallskills_fix`, `iHub_management_open`, `odb_models`, `staging`, `target_destroyed_modules_deactivate_segfault` | 7 | Limited or historical independent branch changes; low/medium priority |
| P1-F85 [AlbertPope/evemu_Crucible](https://github.com/AlbertPope/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F86 [nicti/evemu_Crucible](https://github.com/nicti/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F88 [ZyenDomani/evemu_Crucible](https://github.com/ZyenDomani/evemu_Crucible) | behind | `staging` | 1 | Non-default branches present, but no ahead commits against current upstream |
| P1-F89 [kroryon/evemu_Crucible](https://github.com/kroryon/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F90 [zhyrohaad/evemu_Crucible](https://github.com/zhyrohaad/evemu_Crucible) | behind | `allan-destiny`, `destiny-rework`, `staging` | 3 | Non-default branches present, but no ahead commits against current upstream |
| P1-F91 [katz1/evemu_Crucible](https://github.com/katz1/evemu_Crucible) | behind | `manufacturing-fix`, `staging` | 2 | Limited or historical independent branch changes; low/medium priority |
| P1-F92 [fumikejin/evemu_Crucible](https://github.com/fumikejin/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F93 [rhammond17/evemu_Crucible](https://github.com/rhammond17/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F94 [alive1986/evemu_Crucible](https://github.com/alive1986/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F95 [jdhirst/evemu_Crucible](https://github.com/jdhirst/evemu_Crucible) | identical | `missions_rework`, `posplot`, `staging` | 3 | TARGETED candidate: utility/warp/inventory/mission changes |
| P1-F96 [CyborgYL/evemu_Crucible](https://github.com/CyborgYL/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F98 [xchgeax/evemu_Crucible](https://github.com/xchgeax/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F99 [Trav41514/evemu_Crucible](https://github.com/Trav41514/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F100 [Stranho/evemu_Crucible](https://github.com/Stranho/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F101 [mcp77/evemu_Crucible](https://github.com/mcp77/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `staging` | 3 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F104 [TohkaPrincess/evemu_Crucible](https://github.com/TohkaPrincess/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F105 [Stars-22/evemu_Crucible](https://github.com/Stars-22/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F106 [robertbriggsgames/evemu_Crucible](https://github.com/robertbriggsgames/evemu_Crucible) | identical | `Staging`, `belt-rat-spawns-(high-value,-isolated-diff)`, `destiny-move-desync-275`, `modules-loader` | 4 | HIGH candidate: movement, missions, economic activity, NPC spawn fixes |
| P1-F107 [VizanArkonin/evemu_Crucible](https://github.com/VizanArkonin/evemu_Crucible) | behind | `contracts_implementation`, `destiny-rework`, `revert-1-staging`, `staging` | 4 | Limited or historical independent branch changes; low/medium priority |
| P1-F108 [FrostSoul/evemu_Crucible](https://github.com/FrostSoul/evemu_Crucible) | identical | `player-bot` | 1 | Non-default branches present, but no ahead commits against current upstream |
| P1-F109 [hrluo93/evemu_Crucible](https://github.com/hrluo93/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F110 [closet13/evemu_Crucible](https://github.com/closet13/evemu_Crucible) | behind | none | 0 | No non-default branches; no unique master commits |
| P1-F111 [FeenieRU/evemu_Crucible](https://github.com/FeenieRU/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F113 [melkordoran/evemu_Crucible](https://github.com/melkordoran/evemu_Crucible) | identical | `destiny-rework`, `staging` | 2 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F114 [ThisIsSietandre/evemu_Crucible](https://github.com/ThisIsSietandre/evemu_Crucible) | identical | none | 0 | No non-default branches; no unique master commits |
| P1-F115 [marsara9/evemu_Crucible](https://github.com/marsara9/evemu_Crucible) | behind | `destiny-rework`, `dungeon_editor`, `feature/minor-fixes`, `feature/outpost-manufacturing`, `feature/pos-manufacturing`, `staging` | 6 | Limited or historical independent branch changes; low/medium priority |
| P1-F117 [chuengeric2020/evemu_Crucible_ch](https://github.com/chuengeric2020/evemu_Crucible_ch) | behind | `beta_v0.1` | 1 | Limited or historical independent branch changes; low/medium priority |

## Evidence and limitations
Main/master comparison status previously obtained via GitHub compare. Unreviewed branches remain unverified; every adoption candidate needs source-path/commit evidence, legal/license examination, build/test and single-player gameplay verification.
