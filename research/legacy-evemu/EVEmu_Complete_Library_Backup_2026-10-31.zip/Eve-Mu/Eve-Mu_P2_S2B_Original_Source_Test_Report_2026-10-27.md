# Eve-Mu — S2-B source-extracted C++ test report

**Date:** 2026-10-27  
**Test category:** Compiled original method/function bodies against test doubles, **NOT** complete EVEmu server integration or historical EVE client testing.  
**Workspace:** `/mnt/data/eve_mu_s2b_actual_source/`  
**Status:** Reproducible source-level tests executed; whole-source server build and database integration remain **BLOCKED / NOT RUN**.

## Why this is stronger than S2-A — and what it is not

S2-A modeled source behavior in independent handwritten model methods. S2-B **compiled and ran EVEmu production functions** obtained from pinned public sources. EVEmu's large dependency graph was represented by *test-only stand-ins*. Pure math code in `market/sim/SimEconomy.cpp` is copied in full; other included production bodies were transcribed from the named source files without intentionally changing their logic. Minimal stubs **are not the production dependency implementations**. The Revised mining method was reconstructed from the observed source diff relative to F42; the original complete file was checked during source inspection, but no full checkout or Git blob content hash verification of the transcribed snippets was performed.

The following are **not** claimed: complete repository checkout, build of any actual EVEmu server executable, linked live server process, MariaDB/MySQL DBcore runtime, real server inventory logic, client connectivity or shipping production corrections. `DBTransaction` was executed against an SQLite-backed `DBcore` test double. A controlled invalid-pointer diagnostic in the extracted source is **not** a reproduced crash of the whole server. The author's PC or 10 GB historical client was not accessed.

Direct outbound GitHub DNS from the local container was unavailable; source was inspected through the GitHub connection and transferred as targeted text for the harness.

## Pinned source provenance

| Source | Revision | Method/file evidence |
|---|---|---|
| M0 upstream `EvEmu-Project/evemu_Crucible` | `f55b488a006e3090470d3b481aee47a1d7a0dade` | `src/eve-server/system/Asteroid.cpp` blob `bd4ba47ad9c2461ed03159ce6a858f3d18eb6b8a` |
| F42 `Mrinnovvation/evemu_Crucible`, `fixes/2026-10-15-combat-and-fitting` | `c88496f6f08a6488b57bbe9e3f5e3a61fd2da092` | `MiningLaser.cpp` blob `0591c86d557d371d770390c038c3b4ffd71d8f85`; `SimEconomy.cpp` blob `384e480f6017f54515cc194d312168b2522a3aed`; `Asteroid.cpp` blob `4b83b44b1694695787845dd5761424e58dd4b3ae`; `dbcore.h` blob `06a55f28918c02b4cf4c03e52e0a3056795d7305` |
| Revised `rennr/evemu_Revised`, `revised` | `2f1675b9d710bdb1158cbbd5cf46858a0e9e341a` | `MiningLaser.cpp` blob `4f7ddec5d595c32233d87b6f1cf6a754d3ba337c` |

## Toolchain and procedure

- Local C++ compiler: GCC 14.2.0, C++17; `-O1 -g -Wall -Wextra -fsanitize=undefined -fno-sanitize-recover=all -fno-omit-frame-pointer` for reproducible runner. Earlier separate economy and asteroid builds also ran with `-fsanitize=address,undefined`.
- `SQLite` is only used for the fake DBcore wrapper in the transaction tests. No claims about MariaDB's connection/failure behavior.
- Run `bash run_tests.sh` from this folder. Its exit status was **0** on the completed test run.
- **29/29 checks behaved as expected**: 11 economy, 9 asteroid, 4 transaction, 1 original-upstream regrowth, 4 mining scenarios. The count includes one *expected failing child execution* demonstrating a UBSan diagnostic; it is **not** 29 software passes.

## Reproduced observations

### 1. Actual F42 mining function: cargo-full / null pointer

- `mining_f42_source_extracted.cpp` compiles the actual `MiningLaser::ProcessCycle(bool)` body; stubs for its inventory, ship module deactivation, target, asteroid and stats are defined in `mining_stubs.hpp`.
- In **normal cargo** with 30 free volume, output was `oreRemaining=90 cargoDelivered=10 cargoRemaining=20`.
- In **partial cargo** with 4 free volume and a cycle of 10 units, the cargo-full stub synchronously deactivated the module and cleared `m_targetSE`, which was later referenced by the original F42 method. UBSan output:

  `mining_f42_source_extracted.cpp:59:48: runtime error: member call on null pointer of type 'struct SystemEntity'`

- The child process exited **1**, expected by the automated runner. No whole-server crash has been observed. This is a credible, executable source-level defect trace pending the exact production call-chain integration test.

### 2. Revised miner retained its target pointer

- `mining_revised_source_extracted.cpp` reconstructs `rennr`'s observed `ProcessCycle` function body with the saved `pTarget` local.
- Normal cargo output: `oreRemaining=90 cargoDelivered=10 cargoRemaining=20`.
- Partial cargo output: `oreRemaining=92 cargoDelivered=4 cargoRemaining=0`. The source-level harness did **not** null-dereference here, but it suggests a **possible mismatch** of 8 units removed vs 4 delivered under the stub's synchronous reentrant deactivation. Actual EVEmu inventory behavior might differ. Do not call the discrepancy a proven production bug without a full integration test.

### 3. Source-original simulated-economy math

Eleven tests passed using the unmodified `SimEconomy.cpp` function bodies: weighted anchors, high/low inventory clamps, OU step, ordered quotes, rounding, demand, wallet-budget limits, multiplication overflow and lot rounding. Numerical and guard tests only; **not** proof of whole-market financial integrity or realistic prices.

### 4. Source-original F42 asteroid behavior

Nine tests passed for `AsteroidSE::Grow`, `SetQuantity`, `RemoveQuantity`, `RadiusForQuantity`, `QuantityForRadius`: mathematical round trip, radius cap, gas handling, ore/mass/industrial-index changes, overmine clamp, growth, ice radius stability and a simulated Destiny radius update. Manager/database/client implementations were replaced by stand-ins. **No restart/persistence test.**

### 5. Source-original DBTransaction semantics

Four tests passed using the original class definition from `dbcore.h` with an SQLite-backed `DBcore` double: destructor auto-commits during exception unwinding, explicit rollback undoes work, explicit commit succeeds and persists. This **confirms the design of the RAII wrapper** but does not prove an actual EVEmu market settlement defect by itself. The F42 `MarketMgr::FillAgainstSellOrder` caller has an independently reviewed path that logs a failed spawn and continues. A production integration test must ensure item delivery errors roll back wallets/order/sim ledger.

### 6. Original upstream asteroid growth gap

The exact upstream `AsteroidSE::Grow()` method, using a timer stub, disabled the growth timer **without replenishing** the previously mined amount. Expected limitation observed in source-executed unit test; not an entire world-tick test. Revised/F42 has a functional growth method but requires server-lifecycle verification.

## High-priority follow-up gates (still open)

1. **S2-C-1: Actual linked EVEmu module + real inventory/target manager:** compile F42 and Revised modules with production dependencies; reproduce cargo-full, deactivation, and depleted-target paths with sanitizer instrumentation; compare quantity delivered vs removed. Goal is a real integration verdict, not a test-double inference.
2. **S2-C-2: Real MarketMgr + real DBcore and MariaDB/InnoDB:** inject `SpawnItem` failure after wallet transfer; assert call fails and all player/sim ledger/order/stock states remain consistent. Test the other market fill direction and connection failures as well.
3. **S2-C-3: Real BeltMgr + ManagerDB:** save/reload twice with multiple asteroid types (including non-unit type radius), depletion, growth timers and restart; assert original quantities and radii persist.
4. **S2-C-4: Build dependencies:** obtain a source checkout and database/migrations; produce a clean reproducible build on supported research platform before Windows x86-64 verification. Do not assume Windows tests from Linux results.

## Repository safety

No GitHub repos/branches/files changed; all local harness files are new, additive test artifacts only. The historical client remains local and untouched. Test code and logs are archived separately from previous S2-A behavioral models.
