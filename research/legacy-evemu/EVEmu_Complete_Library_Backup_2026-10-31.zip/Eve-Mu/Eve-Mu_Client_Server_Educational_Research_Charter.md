# Eve-Mu — Private Educational Client–Server Research Charter

**Decision date:** 2026-10-27  
**Status:** Scope confirmed; client research and integrated testing not yet begun.

## Purpose and scope
Eve-Mu is a **strictly educational, personal, non-distributed** investigation of how a space MMORPG is engineered. The reference is EVEmu's Crucible-era **server emulator**, including relevant forks, alongside the operation and interaction of the **historical game client**. The user wants to understand the full system, and experiment with a small, quiet, mining-oriented private world. A new independently created game is a **possible later alternative**, not an active replacement for the client or the research objective.

### What is in scope
- Server code, networking/protocol handlers, services, database and persistence, combat/NPC/economy simulation, mining and refining, station and map systems.
- Client–server handshake, version compatibility, RPC calls, events and world synchronization, client presentation responsibilities, existing UI/assets/static data dependencies, inspectable on-device behavior when material is available.
- Windows x86-64 local setup and reproducible tests of real gameplay on a user-controlled system; no cloud or public server requirement.
- Research notes, behavior maps, source references, reproducible test results and cross-fork evaluations saved to the private Eve-Mu Library.

### Boundaries
- **No distribution planned.** This is the user's private educational environment.
- The EVEmu server code is inspectable through the published repositories; **a corresponding client source repository has not been established**. Client analysis initially means documented version requirements, obtainable documentation, accessible data and observed behavior, not pretending proprietary source exists.
- Distinguish education and personal experimentation from permissions concerning proprietary code/content. Do not assume client redistribution, altered access controls or asset reuse.

## Reference client/server contract
- Upstream `EvEmu-Project/evemu_Crucible/src/eve-common/EVEVersion.h` declares **Crucible v1.6.5, build 360229**; protocol constant `MachoNetVersion = 320`.
- Upstream source has a client session / packet / service infrastructure and a default Docker Compose deployment showing TCP port **26000** (and **26001**); precise service allocation must be verified in source and a working test, not inferred from port numbers alone.
- A local server/client connection does not mean the client is available, functional or authorized by itself; each must be validated separately.

## Coordinated analysis tracks

| ID | Track | Concrete research output |
|---|---|---|
| C0 | Client provenance | Exact builds, source/binary/data availability, dependencies and permission constraints |
| C1 | Login/session protocol | Handshake timeline, packet families and handler mapping, errors and compatibility |
| C2 | Mining gameplay trace | Client requests ↔ server handlers ↔ DB updates ↔ returned effects |
| C3 | Presentation and map | Client-side UI, asset and static-ID dependencies; what server can or cannot control |
| C4 | Real-world validation | Windows-local client session evidence, logs, screenshots or diagnostics (if supplied/available), failures |
| C5 | General lessons | Architecture patterns for MMORPG state authority, simulation, replication and economy |
| S0 | Baseline | Build configuration, database requirements, core C++ layout and provenance |
| S1 | Fork comparison | Tested improvements from F42, F59, F118, F120 and focused branches |
| S2 | Mining/economy | Belts, ore, inventory, refining, NPC orders, trading and persistence |
| S3 | World/travel | Gates, warp, security zones, wormholes, NPCs and spawning |
| S4 | Integrated tests | End-to-end results with fixed versions and repeatable conditions |

## First integration test — one controlled local gameplay loop
1. Start the local database and EVEmu server; capture version/config and error logs.
2. Start a compatible, user-accessible historical client and verify loopback login and character selection.
3. Undock, warp to an asteroid belt and verify ship movement and entity synchronization.
4. Target an asteroid and cycle a mining module; verify ore subtraction, storage and client HUD updates.
5. Return to station, dock, refine ore, sell minerals to an actual seeded/simulated buyer.
6. Exit and restart; confirm persistent inventory and economy state.

Do not mark any item passed until tested; a source file or README claim is not a passing test.

## Optional small-world experiment
- High-security hub with station and NPC corporate services; direct path to a medium-security system; then null-sec.
- Wormhole system connected only from medium-sec, potentially a later test.
- Mining-first and leisurely. Keep this experimental map separate from assumptions about how the historic client displays static universe data.

## Review and checkpoint discipline
- Save client investigation as `C0`, `C1`, etc. with source/version details and verified-vs-hypothesized status.
- Continue per-repository P1/P2 notes independently, prioritizing user-relevant results rather than exhaustive diffs.
- Never silently turn the research into an independent commercial game project. Any original-game design should be a separately approved decision.

## Reference source
[EVEmu Crucible upstream](https://github.com/EvEmu-Project/evemu_Crucible) · [`EVEVersion.h`](https://github.com/EvEmu-Project/evemu_Crucible/blob/master/src/eve-common/EVEVersion.h)
