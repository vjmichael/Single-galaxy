# Eve-Mu — Results of the 80-fork hidden-development audit

**Date:** 2026-10-27  
**Scope:** all 80 EvEmu-Project forks whose default `master` branch was identical to or behind upstream; 148 non-default branch names.  
**Status:** GitHub commit/file screening completed for 148/148 branches; selected files and documentation inspected. **No repository was rebuilt or runtime-tested** in this phase.

## Executive findings

- **80/80** fork records examined; **148/148** non-default branches compared to `EvEmu-Project/evemu_Crucible:master`.
- **31** forks have no alternative branches and no independent `master` commits.
- **6** forks have alternative branches, but none has commits ahead of current upstream.
- **43** forks have at least one alternative branch ahead of upstream. These are *not 43 distinct gameplay improvements*: many branches copy shared older feature work.
- Repeated `destiny-rework` branches are uniformly behind current upstream with no unique commits; repeated `dungeon_editor` variants retain older divergence; many `staging` copies have no unique commits or share the same 13-file divergence.
- **F42 and F59** are the clearest leads for an already-populated world and a local, one-player mining economy.

## Ranked branches for the mining-focused single-player goal

| ID | Priority | Main branch leads | Evidence from review | Risks and next test |
|---|---|---|---|---|
| P1-F42 [Mrinnovvation/evemu_Crucible](https://github.com/Mrinnovvation/evemu_Crucible) | Very high | `fixes/2026-10-15-combat-and-fitting`, `fix/gettimeparts-now` | Simulation depth: author describes NPC miners/haulers, simulated economy, patrol traffic, reprocessing, modules, PvE and other systems. The branch CHANGELOG describes specific client-exercised bug fixes. | Branches contain 429 and 408 independent upstream-ahead commits; README admits features may be partial/buggy. README also points to rennr/evemu_Revised: trace ancestry and conflicts before porting. |
| P1-F59 [sargentscrufy/evemu_Crucible](https://github.com/sargentscrufy/evemu_Crucible) | Very high | `phase-1-commerce`, `phase-0-foundation` | A private-server project with source for market bot and smoke-test login harness, plus author progress record of simfleet/market seeding and mission validation. | Phase-1-commerce ahead 178; source-verified smoke_test.py is login handshake only, not proof of end-to-end mining or market test. |
| P1-F63 [celinor1982/evemu_Crucible](https://github.com/celinor1982/evemu_Crucible) | High | `staging_traderjoe_1_0`, `dbupgrade`, `staging_autopilot` | Staging trader/Trader Joe branch; economy automation can support a solo pilot buying and selling minerals. | Staging_traderjoe_1_0 ahead 313 but behind 5; historical diff may include common legacy work, do not merge whole branch. |
| P1-F50 [dgerabagi/evemu_Crucible](https://github.com/dgerabagi/evemu_Crucible) | High | `feature/autopilot-fix`, `feature/combat-missions` | Combat missions and autopilot branches contain 28/58 unique commits, changed agents, character and ship services. | Broader than a mining-first MVP; source/tests require build validation. |
| P1-F7 [ziggozoggo/evemu_crucible](https://github.com/ziggozoggo/evemu_crucible) | High | `stage`, `fix/repair-service-and-warp-desync`, `feature/physics` | Physics, warp and repair services address basic travel and ship control; branch files change DestinyManager and math. | feature/physics 8 ahead; fix/repair-service-and-warp-desync 12 ahead; later stage branch 28 ahead; untested. |
| P1-F106 [robertbriggsgames/evemu_Crucible](https://github.com/robertbriggsgames/evemu_Crucible) | High | `destiny-move-desync-275`, `belt-rat-spawns-(high-value,-isolated-diff)`, `Staging` | Belt rat spawn logic and movement desync branches touch SpawnMgr, SystemDB and DestinyManager, relevant to mining danger. | Four/five commits ahead, with an additional Staging branch. Actual spawn behaviors untested. |
| P1-F76 [JiwekLabs/evemu_Crucible](https://github.com/JiwekLabs/evemu_Crucible) | Medium | `feature/stationmenus`, `inventory` | Inventory and station menu changes may improve hangar usability and solo mission navigation. | Inventory branch one commit changes 34 files, feature/stationmenus 29 commits/72 files; need regression checks. |
| P1-F38 [kenneaal/evemu_Crucible](https://github.com/kenneaal/evemu_Crucible) | Medium | `market-solarSystemIndex` | Concrete tiny performance candidate: SQL migration creates an index on mktOrders(solarSystemID). | Current main comparison shows 1 divergent commit and 16 behind; SQL reviewed but query plan/market latency not measured. |
| P1-F1 [ozatomic/evemu_crucible_current](https://github.com/ozatomic/evemu_crucible_current) | Medium | `fix/warp-formula-and-packets`, `feature/tutorial-disable` | Tutorial skip and warp packet consistency may make an offline single-player experience easier. | Each branch only one commit; test with client. |
| P1-F8 [pet1100/evemu_crucible](https://github.com/pet1100/evemu_crucible) | Medium | `bugfix/undocking`, `dev` | Single-file undocking fix can help core loop. | One commit; compare to F7 and F59 changes before adoption. |
| P1-F95 [jdhirst/evemu_Crucible](https://github.com/jdhirst/evemu_Crucible) | Low/medium | `missions_rework`, `posplot` | JSON-oriented mission persistence/architecture useful later for quests. | Documents conflict: status says DB implementation builds while another doc admits JSON integration problems. Not MVP-ready. |

## Code/document evidence checked (not just file names)

1. **F59 source:** `tools/smoke-bot/smoke_test.py` actually performs a Crucible login handshake and verifies a valid user ID; it does **not** test mining, market settlement, gate travel or end-to-end missions. `.github/workflows/smoke-test.yml` runs a Docker login smoke job. `src/eve-server/market/MarketBotMgr.cpp` explicitly includes ore/mineral group IDs and automated buy/sell market code. Its `doc/PROGRESS.md` describes simulated pilot fleets, market buy walls, an industrial chain and gameplay tests, but those results were not independently reproduced here.
2. **F42 documentation:** `README.md` on `fixes/2026-10-15-combat-and-fitting` describes NPC miners, haulers, markets and a broader living universe. `CHANGELOG.md` describes precise boolean database decoding, module effect, targeting, scanning, docking and NPC/dungeon bug fixes, with some playtested claims. README explicitly warns that many features can be partial or buggy. It points to `rennr/evemu_Revised`; this is an **additional provenance/integration lead**, not part of the numbered 80.
3. **F38 source:** `sql/migrations/202406242143-mktOrderIndex` creates `CREATE INDEX solarSystem on mktOrders(solarSystemID)` with a matching down migration. This is a tangible index change, not evidence of measured latency improvement.
4. **F106 source:** `src/eve-server/system/cosmicMgrs/SpawnMgr.cpp` initializes belt spawn management and rat respawn timers, but source comments still admit work is needed on spawning and kill-count tracking; therefore the belt-rat feature is a candidate, not verified complete.
5. **F95 status docs:** one status document reports 23 mission DB methods and a successful build, while another describes unresolved `nlohmann/json` compilation and wiring steps; treat as incomplete until a clean build and mission flow test pass.
6. **F108 false-positive:** its `player-bot` branch is `identical` to current upstream (0 ahead / 0 behind / 0 changed files). It is **not** evidence of a separate bot feature.

## Repeated historical branch families

| Family | Observed result | Recommendation |
|---|---|---|
| `destiny-rework` (33 branches) | Every reviewed instance lies behind current upstream without ahead commits (mostly 176 commits behind, one 235). | Do not cherry-pick; already in upstream ancestry. |
| `dungeon_editor` (20 branches) | Three main older variants: 7 ahead / 104 behind, 11 ahead / 50 behind, 12 ahead / 104 behind; 19–31 changed files involving editor SQL/services. | Inspect unique ancestry only if custom missions, mining sites or wormhole dungeons are later needed. |
| `staging` (40 branches) | Mix of behind-only copies, small divergences, and a frequently repeated 2 ahead / 1 behind / 13-file historical patch. | Do not equate branch count with distinct implementations; compare specific commits before adoption. |

## Practical recommendation

**Evaluate F59 and F42 independently before choosing a base.** F59 appears to target a small private world directly, while F42 is broader and potentially much more capable but also more complex and potentially based on another revised repository. Neither has been independently built here. Avoid a wholesale combination of their branches. First reproduce a legal, compatible client/server login and then a complete player loop: create character → undock → warp to belt → fire mining laser → ore cargo → return/dock → reprocess → sell → save/reload. Follow with a background NPC buyer and resource replenishment; only then add systems, NPC miners and wormholes.

**World size:** model the requested “galaxies” initially as four star systems/clusters (high-sec trading hub, medium-sec mining hub, null-sec frontier, optional wormhole connected only to medium-sec). Preserve the existing IDs/dependencies behind a restricted playable map instead of deleting most of the EVE universe database on day one.

## Source and legal/test boundaries

- All branch classifications are GitHub ahead/behind and changed-file evidence, not compiled or benchmarked outcomes. A comparison listing 300 files may be truncated. Some branches retain independent commits but net zero changed files.
- Private/local use does not itself authorize proprietary client binaries, game assets or third-party code outside their licenses. Verify licenses and compatible client sources before implementing the playable client.
- An emulator is server-side infrastructure, not a self-contained local game executable. Offline economy and resource respawning may need dedicated synthetic processes.

## Full 80-fork analysis register

Status key: `ahead branches` counts branch refs (not unique features). `Historical` means non-current or duplicated shared changes; this should guide source review, not imply the branch is useless.

| Fork | `master` | Other branches | Branch refs ahead | Assessment |
|---|---|---:|---:|---|
| P1-F1 [ozatomic/evemu_crucible_current](https://github.com/ozatomic/evemu_crucible_current) | identical | 2 | 2 | TARGETED candidate: utility/warp/inventory/mission changes |
| P1-F3 [ion9/evemu_Crucible](https://github.com/ion9/evemu_Crucible) | behind | 2 | 1 | Limited or historical independent branch changes; low/medium priority |
| P1-F4 [triple111/evemu_Crucible](https://github.com/triple111/evemu_Crucible) | behind | 2 | 2 | Limited or historical independent branch changes; low/medium priority |
| P1-F7 [ziggozoggo/evemu_crucible](https://github.com/ziggozoggo/evemu_crucible) | identical | 3 | 3 | HIGH candidate: movement, missions, economic activity, NPC spawn fixes |
| P1-F8 [pet1100/evemu_crucible](https://github.com/pet1100/evemu_crucible) | identical | 2 | 2 | TARGETED candidate: utility/warp/inventory/mission changes |
| P1-F9 [chengood5000/evemu_Crucible](https://github.com/chengood5000/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F10 [chuengjoanna/evemu_Crucible](https://github.com/chuengjoanna/evemu_Crucible) | behind | 1 | 1 | Limited or historical independent branch changes; low/medium priority |
| P1-F14 [bnaambo/evemu_Crucible](https://github.com/bnaambo/evemu_Crucible) | behind | 3 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F18 [ImTorbin/evemu_Crucible3.0](https://github.com/ImTorbin/evemu_Crucible3.0) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F19 [cingulari/evemu_Crucible](https://github.com/cingulari/evemu_Crucible) | behind | 3 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F20 [seren1tyy/evemu_Crucible](https://github.com/seren1tyy/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F21 [locvez/evemu_Crucible](https://github.com/locvez/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F22 [strikersix23/evemu_Crucible](https://github.com/strikersix23/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F23 [d10sfan/evemu_Crucible](https://github.com/d10sfan/evemu_Crucible) | behind | 6 | 4 | Limited or historical independent branch changes; low/medium priority |
| P1-F24 [charles-m-knox/evemu_Crucible](https://github.com/charles-m-knox/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F25 [Avi-E-Koenig/evemu_Crucible](https://github.com/Avi-E-Koenig/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F27 [dd667/evemu_Crucible](https://github.com/dd667/evemu_Crucible) | behind | 2 | 0 | Non-default branches present, but no ahead commits against current upstream |
| P1-F30 [SilverXarrow/evemu_Crucible](https://github.com/SilverXarrow/evemu_Crucible) | behind | 3 | 2 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F31 [devedse/evemu_Crucible](https://github.com/devedse/evemu_Crucible) | identical | 2 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F36 [swaric/evemu_Crucible](https://github.com/swaric/evemu_Crucible) | identical | 3 | 2 | Limited or historical independent branch changes; low/medium priority |
| P1-F38 [kenneaal/evemu_Crucible](https://github.com/kenneaal/evemu_Crucible) | behind | 4 | 3 | TARGETED candidate: utility/warp/inventory/mission changes |
| P1-F39 [dawa11/evemu_Crucible](https://github.com/dawa11/evemu_Crucible) | identical | 2 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F41 [PHX-TeamPhoenix/evemu_Crucible](https://github.com/PHX-TeamPhoenix/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F42 [Mrinnovvation/evemu_Crucible](https://github.com/Mrinnovvation/evemu_Crucible) | identical | 4 | 3 | TOP candidate: extensive simulation, NPC economy/miners; author-tested claims |
| P1-F44 [rrfarmer/evemu_Crucible](https://github.com/rrfarmer/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F47 [I-89762345-I/evemu_Crucible](https://github.com/I-89762345-I/evemu_Crucible) | behind | 3 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F48 [sephcasiah/evemu_Crucible](https://github.com/sephcasiah/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F49 [d4rkf0x/evemu_Crucible](https://github.com/d4rkf0x/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F50 [dgerabagi/evemu_Crucible](https://github.com/dgerabagi/evemu_Crucible) | identical | 2 | 2 | HIGH candidate: movement, missions, economic activity, NPC spawn fixes |
| P1-F51 [xrizonx/evemu_Crucible](https://github.com/xrizonx/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F52 [gebainixyz/evemu_Crucible](https://github.com/gebainixyz/evemu_Crucible) | behind | 3 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F55 [Mezzarius/evemu_Crucible](https://github.com/Mezzarius/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F56 [hxhieu/evemu_Crucible](https://github.com/hxhieu/evemu_Crucible) | identical | 6 | 3 | Limited or historical independent branch changes; low/medium priority |
| P1-F57 [SpirytusMoe/evemu_Crucible](https://github.com/SpirytusMoe/evemu_Crucible) | behind | 3 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F59 [sargentscrufy/evemu_Crucible](https://github.com/sargentscrufy/evemu_Crucible) | identical | 4 | 3 | TOP candidate: private single-player-friendly economy + bots; author-tested claims |
| P1-F61 [favoms/evemu_Crucible](https://github.com/favoms/evemu_Crucible) | behind | 2 | 0 | Non-default branches present, but no ahead commits against current upstream |
| P1-F62 [salartarium/evemu_Crucible](https://github.com/salartarium/evemu_Crucible) | behind | 4 | 2 | Limited or historical independent branch changes; low/medium priority |
| P1-F63 [celinor1982/evemu_Crucible](https://github.com/celinor1982/evemu_Crucible) | behind | 7 | 4 | HIGH candidate: movement, missions, economic activity, NPC spawn fixes |
| P1-F64 [aliyajadzia/evemu_Crucible](https://github.com/aliyajadzia/evemu_Crucible) | behind | 2 | 0 | Non-default branches present, but no ahead commits against current upstream |
| P1-F65 [kroryan/evemu_Crucible](https://github.com/kroryan/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F66 [innocentius/evemu_Crucible](https://github.com/innocentius/evemu_Crucible) | behind | 3 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F68 [beelitzs/evemu_Crucible](https://github.com/beelitzs/evemu_Crucible) | behind | 3 | 2 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F70 [tylerengland89/evemu_Crucible](https://github.com/tylerengland89/evemu_Crucible) | identical | 2 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F72 [wytsa/evemu_Crucible](https://github.com/wytsa/evemu_Crucible) | behind | 3 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F73 [Gargash/evemu_Crucible](https://github.com/Gargash/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F75 [almirosmanovic/evemu_Crucible](https://github.com/almirosmanovic/evemu_Crucible) | behind | 3 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F76 [JiwekLabs/evemu_Crucible](https://github.com/JiwekLabs/evemu_Crucible) | identical | 2 | 2 | TARGETED candidate: utility/warp/inventory/mission changes |
| P1-F78 [dkstiler/evemu_Crucible](https://github.com/dkstiler/evemu_Crucible) | identical | 4 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F79 [ganymedex/evemu_Crucible](https://github.com/ganymedex/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F80 [sonicj/evemu_Crucible](https://github.com/sonicj/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F81 [masternerdguy/evemu_Crucible](https://github.com/masternerdguy/evemu_Crucible) | identical | 2 | 2 | Limited or historical independent branch changes; low/medium priority |
| P1-F82 [KaldarAralay/evemu_Crucible](https://github.com/KaldarAralay/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F83 [SantjagoCorkez/evemu_Crucible](https://github.com/SantjagoCorkez/evemu_Crucible) | behind | 7 | 5 | Limited or historical independent branch changes; low/medium priority |
| P1-F85 [AlbertPope/evemu_Crucible](https://github.com/AlbertPope/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F86 [nicti/evemu_Crucible](https://github.com/nicti/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F88 [ZyenDomani/evemu_Crucible](https://github.com/ZyenDomani/evemu_Crucible) | behind | 1 | 0 | Non-default branches present, but no ahead commits against current upstream |
| P1-F89 [kroryon/evemu_Crucible](https://github.com/kroryon/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F90 [zhyrohaad/evemu_Crucible](https://github.com/zhyrohaad/evemu_Crucible) | behind | 3 | 0 | Non-default branches present, but no ahead commits against current upstream |
| P1-F91 [katz1/evemu_Crucible](https://github.com/katz1/evemu_Crucible) | behind | 2 | 1 | Limited or historical independent branch changes; low/medium priority |
| P1-F92 [fumikejin/evemu_Crucible](https://github.com/fumikejin/evemu_Crucible) | behind | 3 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F93 [rhammond17/evemu_Crucible](https://github.com/rhammond17/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F94 [alive1986/evemu_Crucible](https://github.com/alive1986/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F95 [jdhirst/evemu_Crucible](https://github.com/jdhirst/evemu_Crucible) | identical | 3 | 3 | TARGETED candidate: utility/warp/inventory/mission changes |
| P1-F96 [CyborgYL/evemu_Crucible](https://github.com/CyborgYL/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F98 [xchgeax/evemu_Crucible](https://github.com/xchgeax/evemu_Crucible) | behind | 3 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F99 [Trav41514/evemu_Crucible](https://github.com/Trav41514/evemu_Crucible) | behind | 3 | 2 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F100 [Stranho/evemu_Crucible](https://github.com/Stranho/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F101 [mcp77/evemu_Crucible](https://github.com/mcp77/evemu_Crucible) | behind | 3 | 2 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F104 [TohkaPrincess/evemu_Crucible](https://github.com/TohkaPrincess/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F105 [Stars-22/evemu_Crucible](https://github.com/Stars-22/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F106 [robertbriggsgames/evemu_Crucible](https://github.com/robertbriggsgames/evemu_Crucible) | identical | 4 | 4 | HIGH candidate: movement, missions, economic activity, NPC spawn fixes |
| P1-F107 [VizanArkonin/evemu_Crucible](https://github.com/VizanArkonin/evemu_Crucible) | behind | 4 | 2 | Limited or historical independent branch changes; low/medium priority |
| P1-F108 [FrostSoul/evemu_Crucible](https://github.com/FrostSoul/evemu_Crucible) | identical | 1 | 0 | Non-default branches present, but no ahead commits against current upstream |
| P1-F109 [hrluo93/evemu_Crucible](https://github.com/hrluo93/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F110 [closet13/evemu_Crucible](https://github.com/closet13/evemu_Crucible) | behind | 0 | 0 | No non-default branches; no unique master commits |
| P1-F111 [FeenieRU/evemu_Crucible](https://github.com/FeenieRU/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F113 [melkordoran/evemu_Crucible](https://github.com/melkordoran/evemu_Crucible) | identical | 2 | 1 | Historical shared branches only; check provenance and age, do not cherry-pick blindly |
| P1-F114 [ThisIsSietandre/evemu_Crucible](https://github.com/ThisIsSietandre/evemu_Crucible) | identical | 0 | 0 | No non-default branches; no unique master commits |
| P1-F115 [marsara9/evemu_Crucible](https://github.com/marsara9/evemu_Crucible) | behind | 6 | 4 | Limited or historical independent branch changes; low/medium priority |
| P1-F117 [chuengeric2020/evemu_Crucible_ch](https://github.com/chuengeric2020/evemu_Crucible_ch) | behind | 1 | 1 | Limited or historical independent branch changes; low/medium priority |

## Machine-readable backing data

The companion `Eve-Mu_P2_80Fork_Branch_Audit.json` records every branch name, ahead/behind status, comparison file count, and per-branch evidence/limitations; IDs remain stable at P1-F1…P1-F120. Always review and preserve pinned commits before borrowing fixes.
