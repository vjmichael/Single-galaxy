-- ============================================================================
-- evemu_test seed data (corrected) — EVEmu Crucible market audit
-- Date: 2026-10-28
-- Supersedes the seed block in audit/04_test_plan.md ("Test Database Setup"),
-- which was NON-CONFORMING:
--   * used non-existent column `name`        -> correct column: `characterName`
--   * characterID 990001 outside [90000000, 97999999] (EVE_Defines.h:139-140,
--     IsCharacterID() false, IsValidOwner() false)
--   * corporationID 2000001 inside the NPC-corp range [1000000, 1100000]
--     (IsPlayerCorp() false -> HandleCorpTransaction() would never run)
-- Verified 2026-10-28 against MariaDB 13.0.2 in a scratch database
-- (created + dropped; no residue). See audit/06_followup_evidence_report_v2.md
-- section 6.5.
--
-- Preconditions: the evemu_test database exists and has received the base
-- schema (sql/base/*.sql.gz) + sql/migrations/*.sql (see sql/README.md).
-- This file adds ONLY the test fixtures below — it does not create tables.
-- ============================================================================

USE evemu_test;

-- ----------------------------------------------------------------------------
-- Characters (player ID range: 90000000 - 97999999)
-- chrCharacters: characterID int unsigned AI, characterName varchar(30) NOT NULL,
--                balance double NOT NULL, corporationID int unsigned
-- ----------------------------------------------------------------------------
INSERT INTO chrCharacters (characterID, characterName, balance, corporationID)
  VALUES (90000001, 'TestChar1', 100000.0, 98000001);

INSERT INTO chrCharacters (characterID, characterName, balance, corporationID)
  VALUES (90000002, 'TestChar2', 100000.0, 98000001);

-- ----------------------------------------------------------------------------
-- Player corporation wallet (player corp ID range: 98000000 - 98999999)
-- crpWalletDivisons (sic): corporationID PK, balance1..balance7 float NOT NULL
-- (MyISAM engine in base schema — see report Q4)
-- ----------------------------------------------------------------------------
INSERT INTO crpWalletDivisons (corporationID, balance1)
  VALUES (98000001, 50000.0);

-- ----------------------------------------------------------------------------
-- Station / region / type references must come from the LOADED base data:
--   * station 60014137 (region 10000001, system 30000053) — a row used by
--     sql/seed_and_clean/seed_station_market.sql (verify presence after base
--     load: SELECT * FROM staStations WHERE stationID=60014137)
--   * typeID 34 (Tritanium) — present in invTypes after base load
-- Do NOT hard-code station/region rows here; they belong to base data.
-- ----------------------------------------------------------------------------

-- ----------------------------------------------------------------------------
-- Market order fixtures (optional; column list matches MarketDB::StoreOrder,
-- src/eve-server/market/MarketDB.cpp). Example standing buy order for test
-- variants A/B/C in report section 6.3 (volRemaining=100, price=5.00):
--
-- INSERT INTO mktOrders
--   (typeID, ownerID, regionID, stationID, solarSystemID, orderRange,
--    bid, price, escrow, minVolume, volEntered, volRemaining,
--    issued, contraband, duration, jumps, isCorp, accountKey, memberID)
-- VALUES
--   (34, 90000002, 10000001, 60014137, 30000053, 0,
--    1, 5.00, 500.00, 0, 100, 100,
--    133428496500000000, 0, 0, 0, 0, 1000, 0);
--
-- (issued = FILETIME-style ms timestamp; escrow = price*volRemaining)
-- ----------------------------------------------------------------------------

-- Verification queries (read-only):
SELECT characterID, characterName, balance, corporationID FROM chrCharacters
 WHERE characterID IN (90000001, 90000002);
SELECT corporationID, balance1 FROM crpWalletDivisons WHERE corporationID = 98000001;
