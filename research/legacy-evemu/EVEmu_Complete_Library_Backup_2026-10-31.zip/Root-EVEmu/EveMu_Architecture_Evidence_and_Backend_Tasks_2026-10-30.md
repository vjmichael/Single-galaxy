# Eve-Mu Architecture Evidence & Original Backend Task Plan
**Date:** 2026-10-30  
**Status:** Planned / not executed  
**Separation:** Eve-Mu educational investigation and original-game backend are independent workstreams.

## Scope decision: one fictional galaxy, not EVE Online
- The proposed original game is set within **one fictional galaxy**. It is **not** a reproduction of EVE Online's universe, map, factions, stations, market database, client, or game content.
- A galaxy is the world container, **not** a commitment to individually simulate billions of stars. Star systems/sectors are authored or generated under explicit resource budgets; distant regions can be represented coarsely.
- The first engineering prototype should contain **one playable star system within that galaxy**. Expand the playable footprint only after movement, persistence, inventory, and economy are proven. Final star-system count is undecided.
- Eve-Mu remains a separate private educational investigation of the existing Crucible-era server/client; its findings inform general engineering patterns, not wholesale code/asset copying.

## Evidence provenance / what is known
- Current educational research traced server-side implementations for mining, asteroid depletion, belt management, reprocessing, market services, and candidate NPC market simulation, but integrated real-client gameplay remains unverified.
- Qwen's P4 handoff reports a functioning `evemu_test` database, six passing CTest tests and 42 checks of production DBcore and production-equivalent SQL. **This did not execute production `MarketMgr::ExecuteBuyOrder`/`ExecuteSellOrder`, and it did not verify client/server gameplay.**
- P4 source review reports outstanding transaction-record propagation, early-return cleanup, and live-memory/DB divergence risks; treat them as open until repaired and directly tested.
- Evidence should be tagged: `SOURCE_INSPECTED`, `ISOLATED_TEST`, `PRODUCTION_DB_PATH_TEST`, `FULL_SERVER_RUNTIME`, `REAL_CLIENT_LOOPBACK`, `PERFORMANCE_RUN`, or `NOT_VERIFIED`; never promote an earlier classification without evidence.

## Workstream A — Finish the EVEmu architecture investigation
**Owner split:** Qwen = read-only client-directory reconnaissance (separate handoff); subsequent EVEmu runtime instrumentation and validation = future authorized work, with owner assigned then.

| Task | Evidence needed | Acceptance gate | Current status |
|---|---|---|---|
| A0 Client directory reconnaissance | Actual local file classes, version/build candidates, rendering/UI/resource evidence, protocol hints and client/server responsibility map | Reports cite exact relative paths/metadata, clearly separate observed from inferred | Not started |
| A1 Spatial simulation | Trace server movement/tick/warp/collision/zone code and client handling; establish which side owns authoritative transforms | Source-path crosswalk plus one reproducible movement/warp runtime trace when approved | Not verified |
| A2 Networking & synchronization | Trace handshake, session creation, service RPC, object enter/leave, updates, acknowledgments, reconnect and error handling | Message/handler matrix; version match; clean local trace with timestamps when approved | Not verified |
| A3 NPC AI & background simulation | Trace NPC spawning, state machines, target selection, persistence, market actors, activity when no human is connected | Source map plus reproducible headless NPC activity test, deterministic seed where possible | Not verified |
| A4 Market realism & correctness | Exercise buy/sell, partial fills, taxes, wallet/inventory/order conservation; inject faults; reproduce concurrent/duplicate cases | Actual orchestration tests, ledger invariants and rollback/reconciliation evidence; do not confuse P4 with full coverage | Partially covered at DB layer only |
| A5 Integrated gameplay | Login → ship/spawn → undock → movement/warp → mine → inventory → dock → refine/sell → shutdown/restart | Every step logged with actual client/server/test-DB evidence; no artificial fixture called normal gameplay | Not verified |
| A6 Runtime workload profiling | Tick cost, RPC throughput, NPC processing, entity count, market load, persistence latency, CPU/RAM usage | Repeatable config + workload + raw results + failure counters; report p50/p95/p99 where meaningful | Not started |

### Conditions for A-series runtime work
1. Obtain explicit authorization before executing the historical client, instrumenting it, capturing packets, modifying any configuration, or running synthetic loads. Qwen's initial task is **static, read-only review** of the approximately 10 GB client directory.
2. Use only an isolated local server and disposable `evemu_test` database; do not touch production databases or connect to external services.
3. Keep public-server credentials, passwords, account tokens, personal logs, and proprietary assets out of reports and repositories. Do not copy, upload or redistribute the full client directory.
4. Pin build/config/source revisions. Verify actual client version instead of assuming compatibility with upstream-declared Crucible v1.6.5 build 360229 / MachoNet 320.
5. Do not assume code comments, scripts, simulated client tests, or SQL-only tests establish full gameplay success.

## Workstream B — Original single-galaxy backend: design and prototype gates
**Status:** Proposed, no source code created or benchmark run under this task plan.

| Gate | Implementation deliverable | Verification / exit criterion |
|---|---|---|
| B0 Boundary & architecture contract | Original game design scope; authoritative command/event protocol; simulation tick; entity identifiers; versioned save format; separate modules for movement, resources, inventory, economy, NPCs | Written invariants and test interfaces approved; no dependency on historical EVE client, database, IDs or art |
| B1 Headless single-system kernel | Windows x86-64 native process/library, fixed-step world loop, spawn/move/advance entities, command validation, deterministic seeds | Automated replay tests produce identical results for identical seeds/commands |
| B2 Persistence & conservation | SQLite database or equivalent embedded persistence, transactional inventory/wallet/resource operations, recovery journal, controlled shutdown/restart | No currency/ore duplication or loss on successful or failed commands; crash/fault-injection tests |
| B3 Minimal economy & NPCs | Ore/repair/salvage resources, finite NPC stores/wallets, simple production and trade, dormant-sector progression policy | Bounded workloads; NPC transactions properly backed; finite resources conserved per game rules |
| B4 Play-loop harness | Headless journey: depart station → travel → extract/salvage → cargo → return → sell/refine → persist/restart | No manual database staging masquerading as player activity |
| B5 Benchmarks & profiling | Repeatable scenarios for entity simulation, movements, AI, transactional settlement, snapshot/recovery | Repeated measurements with hardware/build/seed/config recorded; correctness still passes under load |
| B6 Optional client/network adapter | Original rendering/client interface and optional localhost/network transport for future friends | Same validated command semantics for local and remote adapters; not a prerequisite for B1–B5 |

### Initial performance measurement design (targets to be calibrated, not asserted)
- Record Windows build/version, CPU/GPU, RAM, executable revision, seed, engine configuration, simulation tick interval, feature flags and test DB state.
- Profile escalating workloads such as 1/10/100 simulated active entities, 1/10/100 NPC economic actors, and 1/10/100 synthetic order submissions per interval; adjust for actual hardware and avoid claiming these are already supported.
- Metrics: update/tick duration (p50, p95, p99, worst), command latency, number of authoritative state mismatches, transaction failures, wallet/resource conservation residual, CPU utilization, memory peak, disk I/O, save/load and crash recovery durations, and network latency/bandwidth only when networking exists.
- Distinguish idle, active mining/salvage, NPC production/trading, and mixed stress cases. Include warmup, repeat counts, failure logs and reproducible commands.
- Do not present EVEmu versus original-backend benchmark results as a fair performance comparison unless the workloads and semantics are deliberately matched; otherwise report each backend independently.

## Sequencing and responsibility
1. **Now:** Qwen halts P5 and does A0, a read-only 10 GB local client-directory review (see Qwen handoff). Preserve any existing EVEmu work; no destructive resets.
2. **Next research proposal:** Use Qwen's A0 output to narrow A1/A2 client/server trace points, then request separate permission for runtime tests (A1–A6).
3. **Original project:** B0 design can be drafted in parallel; B1–B5 require explicit kickoff and implementation assignment, and should not change the EVEmu repository.
4. **Later:** Report verified gaps and compare design implications; no unapproved P5 work, GitHub pushes, or client modifications.

## Required reporting structure
For each gate: hypothesis; scope; source versions and exact file/path references; commands/configuration (with secrets redacted); observed data; expected behavior; classification; PASS/FAIL/NOT RUN; limitation; next action. A checklist item isn't PASS without reproducible evidence.
