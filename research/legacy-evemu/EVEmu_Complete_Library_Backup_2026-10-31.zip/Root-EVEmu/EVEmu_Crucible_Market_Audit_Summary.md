# EVEmu Crucible — Market Integrity Audit (Complete Findings)

> **Purpose**: Self-contained audit document for sharing with external AI assistants (e.g., ChatGPT) or development teams. Contains all source references, findings, and recommendations. No access to the codebase is required to read this document.

---

## 1. Repository Identification

| Field | Value |
|---|---|
| **Repository** | `https://github.com/EvEmu-Project/evemu_Crucible.git` |
| **Branch** | `master` |
| **Commit SHA** | `7d5e20611d53ca4ded6875e7bd390f36878d4654` |
| **Commit subject** | `Version 0.8.5 release` |
| **Parent commit** | `c215cf91` — `Fix Activate call on DogmaIMService (#254)` |
| **Version** | 0.8.5 (ChangeLog.md); `EVEVersion.h` has cosmetic bug: hardcodes `"0.8.4-"` prefix |
| **Client target** | EVE Online Crucible v1.6.5, build 360229, MachoNet 320 |
| **Language** | C++17 (`-std=gnu++17`) |
| **Build system** | CMake ≥ 2.8.8 |
| **Database** | MySQL/MariaDB (libmysqlclient C API), Docker: `bitnami/mariadb:10.4` |
| **Dependencies** | Boost, TinyXML, UTF8-CPP, ZLIB |
| **Test framework** | Custom (no gtest), CTest integration. Only 3 tests exist (auth, marshal, EvilNumber). |
| **Audit method** | Static code analysis (build tools unavailable in audit environment) |
| **Audit date** | 2026-07-09 |

---

## 2. Architecture Overview

### 2.1 Source Directory Structure

```
evemu_Crucible/
├── CMakeLists.txt
├── docker-compose.yml          # server + MariaDB
├── sql/
│   ├── base/                   # 50+ .sql.gz table dumps (gzipped)
│   └── migrations/             # 18 timestamped .sql migration files
├── src/
│   ├── eve-core/               # DB (dbcore), network, memory, marshal, log
│   │   └── database/dbcore.{h,cpp}   # MySQL singleton (sDatabase), mutex-locked per-query
│   ├── eve-common/             # Python-like objects, packets, auth, cache
│   │   └── EVE_Market.h        # Market data structures (TxData, SaveData, OrderInfo)
│   ├── eve-server/             # All game logic
│   │   ├── market/
│   │   │   ├── MarketProxyService.{h,cpp}  # Client-facing API (PlaceCharOrder, etc.)
│   │   │   ├── MarketMgr.{h,cpp}           # ExecuteBuyOrder, ExecuteSellOrder
│   │   │   ├── MarketDB.{h,cpp}            # All market SQL (StoreOrder, FindBuyOrder, etc.)
│   │   │   ├── MarketBot*.{h,cpp}          # NPC trader bots
│   │   │   └── NPCMarket.{h,cpp}
│   │   ├── account/
│   │   │   ├── AccountService.{h,cpp}      # TranserFunds (the money mover)
│   │   │   └── AccountDB.{h,cpp}           # OfflineFundXfer, GetCorpBalance, AddJournalEntry
│   │   ├── inventory/
│   │   │   ├── InventoryItem.{h,cpp}       # Donate(), Split(), Delete(), AlterQuantity()
│   │   │   ├── ItemFactory.{h,cpp}         # SpawnItem()
│   │   │   └── ...
│   │   └── ...
│   └── eve-test/               # 3 unit tests (no market/account tests)
```

### 2.2 Key Global Singletons

| Symbol | Type | File | Role |
|---|---|---|---|
| `sDatabase` | `DBcore::get()` | `dbcore.h` | Single MySQL connection, `Mutex MDatabase` per query |
| `sMktMgr` | `MarketMgr::get()` | `MarketMgr.h` | Market manager singleton |
| `sDataMgr` | `StaticDataMgr` | — | Static game data (types, stations, regions) |
| `sItemFactory` | `ItemFactory` | — | Item creation/loading |
| `sEntityList` | `EntityList` | — | Online client lookup |
| `stDataMgr` | `StationDataMgr` | — | Station data |
| `sConfig` | `EVEServerConfig` | — | Server configuration |

---

## 3. Market Transaction Lifecycle (Complete Call Graph)

```
Client (Crucible v1.6.5)
  │
  ▼
MarketProxyService::PlaceCharOrder()          [MarketProxyService.cpp]
  │
  ├── BUY ORDER (bid=1)
  │   │
  │   ├── IMMEDIATE (duration=0)
  │   │   ├── MarketDB::FindSellOrder()       [MarketDB.cpp]
  │   │   │   SQL: SELECT orderID FROM mktOrders
  │   │   │       WHERE bid=0 AND typeID=X AND stationID=Y
  │   │   │       AND volRemaining >= Q AND price <= P
  │   │   │       ORDER BY price ASC LIMIT 1
  │   │   │   ⚠ NO FOR UPDATE lock
  │   │   │
  │   │   └── MarketMgr::ExecuteSellOrder()   [MarketMgr.cpp]
  │   │       ├── 1. AccountService::TranserFunds(buyer→seller, money)
  │   │       │      ⚠ Throws UserError if insufficient funds
  │   │       ├── 2. AccountService::TranserFunds(seller→CCP, tax)
  │   │       ├── 3. sItemFactory.SpawnItem() → iRef->Donate(buyer)
  │   │       │      ⚠ If SpawnItem returns null → early return (funds already moved!)
  │   │       ├── 4. MarketDB::DeleteOrder() or AlterOrderQuantity()
  │   │       └── 5. MarketDB::RecordTransaction() × 2 (buy + sell sides)
  │   │          ⚠ Failure only logged, not propagated
  │   │
  │   └── STANDING (duration>0)
  │       ├── MarketDB::StoreOrder()          → INSERT mktOrders
  │       ├── AccountService::TranserFunds(buyer→station, broker_fee)
  │       └── AccountService::TranserFunds(buyer→station_escrow, escrow)
  │          ⚠ StoreOrder called BEFORE TranserFunds
  │
  └── SELL ORDER (bid=0)
      │
      ├── IMMEDIATE (duration=0)
      │   └── while (quantity > 0):
      │       ├── MarketDB::FindBuyOrder()    [MarketDB.cpp]
      │       │   SQL: SELECT orderID FROM mktOrders
      │       │       WHERE bid=1 AND typeID=X AND stationID=Y
      │       │       AND volRemaining >= Q AND price >= P
      │       │       ORDER BY price DESC LIMIT 1
      │       │   ⚠ NO FOR UPDATE lock
      │       │
      │       └── MarketMgr::ExecuteBuyOrder() [MarketMgr.cpp]
      │           ├── 1. iRef->Donate() / Split() / Delete()  (item transfer)
      │           │   ⚠ NULL deref bug if Split() returns null (see §5.1)
      │           ├── 2. AccountService::TranserFunds(seller→CCP, tax)
      │           ├── 3. AccountService::TranserFunds(escrow→seller, money)
      │           ├── 4. MarketDB::RecordTransaction() × 2
      │           │   ⚠ Failure only logged, not propagated
      │           └── 5. MarketDB::DeleteOrder() or AlterOrderQuantity()
      │
      └── STANDING (duration>0)
          ├── AccountService::TranserFunds(seller→station, broker_fee)
          ├── MarketDB::StoreOrder()          → INSERT mktOrders
          ├── iRef->Delete() or AlterQuantity(-qty)
          └── sMktMgr.InvalidateOrdersCache() + SendOnOwnOrderChanged()
             ⚠ If Delete() fails after StoreOrder() → item duplication
```

### 3.1 AccountService::TranserFunds — The Money Mover

**File**: `src/eve-server/account/AccountService.cpp`, function `TranserFunds()`

Three paths depending on entity type:

**Online character (sender)**:
```
pClientFrom->AddBalance(-amount, currency)   // in-memory
AccountDB::AddJournalEntry(fromID, ...)      // DB INSERT
```

**Offline character (sender)**:
```
AccountDB::OfflineFundXfer(fromID, -amount, currency)
  → SELECT balance FROM chrCharacters WHERE characterID = X
  → balance += amount                          // in-memory
  → UPDATE chrCharacters SET balance = new WHERE characterID = X
AccountDB::AddJournalEntry(fromID, ...)      // DB INSERT
```

**Corporation (sender or recipient)**:
```
HandleCorpTransaction(corpID, ...)
  → AccountDB::GetCorpBalance(corpID, key)    // SELECT
  → if withdrawing: check balance sufficient   // throws UserError if not
  → balance += amount
  → AccountDB::UpdateCorpBalance(corpID, key, newBalance)  // UPDATE
  → AccountDB::AddJournalEntry(corpID, ...)   // DB INSERT
```

**Critical**: None of these paths use `BEGIN`/`COMMIT`, `SELECT ... FOR UPDATE`, or atomic `UPDATE ... SET col = col + X`. The `MDatabase` mutex in `DBcore` serializes individual SQL statements but does NOT span the multi-statement read-compute-write sequence.

### 3.2 DBcore — Database Connection Layer

**File**: `src/eve-core/database/dbcore.{h,cpp}`

- Single `MYSQL*` connection (singleton via `DBcore::get()` → `sDatabase`)
- `Mutex MDatabase` — acquired and released per `RunQuery()` call
- Four query methods: `RunQuery(DBQueryResult&)`, `RunQuery(DBerror&)`, `RunQuery(DBerror&, uint32&)`, `RunQueryLID(DBerror&, uint32&)`
- **No transaction API**: No `BEGIN`, `COMMIT`, `ROLLBACK`, no `mysql_start_transaction()`, no `mysql_commit()`
- Auto-reconnect on server loss
- Character set: UTF-8
- Connection flags: `CLIENT_FOUND_ROWS`

---

## 4. Complete Evidence Matrix

### Legend
- **PASS** — Correct as observed
- **FAIL** — Defect confirmed in code
- **BLOCKED** — Cannot verify without build/runtime
- **OBSERVED** — Not necessarily a bug, but notable

---

### 4.1 Transaction Atomicity

| # | Component (file → function) | Finding | Result |
|---|---|---|---|
| 1.1 | `MarketMgr.cpp` → `ExecuteBuyOrder()` | 6 independent operations (item donate, tax xfer, payment xfer, 2× RecordTransaction, order update) with **NO DB transaction**. Failure at any step after item transfer → inconsistent state. | **FAIL** |
| 1.2 | `MarketMgr.cpp` → `ExecuteSellOrder()` | 5 independent operations. If `SpawnItem` fails after `TranserFunds` succeeds → buyer paid, no item, order not consumed. | **FAIL** |
| 1.3 | `AccountService.cpp` → `TranserFunds()` | Offline char: SELECT→compute→UPDATE without lock. Corp: SELECT→check→UPDATE. **TOCTOU race**. | **FAIL** |
| 1.4 | `AccountDB.cpp` → `OfflineFundXfer()` | `SELECT balance` → `balance += amount` → `UPDATE SET balance = computed`. Classic lost-update. | **FAIL** |
| 1.5 | `AccountDB.cpp` → `UpdateCorpBalance()` | Absolute value UPDATE (not `balance = balance + X`). Called after separate SELECT in `HandleCorpTransaction`. Same TOCTOU. | **FAIL** |
| 1.6 | `AccountDB.cpp` → `AddJournalEntry()` | Separate INSERT after balance update. Comment in code: `"dont care if this fails"`. | **FAIL** |

### 4.2 Market Order Lifecycle

| # | Component (file → function) | Finding | Result |
|---|---|---|---|
| 2.1 | `MarketDB.cpp` → `StoreOrder()` | Single `INSERT INTO mktOrders`. Returns `orderID` via `mysql_insert_id`. | **PASS** |
| 2.2 | `MarketDB.cpp` → `GetOrderInfo()` | `SELECT volRemaining, price, ... FROM mktOrders WHERE orderID=X`. Correct. | **PASS** |
| 2.3 | `MarketDB.cpp` → `FindBuyOrder()` | `SELECT orderID ... WHERE bid=1 ... volRemaining >= Q ... ORDER BY price DESC LIMIT 1`. **No `FOR UPDATE`**. Two concurrent sellers can match the same order. | **FAIL** |
| 2.4 | `MarketDB.cpp` → `FindSellOrder()` | Same pattern for sell orders. **No `FOR UPDATE`**. | **FAIL** |
| 2.5 | `MarketDB.cpp` → `AlterOrderQuantity()` | `UPDATE SET volRemaining = X` (absolute, not decrement). Not atomic. | **FAIL** |
| 2.6 | `MarketDB.cpp` → `DeleteOrder()` | `DELETE FROM mktOrders WHERE orderID = X`. Safe if called once. | **PASS** |
| 2.7 | `MarketDB.cpp` → `RecordTransaction()` | Single `INSERT INTO mktTransactions`. Atomic alone, but not in same TX as other steps. | **PASS** / **FAIL** in context |
| 2.8 | `MarketProxyService.cpp` → `CancelCharOrder()` | Buy: refund escrow → delete. Sell: spawn item → donate → delete. **Non-atomic**. | **FAIL** |

### 4.3 Order Placement (PlaceCharOrder)

| # | Finding | Result |
|---|---|---|
| 3.1 | Standing **buy** order: `StoreOrder()` called BEFORE `TranserFunds(escrow)`. If escrow fails → **orphan order with no backing funds** visible in market. | **FAIL** |
| 3.2 | Standing **sell** order: `TranserFunds(fee)` → `StoreOrder()` → `iRef->Delete()`. If `Delete()` fails → **item duplication** (player keeps item AND has sell order). | **FAIL** |
| 3.3 | No balance pre-check before `StoreOrder()` on buy orders. `TranserFunds` throws after order exists. | **FAIL** |
| 3.4 | Corp market **hard-disabled** at entry: `if (useCorp) { SendErrorMsg("Corporation Market transactions are not available"); return; }`. But `ExecuteBuyOrder`/`ExecuteSellOrder` have extensive corp code paths (dead code). | **OBSERVED** |

### 4.4 Concurrency & Threading

| # | Finding | Result |
|---|---|---|
| 4.1 | `DBcore::MDatabase` mutex protects individual `RunQuery()` calls only. Multi-step SELECT→compute→UPDATE is NOT atomic. Thread A's SELECT can interleave with Thread B's SELECT before either UPDATE. | **FAIL** |
| 4.2 | `MarketMgr` methods have no internal locking. Two clients can concurrently call `ExecuteBuyOrder` on the same order. | **FAIL** (uncertain — depends on threading model) |
| 4.3 | `FindClientByCharID` + `AddBalance` not atomic. Client could disconnect between lookup and balance modification. | **BLOCKED** |

### 4.5 Error Handling & Failure Modes

| # | Finding | Result |
|---|---|---|
| 5.1 | **NULL POINTER DEREFERENCE** in `ExecuteBuyOrder`: `if (siRef.get() == nullptr) { _log(..., siRef->itemID(), siRef->name()); }` — calls `->itemID()` and `->name()` on a null `RefPtr<InventoryItem>`. **Will segfault on the error path.** | **FAIL** |
| 5.2 | `ExecuteBuyOrder`: `RecordTransaction` failure logged but NOT propagated. Order deleted, money moved, but transaction not recorded. | **FAIL** |
| 5.3 | `ExecuteSellOrder`: Same — `RecordTransaction` failure ignored. | **FAIL** |
| 5.4 | `TranserFunds`: Code comment `/** @todo if this DOES fail, return funds to origin. this needs a try/catch block */`. Acknowledged but unimplemented. | **FAIL** (TODO) |
| 5.5 | Standing buy: order in DB, then `TranserFunds(escrow)` throws → orphan order. | **FAIL** |
| 5.6 | Standing sell: fee charged, order stored, `iRef->Delete()` fails → item still in inventory. | **FAIL** |

### 4.6 Database Schema & Migrations

| # | Finding | Result |
|---|---|---|
| 6.1 | Market tables (inferred from C++ code): `mktOrders` (20 cols), `mktTransactions` (12 cols), `mktHistory`, `mktData`, `mktSeedStations`, `mktUpdates`. Actual SQL is in `.sql.gz` files — **cannot verify without decompression**. | **BLOCKED** |
| 6.2 | Migration `20210911143004-market_decimal_prices.sql` (447 B) — changes market prices to decimal. Cannot verify content. | **BLOCKED** |
| 6.3 | 18 migrations total. Latest: `20220328120907-loyaltypoints.sql`. | **BLOCKED** |

### 4.7 Data Type & Precision

| # | Finding | Result |
|---|---|---|
| 7.1 | `Market::SaveData.price` is `float` (32-bit). Precision loss for ISK > 16.7M. | **OBSERVED** |
| 7.2 | `Market::OrderInfo.price` is `float`. Same issue. | **OBSERVED** |
| 7.3 | `MarketDB::RecordTransaction` stores with `%f` (double) but source is `float`. | **OBSERVED** |
| 7.4 | `AlterOrderPrice` uses `%.2f` — intentional 2-decimal truncation for ISK. | **PASS** |

### 4.8 Cache Consistency

| # | Finding | Result |
|---|---|---|
| 8.1 | `InvalidateOrdersCache()` called after all order mutations. | **PASS** |
| 8.2 | Price history cached, refreshed by timer (`UpdatePriceHistory`). Stale is expected. | **PASS** |

### 4.9 Persistence Across Restart

| # | Finding | Result |
|---|---|---|
| 9.1 | Market orders persist in `mktOrders`. | **PASS** |
| 9.2 | Transactions persist in `mktTransactions`. | **PASS** |
| 9.3 | **Online character balances are in-memory only** (`Client::m_balance`). Lost on crash. Persisted only on graceful logout. | **FAIL** |
| 9.4 | Corp balances always in DB (`crpWalletDivisons`). | **PASS** |
| 9.5 | Items in `invItems` table. But non-atomic transactions (1.1/1.2) mean crash between steps → inconsistent state. | **FAIL** (context) |
| 9.6 | Escrow in station owner's escrow account. If crash after `StoreOrder` but before `TranserFunds(escrow)` → order exists without escrow. | **FAIL** |

### 4.10 Existing Tests

| Test | File | Status |
|---|---|---|
| `PasswordModuleTest` | `src/eve-test/auth/` | NOT RUN (no build tools) |
| `EVEMarshalTest` | `src/eve-test/marshal/` | NOT RUN |
| `EvilNumberTest` | `src/eve-test/utils/` | NOT RUN |
| Market tests | — | **DO NOT EXIST** |
| Account/balance tests | — | **DO NOT EXIST** |
| DB integration tests | — | **DO NOT EXIST** |
| Concurrency tests | — | **DO NOT EXIST** |

---

## 5. Severity Summary

### 🔴 CRITICAL — Data Loss / Duplication Possible

| ID | Finding | Impact |
|---|---|---|
| 1.1–1.2 | **No DB transactions** in `ExecuteBuyOrder`/`ExecuteSellOrder` | Crash or error mid-sequence → lost funds, duplicated items, orphaned orders, inconsistent transaction logs |
| 1.3–1.5 | **TOCTOU race** in `OfflineFundXfer()` / `HandleCorpTransaction()` | Concurrent transfers → lost updates, balance corruption |
| 9.3 | **Online balances lost on crash** | All ISK earned during session is gone |

### 🟠 HIGH — Incorrect Behavior / Crashes

| ID | Finding | Impact |
|---|---|---|
| 5.1 | **NULL pointer deref** in `ExecuteBuyOrder` error path | Segfault when `Split()` fails |
| 2.3–2.5 | **No row locking** on order find/modify | Concurrent partial fills over-fulfill orders |
| 3.1 / 5.5 | **Orphan orders** (created before escrow) | Market shows orders with no backing funds |
| 3.2 / 5.6 | **Item duplication** (delete after order) | Player keeps item AND has sell order |
| 5.2–5.3 | **Silent transaction loss** | `RecordTransaction` fails, not propagated |

### 🟡 MEDIUM — Robustness / Design

| ID | Finding |
|---|---|
| 3.4 | Corp market disabled at entry, dead code in Execute*Order |
| 7.1–7.3 | `float` for monetary amounts |
| 5.4 | Acknowledged TODO: no rollback in `TranserFunds` |
| 4.2 | No per-entity locking for market ops |
| 10.x | No market/account/DB tests exist |

### 🔵 LOW / INFORMATIONAL

| ID | Finding |
|---|---|
| 0.1 | `EVEVersion.h` reports "0.8.4-" instead of "0.8.5" |
| 6.x | SQL schema in `.gz` files, blocked from verification |

---

## 6. Recommended Fixes (Priority Order)

### P0 — Fix Immediately (Data Integrity)

**6.1 Add DB transactions to `ExecuteBuyOrder` and `ExecuteSellOrder`**

Wrap the entire sequence in `BEGIN`/`COMMIT` with `ROLLBACK` on any failure. Requires adding transaction methods to `DBcore`:

```cpp
// In dbcore.h, add:
bool BeginTransaction();
bool CommitTransaction();
bool RollbackTransaction();

// In dbcore.cpp, implementation:
bool DBcore::BeginTransaction() {
    MutexLock lock(MDatabase);
    return !DoQuery_locked(m_txError, "BEGIN", 5);
}
bool DBcore::CommitTransaction() {
    MutexLock lock(MDatabase);
    return !DoQuery_locked(m_txError, "COMMIT", 6);
}
bool DBcore::RollbackTransaction() {
    MutexLock lock(MDatabase);
    return !DoQuery_locked(m_txError, "ROLLBACK", 8);
}
```

Then in `ExecuteBuyOrder` / `ExecuteSellOrder`:
```cpp
sDatabase.BeginTransaction();
// ... all operations ...
if (any_failure) {
    sDatabase.RollbackTransaction();
    return false;
}
sDatabase.CommitTransaction();
```

**Note**: The `MDatabase` mutex is acquired per-query. For transactions to work, the mutex must NOT be released between `BEGIN` and `COMMIT`. This requires either:
- Holding the mutex for the entire transaction (reduces concurrency but is safe), OR
- Using a separate connection for transactions, OR
- Using MySQL's `START TRANSACTION` with a session-specific connection

**6.2 Fix TOCTOU in balance operations**

Replace read-compute-write with atomic SQL:

```cpp
// AccountDB.cpp — replace OfflineFundXfer:
// OLD:
//   SELECT balance FROM chrCharacters WHERE characterID = X
//   balance += amount
//   UPDATE chrCharacters SET balance = computed WHERE characterID = X
// NEW:
bool ok = sDatabase.RunQuery(err,
    "UPDATE chrCharacters SET balance = balance + %f WHERE characterID = %u",
    amount, charID);
// Then SELECT the new balance for the journal entry:
double newBalance = GetBalance(charID);
```

Same pattern for `UpdateCorpBalance`:
```cpp
"UPDATE crpWalletDivisons SET balance1 = balance1 + %f WHERE corporationID = %u"
```

**6.3 Fix null pointer dereference in `ExecuteBuyOrder`**

```cpp
// OLD (crashes):
InventoryItemRef siRef = iRef->Split(quantity);
if (siRef.get() == nullptr) {
    _log(MARKET__ERROR, "ExecuteBuyOrder - Failed to split %u %s.",
         siRef->itemID(), siRef->name());  // NULL DEREF!
    return true;
}

// NEW:
InventoryItemRef siRef = iRef->Split(quantity);
if (siRef.get() == nullptr) {
    _log(MARKET__ERROR, "ExecuteBuyOrder - Failed to split %u units of typeID %u.",
         quantity, typeID);
    return true;
}
```

**6.4 Reorder PlaceCharOrder to check funds before creating order**

```
// BUY (standing):
1. Check balance >= fee + escrow
2. TranserFunds(fee)
3. TranserFunds(escrow)
4. StoreOrder()        ← now safe, funds already secured
5. InvalidateCache + Notify

// SELL (standing):
1. Verify item exists and quantity sufficient
2. TranserFunds(fee)
3. StoreOrder()
4. iRef->Delete() or AlterQuantity()   ← if this fails, rollback (delete order, refund fee)
5. InvalidateCache + Notify
```

### P1 — Fix Soon (Concurrency)

**6.5 Add row-level locking to order matching**

```sql
-- FindBuyOrder: add FOR UPDATE
SELECT orderID FROM mktOrders
WHERE bid=1 AND typeID=%u AND stationID=%u
  AND volRemaining >= %u AND price > %.2f
ORDER BY price DESC
LIMIT 1
FOR UPDATE
```

Or better, use atomic conditional decrement:
```sql
UPDATE mktOrders
SET volRemaining = volRemaining - %u
WHERE orderID = %u AND volRemaining >= %u
```
Check `affected_rows` to see if the claim succeeded.

**6.6 Make AlterOrderQuantity atomic**

```sql
-- OLD:
UPDATE mktOrders SET volRemaining = %u WHERE orderID = %u
-- NEW:
UPDATE mktOrders SET volRemaining = volRemaining - %u
WHERE orderID = %u AND volRemaining >= %u
```

### P2 — Improve (Robustness)

**6.7 Propagate RecordTransaction failures**

```cpp
if (!MarketDB::RecordTransaction(data)) {
    _log(MARKET__ERROR, "ExecuteBuyOrder - Failed to record transaction.");
    return false;  // ← ADD THIS
    // Or: throw CustomError("TransactionRecordFailed");
}
```

**6.8 Implement TranserFunds rollback**

```cpp
void AccountService::TranserFunds(...) {
    // ... debit sender ...
    try {
        // ... credit recipient ...
    } catch (const UserError& e) {
        // Refund sender
        TranserFunds(toID, fromID, amount, "REFUND: " + reason, ...);
        throw;  // re-throw
    }
}
```

**6.9 Persist online balances periodically or per-transaction**

After every `TranserFunds` involving an online character, also update the DB:
```cpp
if (pClientFrom != nullptr) {
    pClientFrom->AddBalance(-amount, fromCurrency);
    // ALSO persist to DB:
    AccountDB::UpdateCharBalance(fromID, pClientFrom->GetBalance(fromCurrency), fromCurrency);
}
```

### P3 — Long-term

- **6.10**: Replace `float` with `double` for all monetary amounts in C++ structs
- **6.11**: Write market integration tests (see §7)
- **6.12**: Write concurrency stress tests
- **6.13**: Add CI pipeline that runs tests against a test MariaDB
- **6.14**: Document or remove corp market dead code
- **6.15**: Fix `EVEVersion.h` version prefix ("0.8.4-" → "0.8.5-")

---

## 7. Recommended Test Plan

### Test Database Setup

```sql
CREATE DATABASE IF NOT EXISTS evemu_test;
USE evemu_test;
-- Import all .sql.gz base tables (gunzip | mysql)
-- Apply all 18 migrations in order
-- Insert test characters, corporations, stations
```

### Test Categories

| # | Category | Tests | What to verify |
|---|---|---|---|
| T1 | **DB CRUD** | StoreOrder, GetOrderInfo, GetOrderRow, AlterQuantity, AlterPrice, FindBuy/Sell, DeleteOrder, GetOrders, GetOrdersForOwner | All fields match, correct filtering, auto-increment IDs |
| T2 | **Transactions** | RecordTransaction, GetTransactions | Correct rows, filtering, auto-increment |
| T3 | **Fund Transfers** | Online→Online, Online→Offline, Offline→Offline, →Corp, insufficient balance (char + corp) | Balances correct, journal entries created, errors thrown |
| T4 | **ExecuteBuyOrder** | Partial fill (100 of 150), full fill (150 of 150), under-fill (50 of 150, order qty 100) | Item split/donated, balances updated, order state correct, 2× transactions recorded |
| T5 | **ExecuteSellOrder** | Full purchase (100), partial purchase (50 of 100) | Item spawned+donated, balances updated, order state correct, 2× transactions |
| T6 | **Concurrency** | 2 threads × partial fill same order (60+60, order qty 100), 2 threads × purchase same sell order | Total fulfilled ≤ order qty, no negative volRemaining, ISK consistent |
| T7 | **Forced Failures** | RecordTransaction fails, SpawnItem fails, TranserFunds throws, iRef->Delete() fails, CancelOrder refund fails | No orphan state, no item duplication, no lost funds |
| T8 | **Persistence** | Place order → "restart" (close+reopen DB), partial fill → "restart", multiple txns → "restart" | All state preserved, volRemaining correct, escrow intact |

### Build & Run

```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Debug -DAUTO_DOWNLOAD_DEPENDENCIES=ON
cmake --build . --target eve-test --config Debug
ctest -R "Market|Account|Execute|Concurrency|Failure|Persistence" -V
```

---

## 8. Safety Notes

- **No production databases were modified**
- **No source code was changed**
- **No git history was altered**
- All findings are based on **static analysis** at commit `7d5e2061`
- Findings marked **BLOCKED** require a build environment or runtime to verify
- The `.sql.gz` base schema files could not be decompressed and inspected in the audit environment
